import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, MapPin, Droplets, Phone, Clock, HeartPulse, RefreshCcw } from 'lucide-react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './style.css';

const donors = [
  { id: 1, name: 'Priyanka Rana', blood: 'O+', city: 'Surat', area: 'Adajan', availability: 'Available', units: 2, lastDonation: '12 Sep 2026', phone: '+91 98765 43210' },
  { id: 2, name: 'Devang Gohil', blood: 'A+', city: 'Surat', area: 'Vesu', availability: 'Available', units: 1, lastDonation: '20 Aug 2026', phone: '+91 98765 12345' },
  { id: 3, name: 'Neha Patel', blood: 'B+', city: 'Ahmedabad', area: 'Navrangpura', availability: 'Available', units: 3, lastDonation: '02 Sep 2026', phone: '+91 98989 11122' },
  { id: 4, name: 'Rahul Shah', blood: 'AB+', city: 'Vadodara', area: 'Alkapuri', availability: 'Available', units: 1, lastDonation: '15 Jul 2026', phone: '+91 99001 22334' },
  { id: 5, name: 'Kavita Joshi', blood: 'O-', city: 'Surat', area: 'City Light', availability: 'Available', units: 1, lastDonation: '28 Aug 2026', phone: '+91 98123 45678' },
  { id: 6, name: 'Amit Mehta', blood: 'A-', city: 'Rajkot', area: 'Kalawad Road', availability: 'Available', units: 2, lastDonation: '01 Sep 2026', phone: '+91 98222 33445' },
  { id: 7, name: 'Riya Desai', blood: 'B-', city: 'Surat', area: 'Pal', availability: 'Unavailable', units: 0, lastDonation: '10 Oct 2026', phone: '+91 98333 44556' },
  { id: 8, name: 'Harsh Trivedi', blood: 'AB-', city: 'Ahmedabad', area: 'Bopal', availability: 'Available', units: 1, lastDonation: '25 Aug 2026', phone: '+91 98444 55667' }
];

function App() {
  const [blood, setBlood] = useState('All Blood Groups');
  const [city, setCity] = useState('All Cities');
  const [keyword, setKeyword] = useState('');
  const [searched, setSearched] = useState(false);

  const results = useMemo(() => donors.filter(d =>
    (blood === 'All Blood Groups' || d.blood === blood) &&
    (city === 'All Cities' || d.city === city) &&
    (!keyword.trim() || `${d.name} ${d.area} ${d.city}`.toLowerCase().includes(keyword.trim().toLowerCase()))
  ), [blood, city, keyword]);

  const reset = () => { setBlood('All Blood Groups'); setCity('All Cities'); setKeyword(''); setSearched(false); };

  return <div className="app-shell">
    <nav className="navbar navbar-expand-lg navbar-dark topbar">
      <div className="container"><a className="navbar-brand fw-bold" href="#top"><Droplets size={24} fill="currentColor" /> Blood<span>Link</span></a>
        <div className="ms-auto d-flex align-items-center gap-3 text-white small"><HeartPulse size={19}/> Emergency Blood Support</div>
      </div>
    </nav>

    <main id="top" className="container py-5">
      <div className="hero text-center mb-4"><div className="icon-circle"><Droplets size={30}/></div><h1>Blood Availability Search</h1><p>Find available blood donors near you quickly and safely.</p></div>

      <section className="search-card shadow-sm">
        <div className="row g-3 align-items-end">
          <div className="col-lg-3 col-md-6"><label className="form-label">Blood Group</label><select className="form-select" value={blood} onChange={e=>setBlood(e.target.value)}><option>All Blood Groups</option>{['A+','A-','B+','B-','AB+','AB-','O+','O-'].map(x=><option key={x}>{x}</option>)}</select></div>
          <div className="col-lg-3 col-md-6"><label className="form-label">City</label><select className="form-select" value={city} onChange={e=>setCity(e.target.value)}><option>All Cities</option>{[...new Set(donors.map(d=>d.city))].sort().map(x=><option key={x}>{x}</option>)}</select></div>
          <div className="col-lg-4 col-md-8"><label className="form-label">Area / Donor Name</label><div className="input-group"><span className="input-group-text"><MapPin size={18}/></span><input className="form-control" placeholder="Search area or donor name" value={keyword} onChange={e=>setKeyword(e.target.value)} /></div></div>
          <div className="col-lg-2 col-md-4 d-flex gap-2"><button className="btn btn-blood flex-grow-1" onClick={()=>setSearched(true)}><Search size={18}/> Search</button><button className="btn btn-light border" onClick={reset} title="Reset"><RefreshCcw size={18}/></button></div>
        </div>
      </section>

      <div className="d-flex justify-content-between align-items-center mt-4 mb-3"><div><h4 className="mb-1">{searched ? 'Search Results' : 'Available Donors'}</h4><span className="text-muted small">{results.length} donor{results.length !== 1 ? 's' : ''} found</span></div><span className="availability-badge"><span></span> Live availability</span></div>

      <div className="row g-3">{results.map(d=><div className="col-lg-6" key={d.id}><article className="donor-card h-100"><div className="blood-badge">{d.blood}</div><div className="flex-grow-1"><div className="d-flex justify-content-between gap-2"><div><h5 className="mb-1">{d.name}</h5><div className="location"><MapPin size={15}/> {d.area}, {d.city}</div></div><span className={d.availability === 'Available' ? 'status available' : 'status unavailable'}>{d.availability}</span></div><div className="details mt-3"><span><Droplets size={15}/> {d.units} unit{d.units !== 1 ? 's' : ''}</span><span><Clock size={15}/> Last donation: {d.lastDonation}</span></div><div className="mt-3"><a className="btn btn-outline-danger btn-sm" href={`tel:${d.phone.replace(/\s/g,'')}`}><Phone size={15}/> Contact Donor</a></div></div></article></div>)}</div>

      {results.length === 0 && <div className="empty text-center py-5 mt-3"><Droplets size={42}/><h5 className="mt-3">No matching blood donors found</h5><p className="text-muted">Try another blood group, city, or area.</p><button className="btn btn-blood" onClick={reset}>Clear Search</button></div>}
      <p className="disclaimer text-center mt-5">For emergency requirements, please contact your nearest hospital or blood bank. Donor availability can change at any time.</p>
    </main>
    <footer className="footer"><div className="container text-center">© 2026 Blood Link · Connecting donors with patients</div></footer>
  </div>;
}

createRoot(document.getElementById('root')).render(<App />);
