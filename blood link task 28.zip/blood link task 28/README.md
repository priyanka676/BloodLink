# Blood Link - Blood Availability Search Page

A standalone React + Vite + Bootstrap 5 Blood Availability Search page.

## Run

1. Open this folder in VS Code.
2. Open Terminal.
3. Run:

```bash
npm install
npm run dev
```

4. Open the URL shown by Vite, normally `http://localhost:5173/`.

## Features

- Blood group filter
- City filter
- Area / donor-name search
- Search and reset buttons
- Live donor result count
- Available/unavailable status
- Contact Donor phone action
- Responsive Bootstrap 5 design
- No backend required; sample donor data is included in `src/main.jsx`
