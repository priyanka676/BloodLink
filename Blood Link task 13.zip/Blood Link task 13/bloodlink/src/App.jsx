import React, { useMemo, useState } from "react";
import {
  LayoutDashboard,
  Droplets,
  ClipboardList,
  Bell,
  UserCircle,
  LogOut,
  HeartPulse,
  MapPin,
  CalendarDays,
  Clock3,
  Hospital,
  Send,
  CheckCircle2,
  Menu,
  X
} from "lucide-react";

const initialRequests = [
  {
    id: "REQ-1001",
    bloodGroup: "O+",
    units: 2,
    hospital: "City Care Hospital",
    urgency: "Urgent",
    status: "Pending",
    date: "01 Oct 2026"
  },
  {
    id: "REQ-1000",
    bloodGroup: "A+",
    units: 1,
    hospital: "LifeLine Hospital",
    urgency: "Normal",
    status: "Approved",
    date: "28 Sep 2026"
  }
];

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [requests, setRequests] = useState(initialRequests);
  const [submitted, setSubmitted] = useState(false);

  const [form, setForm] = useState({
    bloodGroup: "",
    units: "1",
    hospital: "",
    city: "",
    requiredDate: "",
    requiredTime: "",
    urgency: "Normal",
    reason: "",
    notes: ""
  });

  const summary = useMemo(() => ({
    total: requests.length,
    pending: requests.filter(r => r.status === "Pending").length,
    approved: requests.filter(r => r.status === "Approved").length
  }), [requests]);

  const update = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setSubmitted(false);
  };

  const submitRequest = (e) => {
    e.preventDefault();

    if (!form.bloodGroup || !form.units || !form.hospital || !form.city || !form.requiredDate || !form.requiredTime || !form.reason) {
      return;
    }

    const newRequest = {
      id: `REQ-${1002 + requests.length - initialRequests.length}`,
      bloodGroup: form.bloodGroup,
      units: Number(form.units),
      hospital: form.hospital,
      urgency: form.urgency,
      status: "Pending",
      date: new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
      })
    };

    setRequests([newRequest, ...requests]);
    setSubmitted(true);
    setForm({
      bloodGroup: "",
      units: "1",
      hospital: "",
      city: "",
      requiredDate: "",
      requiredTime: "",
      urgency: "Normal",
      reason: "",
      notes: ""
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "show" : ""}`}>
        <div className="brand">
          <div className="brand-icon"><Droplets size={22} fill="currentColor" /></div>
          <div>
            <strong>Blood Link</strong>
            <small>Patient Portal</small>
          </div>
          <button className="close-sidebar d-lg-none" onClick={() => setSidebarOpen(false)}><X /></button>
        </div>

        <nav className="side-nav">
          <a href="#dashboard"><LayoutDashboard size={19} /> Dashboard</a>
          <a className="active" href="#request"><Droplets size={19} /> Request Blood</a>
          <a href="#requests"><ClipboardList size={19} /> My Requests</a>
          <a href="#notifications"><Bell size={19} /> Notifications</a>
          <a href="#profile"><UserCircle size={19} /> My Profile</a>
        </nav>

        <div className="sidebar-bottom">
          <div className="support-card">
            <HeartPulse size={25} />
            <div>
              <strong>Need help?</strong>
              <span>Contact support</span>
            </div>
          </div>
          <button className="logout-btn"><LogOut size={18} /> Logout</button>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <button className="menu-btn d-lg-none" onClick={() => setSidebarOpen(true)}><Menu /></button>
          <div>
            <h1>Request Blood</h1>
            <p>Create a new blood request for yourself or a patient.</p>
          </div>
          <div className="profile-chip">
            <div className="avatar">PR</div>
            <div className="d-none d-sm-block">
              <strong>Priyanka Rana</strong>
              <span>Patient</span>
            </div>
          </div>
        </header>

        <section className="content">
          {submitted && (
            <div className="success-alert">
              <CheckCircle2 size={22} />
              <div>
                <strong>Blood request submitted successfully.</strong>
                <span>Your request has been added with Pending status.</span>
              </div>
            </div>
          )}

          <div className="stats-row">
            <div className="mini-stat">
              <span className="stat-icon blue"><ClipboardList size={20} /></span>
              <div><small>Total Requests</small><strong>{summary.total}</strong></div>
            </div>
            <div className="mini-stat">
              <span className="stat-icon orange"><Clock3 size={20} /></span>
              <div><small>Pending</small><strong>{summary.pending}</strong></div>
            </div>
            <div className="mini-stat">
              <span className="stat-icon green"><CheckCircle2 size={20} /></span>
              <div><small>Approved</small><strong>{summary.approved}</strong></div>
            </div>
          </div>

          <div id="request" className="request-card">
            <div className="card-heading">
              <div>
                <h2>Blood Request Details</h2>
                <p>Fill in the details below to submit your blood requirement.</p>
              </div>
              <span className="required-note">* Required fields</span>
            </div>

            <form onSubmit={submitRequest}>
              <div className="section-label"><span>01</span> Blood Information</div>
              <div className="row g-4">
                <div className="col-md-6">
                  <label>Blood Group <b>*</b></label>
                  <select className="form-select" name="bloodGroup" value={form.bloodGroup} onChange={update} required>
                    <option value="">Select blood group</option>
                    {["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"].map(g => <option key={g}>{g}</option>)}
                  </select>
                </div>
                <div className="col-md-6">
                  <label>Required Units <b>*</b></label>
                  <select className="form-select" name="units" value={form.units} onChange={update} required>
                    {[1,2,3,4,5,6,7,8,9,10].map(n => <option key={n} value={n}>{n} {n === 1 ? "Unit" : "Units"}</option>)}
                  </select>
                </div>
                <div className="col-md-6">
                  <label>Urgency <b>*</b></label>
                  <select className="form-select" name="urgency" value={form.urgency} onChange={update}>
                    <option>Normal</option>
                    <option>Urgent</option>
                    <option>Emergency</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <label>Reason / Requirement <b>*</b></label>
                  <input className="form-control" name="reason" value={form.reason} onChange={update} placeholder="e.g. Surgery, Accident, Treatment" required />
                </div>
              </div>

              <div className="section-label mt-5"><span>02</span> Hospital & Location</div>
              <div className="row g-4">
                <div className="col-md-6">
                  <label><Hospital size={15} /> Hospital Name <b>*</b></label>
                  <input className="form-control" name="hospital" value={form.hospital} onChange={update} placeholder="Enter hospital name" required />
                </div>
                <div className="col-md-6">
                  <label><MapPin size={15} /> City <b>*</b></label>
                  <input className="form-control" name="city" value={form.city} onChange={update} placeholder="Enter city" required />
                </div>
              </div>

              <div className="section-label mt-5"><span>03</span> Required Date & Time</div>
              <div className="row g-4">
                <div className="col-md-6">
                  <label><CalendarDays size={15} /> Required Date <b>*</b></label>
                  <input type="date" className="form-control" name="requiredDate" value={form.requiredDate} onChange={update} required />
                </div>
                <div className="col-md-6">
                  <label><Clock3 size={15} /> Required Time <b>*</b></label>
                  <input type="time" className="form-control" name="requiredTime" value={form.requiredTime} onChange={update} required />
                </div>
              </div>

              <div className="section-label mt-5"><span>04</span> Additional Information</div>
              <div className="row g-4">
                <div className="col-12">
                  <label>Additional Notes</label>
                  <textarea className="form-control" rows="4" name="notes" value={form.notes} onChange={update} placeholder="Add any additional information that may help the blood bank or hospital..."></textarea>
                </div>
              </div>

              <div className="form-footer">
                <span><Droplets size={17} /> Your request will be reviewed by the blood bank.</span>
                <button className="submit-btn" type="submit"><Send size={18} /> Submit Blood Request</button>
              </div>
            </form>
          </div>

          <div id="requests" className="request-card recent-card">
            <div className="card-heading">
              <div><h2>Recent Blood Requests</h2><p>Your latest submitted requests.</p></div>
              <a href="#request">+ New Request</a>
            </div>
            <div className="table-responsive">
              <table className="table align-middle">
                <thead><tr><th>Request ID</th><th>Blood</th><th>Hospital</th><th>Units</th><th>Urgency</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                  {requests.map(r => (
                    <tr key={r.id}>
                      <td><strong>{r.id}</strong></td>
                      <td><span className="blood-badge">{r.bloodGroup}</span></td>
                      <td>{r.hospital}</td>
                      <td>{r.units}</td>
                      <td><span className={`urgency ${r.urgency.toLowerCase()}`}>{r.urgency}</span></td>
                      <td><span className={`status ${r.status.toLowerCase()}`}>{r.status}</span></td>
                      <td>{r.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>

      {sidebarOpen && <div className="overlay d-lg-none" onClick={() => setSidebarOpen(false)}></div>}
    </div>
  );
}

export default App;
