export const donorsData = [
  { id: "D-501", name: "Priyanka Rana", blood: "O+", age: 26, city: "Ahmedabad", donations: 12, status: "Available" },
  { id: "D-502", name: "Devang Gohil", blood: "A+", age: 29, city: "Surat", donations: 8, status: "Available" },
  { id: "D-503", name: "Jay Patel", blood: "B+", age: 33, city: "Vadodara", donations: 15, status: "Unavailable" },
  { id: "D-504", name: "Nisha Rao", blood: "O-", age: 27, city: "Ahmedabad", donations: 5, status: "Available" },
  { id: "D-505", name: "Rahul Shah", blood: "AB+", age: 31, city: "Rajkot", donations: 10, status: "Available" },
  { id: "D-506", name: "Meera Patel", blood: "B-", age: 25, city: "Surat", donations: 6, status: "Unavailable" },
];
