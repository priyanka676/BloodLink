import React, { useState } from "react";
import { Search, Plus } from "lucide-react";
export default function Patients() {
    const [q, setQ] = useState("");
    const data = [["P-1001", "Priyanka Rana", "aarav@email.com",
        "O+", "28", "Ahmedabad", "Active"],
    ["P-1002", "Diya Patel", "diya@email.com",
        "A+", "31", "Surat", "Active"],
    ["P-1003", "Priyanka Rana", "priyanka.com", "B+", "24", "Vadodara", "Active"],
    ["P-1004", "Kavya Joshi", "kavya@email.com", "AB+", "35", "Ahmedabad", "Inactive"]];
    const rows = data.filter(x => x.join(" ").toLowerCase().includes(q.toLowerCase()));
    return <>
        <Page title="Patients" desc="Manage registered blood recipients.">
            <div className="toolbar">
                <div className="search">
                    <Search size={18} />
                    <input placeholder="Search patients..." value={q} onChange={e => setQ(e.target.value)} />
                </div>
                <button className="primary">
                    <Plus size={17} /> Add Patient</button>
            </div>
            <DataTable headers={["ID", "Name", "Email", "Blood Type", "Age", "City", "Status"]} rows={rows} />
        </Page>
    </>
}
function Page(p) {
    return <>
        <div className="page-head">
            <div>
                <h1>{p.title}</h1>
                <p>{p.desc}</p>
            </div>
        </div>
        <section className="panel">{p.children}</section>
    </>
}
function DataTable({ headers, rows }) {
    return <table>
        <thead>
            <tr>
                {headers.map(h => <th key={h}>{h}</th>
                )}
            </tr>
        </thead>
        <tbody>
            {
                rows.map((r, i) => <tr key={i}>{r.map((c, j) =>
                    <td key={j}>{j === r.length - 1 ?
                        <span className={`status ${String(c).toLowerCase()}`}>{c}</span> : c}
                    </td>)}
                </tr>)}
        </tbody>
    </table>
}