import React from "react";
export default function Reports() {
    return <>
        <div className="page-head"><div>
            <h1>Reports</h1>
            <p>Generate and review blood management reports.</p>
        </div>
        </div>
        <div className="card-grid">
            {["Monthly Blood Collection",
                "Blood Request Summary",
                "Donor Activity",
                "Hospital Performance"].map((x, i) =>
                    <div className="simple-card" key={x}>
                        <div className="report-icon">▦</div>
                        <h3>{x}</h3>
                        <p>Generate a detailed report for this category.</p>
                        <button className="outline">Generate Report</button>
                    </div>)}
        </div>
    </>
}