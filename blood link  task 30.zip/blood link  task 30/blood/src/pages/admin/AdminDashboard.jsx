import React from "react";
import { Users, HeartPulse, Droplets, ClipboardList, TrendingUp, ArrowUpRight } from "lucide-react";
import StatCard from "../../components/StatCard";

export default function AdminDashboard() {
  const recent = [
    ["REQ-1042", "Priya Shah", "O+", "2 Units", "Pending"],
    ["REQ-1041", "Amit Patel", "B+", "1 Unit", "Approved"],
    ["REQ-1040", "Neha Joshi", "A-", "3 Units", "Processing"],
    ["REQ-1039", "Ravi Mehta", "AB+", "2 Units", "Completed"]
  ];
  return <div>
    <div className="page-head"><div><h1>Admin Dashboard</h1><p>Overview of your blood management system.</p></div><button className="primary">+ Add New</button></div>
    <div className="stats-grid">
      <StatCard title="Total Patients" value="1,284" note="+12.5% this month" icon={Users} type="blue" />
      <StatCard title="Active Donors" value="846" note="+8.2% this month" icon={HeartPulse} type="green" />
      <StatCard title="Blood Units" value="3,462" note="Across all blood types" icon={Droplets} type="red" />
      <StatCard title="Pending Requests" value="38" note="Needs attention" icon={ClipboardList} type="orange" />
    </div>
    <div className="dashboard-grid">
      <section className="panel"><div className="panel-head"><h3>Blood Inventory</h3><a href="/admin/inventory">View all <ArrowUpRight size={15} /></a></div>
        <div className="blood-bars">{[["A+", "82%", 164], ["A-", "44%", 88], ["B+", "67%", 134], ["B-", "31%", 62], ["O+", "91%", 182], ["O-", "38%", 76], ["AB+", "54%", 108], ["AB-", "24%", 48]].map(x => <div className="bar-row" key={x[0]}><b>{x[0]}</b><div className="bar"><i style={{ width: x[1] }}></i></div><span>{x[2]} units</span></div>)}</div>
      </section>
      <section className="panel"><div className="panel-head"><h3>Monthly Requests</h3><TrendingUp size={19} /></div><div className="chart"><div className="chart-line"></div><div className="chart-labels"><span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span><span>Jun</span></div></div></section>
    </div>
    <section className="panel table-panel"><div className="panel-head"><h3>Recent Blood Requests</h3><a href="/admin/requests">View all <ArrowUpRight size={15} /></a></div>
      <table><thead><tr><th>Request ID</th><th>Patient</th><th>Blood Type</th><th>Quantity</th><th>Status</th></tr></thead><tbody>{recent.map(r => <tr key={r[0]}>{r.map((c, i) => <td key={i}>{i === 4 ? <span className={`status ${c.toLowerCase()}`}>{c}</span> : c}</td>)}</tr>)}</tbody></table>
    </section>
  </div>;
}