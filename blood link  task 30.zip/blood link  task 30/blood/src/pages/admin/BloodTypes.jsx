import React from "react";
export default function BloodTypes() {
    const types = [["A+", "482", "Good"],
    ["A-", "186", "Low"],
    ["B+", "376", "Good"],
    ["B-", "121", "Low"],
    ["O+", "912", "Excellent"],
    ["O-", "204", "Low"],
    ["AB+", "348", "Good"],
    ["AB-", "78", "Critical"]];
    return <><div className="page-head">
        <div>
            <h1>Blood Types</h1>
            <p>Blood group availability overview.</p>
        </div>
    </div>
        <div className="blood-grid">
            {
                types.map(t => <div className="blood-card" key={t[0]}>
                    <div className="blood-symbol">
                        {t[0]}
                    </div>
                    <div>
                        <small>Available Units</small>
                        <h2>{t[1]}</h2>
                        <span className={`status ${t[2].toLowerCase()}`}>
                            {t[2]}
                        </span>
                    </div>
                </div>
                )}
        </div>
    </>
}