import React from "react";
export default function Hospitals() {
    const h = [["City Hospital", "Ahmedabad", "24/7", "Verified"],
    ["Civil Hospital", "Ahmedabad", "24/7", "Verified"],
    ["LifeCare Hospital", "Surat", "24/7", "Verified"],
    ["Sunrise Hospital", "Vadodara", "8 AM - 10 PM", "Pending"]];
    return <>
        <div className="page-head"><div>
            <h1>Hospitals</h1>
            <p>Manage hospitals connected with BloodLink.</p>
        </div>
            <button className="primary">+ Add Hospital</button>
        </div>
        <div className="card-grid">
            {h.map(x => <div className="simple-card" key={x[0]}><h3>{x[0]}</h3>
                <p>📍 {x[1]}</p><p>🕒 {x[2]}</p>
                <span className={`status ${x[3].toLowerCase()}`}>{x[3]}</span>
            </div>)}
        </div>
    </>
}