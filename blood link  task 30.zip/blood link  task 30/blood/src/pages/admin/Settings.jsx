import React, { useState } from "react";
export default function Settings() {
    const [saved, setSaved] = useState(false);
    return <>
        <div className="page-head"><div>
            <h1>Settings</h1>
            <p>Configure your BloodLink admin preferences.</p>
        </div>
        </div>
        <section className="panel settings">
            <label>Organization Name
                <input defaultValue="BloodLink Blood Management" />
            </label>
            <label>Admin Email
                <input defaultValue="admin@bloodlink.com" />
            </label>
            <label>Notification Email
                <input defaultValue="notifications@bloodlink.com" />
            </label>
            <label className="switch-row">Enable email notifications
                <input type="checkbox" defaultChecked />
            </label>
            <button className="primary" onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000) }}>Save Changes</button>
            {saved && <span className="saved">Settings saved successfully.</span>}
        </section>
    </>
}