import React, { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  Plus,
  Search,
  Eye,
  Trash2,
  Droplets,
  Users,
  CalendarDays,
  Activity,
  ArrowLeft,
} from "lucide-react";
import { donorsData } from "../../data/donors";
import "./DonationHistory.css";

const STORAGE_KEY = "bloodlink_donation_history";
const BLOOD_TYPES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const STATUSES = ["Completed", "Pending", "Deferred"];
const PAGE_SIZE = 6;

const seedHistory = [
  { id: "DN-1001", donorId: "D-501", date: "2026-10-02", volume: 450, location: "Civil Hospital, Ahmedabad", status: "Completed", notes: "Regular donation" },
  { id: "DN-1002", donorId: "D-502", date: "2026-10-01", volume: 350, location: "Red Cross Blood Bank, Surat", status: "Completed", notes: "" },
  { id: "DN-1003", donorId: "D-504", date: "2026-09-28", volume: 450, location: "Blood Donation Camp, Ahmedabad", status: "Completed", notes: "Rare group O-, urgent stock" },
  { id: "DN-1004", donorId: "D-505", date: "2026-09-20", volume: 350, location: "Rajkot Civil Hospital", status: "Pending", notes: "Awaiting lab screening" },
  { id: "DN-1005", donorId: "D-503", date: "2026-09-14", volume: 450, location: "SSG Hospital, Vadodara", status: "Completed", notes: "" },
  { id: "DN-1006", donorId: "D-506", date: "2026-09-05", volume: 350, location: "Red Cross Blood Bank, Surat", status: "Deferred", notes: "Low haemoglobin, advised to retry later" },
  { id: "DN-1007", donorId: "D-501", date: "2026-06-30", volume: 450, location: "Civil Hospital, Ahmedabad", status: "Completed", notes: "" },
  { id: "DN-1008", donorId: "D-502", date: "2026-06-18", volume: 450, location: "New Civil Hospital, Surat", status: "Completed", notes: "" },
  { id: "DN-1009", donorId: "D-503", date: "2026-05-22", volume: 350, location: "SSG Hospital, Vadodara", status: "Completed", notes: "" },
  { id: "DN-1010", donorId: "D-505", date: "2026-04-10", volume: 450, location: "Rajkot Civil Hospital", status: "Completed", notes: "" },
  { id: "DN-1011", donorId: "D-504", date: "2026-03-25", volume: 350, location: "Blood Donation Camp, Ahmedabad", status: "Completed", notes: "" },
  { id: "DN-1012", donorId: "D-501", date: "2026-02-12", volume: 450, location: "Civil Hospital, Ahmedabad", status: "Completed", notes: "" },
];

function loadHistory() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (Array.isArray(saved)) return saved;
  } catch {
    /* ignore corrupt storage */
  }
  return seedHistory;
}

function parseDate(value) {
  return new Date(`${value}T00:00:00`);
}

function formatDate(value) {
  return parseDate(value).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function nextEligible(record) {
  if (record.status !== "Completed") return "—";
  const d = parseDate(record.date);
  d.setDate(d.getDate() + 90);
  return d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function todayISO() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

const emptyForm = () => ({
  donorId: "",
  date: todayISO(),
  volume: "450",
  location: "",
  status: "Completed",
  notes: "",
});

export default function DonationHistory() {
  const [searchParams, setSearchParams] = useSearchParams();
  const donorFilter = searchParams.get("donor") || "";

  const [history, setHistory] = useState(loadHistory);
  const [search, setSearch] = useState("");
  const [bloodFilter, setBloodFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [page, setPage] = useState(1);

  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [viewing, setViewing] = useState(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch {
      /* storage unavailable */
    }
  }, [history]);

  // join history rows with donor details
  const records = useMemo(
    () =>
      history
        .map((h) => {
          const donor = donorsData.find((d) => d.id === h.donorId);
          return {
            ...h,
            donorName: donor?.name || "Unknown donor",
            blood: donor?.blood || "—",
            city: donor?.city || "",
          };
        })
        .sort((a, b) => parseDate(b.date) - parseDate(a.date)),
    [history]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return records.filter((r) => {
      if (donorFilter && r.donorId !== donorFilter) return false;
      if (bloodFilter !== "All" && r.blood !== bloodFilter) return false;
      if (statusFilter !== "All" && r.status !== statusFilter) return false;
      if (!q) return true;
      return [r.id, r.donorId, r.donorName, r.blood, r.location, r.status]
        .join(" ")
        .toLowerCase()
        .includes(q);
    });
  }, [records, search, bloodFilter, statusFilter, donorFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageRows = filtered.slice(start, start + PAGE_SIZE);

  const stats = useMemo(() => {
    const now = new Date();
    const completed = records.filter((r) => r.status === "Completed");
    const thisMonth = completed.filter((r) => {
      const d = parseDate(r.date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    });
    return {
      total: completed.length,
      volume: (completed.reduce((s, r) => s + Number(r.volume), 0) / 1000).toFixed(2),
      month: thisMonth.length,
      donors: new Set(completed.map((r) => r.donorId)).size,
    };
  }, [records]);

  const activeDonor = donorsData.find((d) => d.id === donorFilter);

  const resetPage = () => setPage(1);

  const openAdd = () => {
    setForm({ ...emptyForm(), donorId: donorFilter });
    setErrors({});
    setShowAdd(true);
  };

  const setField = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  const handleSave = (e) => {
    e.preventDefault();
    const next = {};
    if (!form.donorId) next.donorId = "Please select a donor";
    if (!form.date) next.date = "Date is required";
    else if (form.date > todayISO()) next.date = "Date cannot be in the future";
    if (!form.location.trim()) next.location = "Location is required";
    setErrors(next);
    if (Object.keys(next).length) return;

    const maxNum = history.reduce(
      (m, h) => Math.max(m, parseInt(h.id.replace("DN-", ""), 10) || 0),
      1000
    );
    const record = {
      id: `DN-${maxNum + 1}`,
      donorId: form.donorId,
      date: form.date,
      volume: Number(form.volume),
      location: form.location.trim(),
      status: form.status,
      notes: form.notes.trim(),
    };
    setHistory((h) => [record, ...h]);
    setShowAdd(false);
    setPage(1);
  };

  const handleDelete = (record) => {
    if (window.confirm(`Delete donation record ${record.id}?`)) {
      setHistory((h) => h.filter((x) => x.id !== record.id));
      if (viewing?.id === record.id) setViewing(null);
    }
  };

  const clearDonorFilter = () => {
    setSearchParams({});
    resetPage();
  };

  const selectedDonor = donorsData.find((d) => d.id === form.donorId);

  return (
    <div className="dh-page">
      <div className="dh-heading">
        <div>
          <h1>Donation History</h1>
          <p>
            {activeDonor
              ? `Donation records for ${activeDonor.name} (${activeDonor.id})`
              : "Track every blood donation made by registered donors."}
          </p>
        </div>
        <div className="dh-heading-actions">
          {activeDonor && (
            <button className="dh-btn dh-btn-outline" onClick={clearDonorFilter}>
              <ArrowLeft size={16} /> All donors
            </button>
          )}
          <button className="dh-btn dh-btn-primary" onClick={openAdd}>
            <Plus size={16} /> Add Donation
          </button>
        </div>
      </div>

      <div className="dh-stats">
        <div className="dh-stat">
          <div className="dh-stat-icon red"><Droplets size={22} /></div>
          <div><span>Total Donations</span><h3>{stats.total}</h3></div>
        </div>
        <div className="dh-stat">
          <div className="dh-stat-icon blue"><Activity size={22} /></div>
          <div><span>Blood Collected</span><h3>{stats.volume} L</h3></div>
        </div>
        <div className="dh-stat">
          <div className="dh-stat-icon orange"><CalendarDays size={22} /></div>
          <div><span>This Month</span><h3>{stats.month}</h3></div>
        </div>
        <div className="dh-stat">
          <div className="dh-stat-icon green"><Users size={22} /></div>
          <div><span>Active Donors</span><h3>{stats.donors}</h3></div>
        </div>
      </div>

      <section className="dh-card">
        <div className="dh-toolbar">
          <div className="dh-search">
            <Search size={17} />
            <input
              type="text"
              placeholder="Search by donor, ID, location..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); resetPage(); }}
            />
          </div>
          <div className="dh-filters">
            <select
              value={bloodFilter}
              onChange={(e) => { setBloodFilter(e.target.value); resetPage(); }}
              aria-label="Filter by blood type"
            >
              <option value="All">All blood types</option>
              {BLOOD_TYPES.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); resetPage(); }}
              aria-label="Filter by status"
            >
              <option value="All">All status</option>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="dh-table-wrap">
          <table className="dh-table">
            <thead>
              <tr>
                <th>Record ID</th>
                <th>Donor</th>
                <th>Blood Type</th>
                <th>Donation Date</th>
                <th>Volume</th>
                <th>Location</th>
                <th>Next Eligible</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {pageRows.map((r) => (
                <tr key={r.id}>
                  <td><span className="dh-id">{r.id}</span></td>
                  <td>
                    <div className="dh-donor">
                      <div className="dh-avatar">{r.donorName.charAt(0)}</div>
                      <div>
                        <strong>{r.donorName}</strong>
                        <small>{r.donorId}</small>
                      </div>
                    </div>
                  </td>
                  <td><span className="dh-blood">{r.blood}</span></td>
                  <td>{formatDate(r.date)}</td>
                  <td>{r.volume} ml</td>
                  <td>{r.location}</td>
                  <td>{nextEligible(r)}</td>
                  <td>
                    <span className={`dh-status ${r.status.toLowerCase()}`}>
                      <i /> {r.status}
                    </span>
                  </td>
                  <td>
                    <div className="dh-actions">
                      <button title="View details" onClick={() => setViewing(r)}>
                        <Eye size={15} />
                      </button>
                      <button title="Delete" onClick={() => handleDelete(r)}>
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="dh-empty">No donation records found.</div>
          )}
        </div>

        <div className="dh-footer">
          <span>
            Showing <strong>{filtered.length === 0 ? 0 : start + 1}</strong> to{" "}
            <strong>{start + pageRows.length}</strong> of{" "}
            <strong>{filtered.length}</strong> records
          </span>
          <div className="dh-pagination">
            <button disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)}>‹</button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((n) => (
              <button
                key={n}
                className={n === currentPage ? "current" : ""}
                onClick={() => setPage(n)}
              >
                {n}
              </button>
            ))}
            <button disabled={currentPage === totalPages} onClick={() => setPage(currentPage + 1)}>›</button>
          </div>
        </div>
      </section>

      {showAdd && (
        <div className="dh-overlay" onClick={() => setShowAdd(false)}>
          <form className="dh-modal" onClick={(e) => e.stopPropagation()} onSubmit={handleSave} noValidate>
            <div className="dh-modal-head">
              <div>
                <h4>Add Donation Record</h4>
                <p>Log a new blood donation for a registered donor.</p>
              </div>
              <button type="button" className="dh-close" onClick={() => setShowAdd(false)}>×</button>
            </div>

            <div className="dh-modal-body">
              <div className="dh-grid">
                <div className="dh-field dh-span2">
                  <label>Donor</label>
                  <select value={form.donorId} onChange={(e) => setField("donorId", e.target.value)}>
                    <option value="">Select donor</option>
                    {donorsData.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.id}) – {d.blood}
                      </option>
                    ))}
                  </select>
                  {errors.donorId && <em>{errors.donorId}</em>}
                </div>

                <div className="dh-field">
                  <label>Blood Type</label>
                  <input type="text" value={selectedDonor?.blood || ""} placeholder="Auto-filled" readOnly />
                </div>

                <div className="dh-field">
                  <label>Donation Date</label>
                  <input type="date" max={todayISO()} value={form.date} onChange={(e) => setField("date", e.target.value)} />
                  {errors.date && <em>{errors.date}</em>}
                </div>

                <div className="dh-field">
                  <label>Volume</label>
                  <select value={form.volume} onChange={(e) => setField("volume", e.target.value)}>
                    <option value="350">350 ml</option>
                    <option value="450">450 ml</option>
                  </select>
                </div>

                <div className="dh-field">
                  <label>Status</label>
                  <select value={form.status} onChange={(e) => setField("status", e.target.value)}>
                    {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>

                <div className="dh-field dh-span2">
                  <label>Hospital / Camp Location</label>
                  <input
                    type="text"
                    placeholder="e.g. Civil Hospital, Ahmedabad"
                    value={form.location}
                    onChange={(e) => setField("location", e.target.value)}
                  />
                  {errors.location && <em>{errors.location}</em>}
                </div>

                <div className="dh-field dh-span2">
                  <label>Notes (optional)</label>
                  <textarea
                    rows={3}
                    placeholder="Any remarks about this donation"
                    value={form.notes}
                    onChange={(e) => setField("notes", e.target.value)}
                  />
                </div>
              </div>
            </div>

            <div className="dh-modal-foot">
              <button type="button" className="dh-btn dh-btn-outline" onClick={() => setShowAdd(false)}>Cancel</button>
              <button type="submit" className="dh-btn dh-btn-primary"><Plus size={16} /> Save Donation</button>
            </div>
          </form>
        </div>
      )}

      {viewing && (
        <div className="dh-overlay" onClick={() => setViewing(null)}>
          <div className="dh-modal dh-modal-sm" onClick={(e) => e.stopPropagation()}>
            <div className="dh-modal-head">
              <div>
                <h4>Donation {viewing.id}</h4>
                <p>{viewing.donorName} · {viewing.donorId}</p>
              </div>
              <button type="button" className="dh-close" onClick={() => setViewing(null)}>×</button>
            </div>
            <div className="dh-modal-body">
              <dl className="dh-details">
                <div><dt>Blood Type</dt><dd><span className="dh-blood">{viewing.blood}</span></dd></div>
                <div><dt>Donor City</dt><dd>{viewing.city || "—"}</dd></div>
                <div><dt>Donation Date</dt><dd>{formatDate(viewing.date)}</dd></div>
                <div><dt>Volume</dt><dd>{viewing.volume} ml</dd></div>
                <div><dt>Location</dt><dd>{viewing.location}</dd></div>
                <div><dt>Next Eligible</dt><dd>{nextEligible(viewing)}</dd></div>
                <div>
                  <dt>Status</dt>
                  <dd><span className={`dh-status ${viewing.status.toLowerCase()}`}><i /> {viewing.status}</span></dd>
                </div>
                <div className="dh-details-full"><dt>Notes</dt><dd>{viewing.notes || "No notes added."}</dd></div>
              </dl>
              <Link
                className="dh-link"
                to={`/admin/donation-history?donor=${viewing.donorId}`}
                onClick={() => { setViewing(null); resetPage(); }}
              >
                View all donations by {viewing.donorName}
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
