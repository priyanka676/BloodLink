import React from "react";
export default function Inventory() {
    return <>
        <div className="page-head"><div>
            <h1>Blood Inventory</h1>
            <p>Monitor available blood units and stock levels.</p>
        </div>
            <button className="primary">+ Update Stock</button>
        </div><section className="panel">
            <table>
                <thead>
                    <tr>
                        <th>Blood Type</th>
                        <th>Available</th>
                        <th>Reserved</th>
                        <th>Total</th>
                        <th>Stock Level</th>
                    </tr>
                </thead>
                <tbody>
                    {[["A+", "482", "44", "526", "Good"],
                    ["A-", "186", "21", "207", "Low"],
                    ["B+", "376", "31", "407", "Good"],
                    ["B-", "121", "14", "135", "Low"],
                    ["O+", "912", "75", "987", "Excellent"],
                    ["O-", "204", "26", "230", "Low"],
                    ["AB+", "348", "18", "366", "Good"],
                    ["AB-", "78", "11", "89", "Critical"]].map(r => <tr key={r[0]}>
                        {r.map((c, i) => <td key={i}>{i === 4 ?
                            <span className={`status ${c.toLowerCase()}`}>{c}</span>
                            : c}</td>
                        )}</tr>
                    )}
                </tbody>
            </table>
        </section>
    </>
}