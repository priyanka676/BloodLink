import React from "react";
export default function Requests() {
    const rows = [["REQ-1042", "Priya Shah", "O+", "2", "City Hospital", "Pending"],
    ["REQ-1041", "Priyanka Rana", "B+", "1", "Civil Hospital", "Approved"],
    ["REQ-1040", "Neha Joshi", "A-", "3", "LifeCare Hospital", "Processing"],
    ["REQ-1039", "Ravi Mehta", "AB+", "2", "City Hospital", "Completed"],
    ["REQ-1038", "Meera Shah", "O-", "1", "Civil Hospital", "Pending"]];
    return <Page title="Blood Requests" desc="Review, approve and track blood requests.">
        <Table rows={rows} heads={["Request ID", "Patient", "Blood Type", "Units", "Hospital", "Status"]} /></Page>
}
function Page({ title, desc, children }) {
    return <>
        <div className="page-head"><div>
            <h1>{title}</h1>
            <p>{desc}</p>
        </div>
        </div>
        <section className="panel">{children}</section>
    </>
}
function Table({ rows, heads }) {
    return <table>
        <thead>
            <tr>
                {heads.map(h => <th key={h}>{h}</th>)}</tr>
        </thead>
        <tbody>
            {rows.map((r, i) => <tr key={i}>{r.map((c, j) =>
                <td key={j}>{j === r.length - 1 ?
                    <span className={`status ${c.toLowerCase()}`}>{c}</span> : c}</td>)}
            </tr>)}
        </tbody>
    </table>
}