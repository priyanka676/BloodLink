import React, { useState } from "react";
export default function RequestBlood() {
    const [sent, setSent] = useState(false);
    return <>
        <div className="page-head"><div>
            <h1>Request Blood</h1>
            <p>Submit a new blood request.</p>
        </div>
        </div>
        <section className="panel form-panel">
            <div className="form-grid">
                <label>Blood Type
                    <select>
                        <option>O+</option>
                        <option>O-</option>
                        <option>A+</option>
                        <option>A-</option>
                        <option>B+</option>
                        <option>B-</option>
                        <option>AB+</option>
                        <option>AB-</option>
                    </select>
                </label>
                <label>Required Units
                    <input type="number" min="1" defaultValue="2" />
                </label>
                <label>Hospital
                    <select>
                        <option>City Hospital</option>
                        <option>Civil Hospital</option>
                        <option>LifeCare Hospital</option>
                    </select>
                </label>
                <label>Required Date
                    <input type="date" defaultValue="2026-08-25" /></label>
                <label className="full-field">Reason
                    <textarea placeholder="Enter reason for blood requirement..."></textarea>
                </label>
            </div>
            <button className="primary" onClick={() => setSent(true)}>Submit Request</button>
            {sent && <p className="success-msg">Request submitted successfully! Request ID: REQ-1043
            </p>}
        </section></>
}