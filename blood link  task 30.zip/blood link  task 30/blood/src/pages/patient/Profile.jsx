import React, { useState } from "react";

export default function Profile() {
    const [ok, setOk] = useState(false);
    return <>
        <div className="page-head">
            <div>
            <h1>My Profile</h1>
            <p>Manage your personal information.</p>
        </div></div><section className="panel form-panel">
            <div className="form-grid">
                <label>
                    Full Name
                    <input defaultValue="Rahul Patel" />
                </label>
                <label>
                    Email
                    <input type="email" defaultValue="rahul@example.com" />
                </label>
                <label>
                    Phone
                    <input defaultValue="+91 98765 43210" /></label>
                <label>Blood Type<select defaultValue="O+">
                    <option>O+</option>
                    <option>O-</option>
                    <option>A+</option>
                    <option>A-</option>
                    <option>B+</option>
                    <option>B-</option>
                    <option>AB+</option>
                    <option>AB-</option>
                </select>
                </label>
                <label className="full-field">Address
                    <textarea defaultValue="Ahmedabad, Gujarat">
                    </textarea>
                </label>
            </div>
            <button className="primary" onClick={() => { setOk(true); setTimeout(() => setOk(false), 2000) }}>Update Profile</button>
            {ok && <span className="saved">
                Profile updated successfully.
            </span>}
        </section>
    </>
}