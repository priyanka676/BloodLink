import React, { useState } from "react";
export default function SearchBlood() {
    const [type, setType] = useState("O+");
    const data = [["City Hospital", "Ahmedabad", "O+", "182", "Available"],
    ["Civil Hospital", "Ahmedabad", "O+", "96", "Available"],
    ["LifeCare Hospital", "Surat", "O+", "54", "Available"],
    ["Sunrise Hospital", "Vadodara", "O+", "12", "Low"]];
    return <>
        <div className="page-head"><div>
            <h1>Search Blood</h1>
            <p>Find available blood units by type and location.</p>
        </div>
        </div>
        <section className="panel search-panel">
            <div>
                <label>Blood Type
                </label>
                <select value={type} onChange={e => setType(e.target.value)}>
                    {["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map(x => <option key={x}>
                        {x}</option>)}
                </select>
            </div>
            <div>
                <label>City
                </label>
                <input placeholder="Enter city" defaultValue="Ahmedabad" />
            </div>
            <button className="primary">Search</button>
        </section>
        <section className="panel">
            <div className="panel-head">
                <h3>Available Hospitals for {type}</h3>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Hospital</th>
                        <th>City</th>
                        <th>Blood Type</th>
                        <th>Units</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        data.map(r => <tr key={r[0]}>
                            {r.map((c, i) =>
                                <td key={i}>{i === 4 ?
                                    <span className={`status ${c.toLowerCase()}`}>
                                        {c}</span> : c}</td>)}</tr>)}
                </tbody>
            </table>
        </section>
    </>
}