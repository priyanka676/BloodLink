import React from "react";
export default function MyRequests() {
    return <>
        <div className="page-head">
            <div>
                <h1>Donation History</h1>
                <p>Track all your blood requests.</p>
            </div>
        </div>
        <section className="panel">
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Blood Type</th>
                        <th>Units</th>
                        <th>Hospital</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {[["REQ-1042", "O+", "2", "City Hospital",
                        "24 Aug 2026", "Pending"],
                    ["REQ-1011", "O+", "1", "Civil Hospital", "18 Aug 2026", "Completed"],
                    ["REQ-0987", "O+", "2", "City Hospital"
                        , "10 Aug 2026", "Approved"]].map(r => <tr key={r[0]}>
                            {r.map((c, i) => <td key={i}>
                                {i === 5 ? <span className={`status ${c.toLowerCase()}`}>{c}</span> : c}
                            </td>)}
                        </tr>)}
                </tbody>
            </table>
        </section>
    </>
}