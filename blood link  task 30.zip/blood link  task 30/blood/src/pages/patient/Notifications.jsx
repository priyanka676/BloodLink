import React from "react";
export default function Notifications() {
    const n = [["Blood request REQ-1042 is pending approval.",
        "2 hours ago", "info"],
    ["Your request REQ-1011 was completed.",
        "Yesterday", "success"],
    ["O+ blood is available at City Hospital.",
        "2 days ago", "warning"]];
    return <>
        <div className="page-head">
            <div>
                <h1>Notifications</h1>
                <p>Stay updated with your requests and blood availability.</p>
            </div>
        </div>
        <div className="notification-list">
            {n.map(x => <div className="notification" key={x[0]}>
                <div className={`notification-dot ${x[2]}`}></div>
                <div>
                    <strong>{x[0]}</strong>
                    <p>{x[1]}</p>
                </div>
            </div>)}
        </div></>
}