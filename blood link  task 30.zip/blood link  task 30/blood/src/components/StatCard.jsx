import React from "react";

export default function StatCard({ title, value, note, icon: Icon, type="" })
 {
  return <div className="stat-card">
    <div className={`stat-icon ${type}`}>
      <Icon size={22}/>
      </div>
    <div>
      <p>{title}</p>
      <h3>{value}</h3>
      </div>
  </div>;
}