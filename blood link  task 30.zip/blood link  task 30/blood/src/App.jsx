import React, { useState } from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import Layout from "./components/Layout";
import Login from "./pages/Login";

import AdminDashboard from "./pages/admin/AdminDashboard";
import Patients from "./pages/admin/Patients";
import Donors from "./pages/admin/Donors";
import DonationHistory from "./pages/admin/DonationHistory";
import BloodTypes from "./pages/admin/BloodTypes";
import Requests from "./pages/admin/Requests";
import Inventory from "./pages/admin/Inventory";
import Hospitals from "./pages/admin/Hospitals";
import Reports from "./pages/admin/Reports";
import Settings from "./pages/admin/Settings";

import PatientDashboard from "./pages/patient/PatientDashboard";
import SearchBlood from "./pages/patient/SearchBlood";
import RequestBlood from "./pages/patient/RequestBlood";
import MyRequests from "./pages/patient/MyRequests";
import Notifications from "./pages/patient/Notifications";
import Profile from "./pages/patient/Profile";

export default function App() {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bloodlink_user")) || null; }
    catch { return null; }
  });

  const login = (role, name) => {
    const u = { role, name };
    localStorage.setItem("bloodlink_user", JSON.stringify(u));
    setUser(u);
  };

  const logout = () => {
    localStorage.removeItem("bloodlink_user");
    setUser(null);
  };

  if (!user) return <Login onLogin={login} />;

  const home = user.role === "admin" ? "/admin" : "/patient";

  return (
    <Routes>
      <Route element={<Layout user={user} onLogout={logout} />}>
        <Route path="/" element={<Navigate to={home} replace />} />

        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/admin/patients" element={<Patients />} />
        <Route path="/admin/donors" element={<Donors />} />
        <Route path="/admin/donation-history" element={<DonationHistory />} />
        <Route path="/admin/blood-types" element={<BloodTypes />} />
        <Route path="/admin/requests" element={<Requests />} />
        <Route path="/admin/inventory" element={<Inventory />} />
        <Route path="/admin/hospitals" element={<Hospitals />} />
        <Route path="/admin/reports" element={<Reports />} />
        <Route path="/admin/settings" element={<Settings />} />

        <Route path="/patient" element={<PatientDashboard />} />
        <Route path="/patient/search-blood" element={<SearchBlood />} />
        <Route path="/patient/request-blood" element={<RequestBlood />} />
        <Route path="/patient/my-requests" element={<MyRequests />} />
        <Route path="/patient/notifications" element={<Notifications />} />
        <Route path="/patient/profile" element={<Profile />} />

        <Route path="*" element={<Navigate to={home} replace />} />
      </Route>
    </Routes>
  );
}