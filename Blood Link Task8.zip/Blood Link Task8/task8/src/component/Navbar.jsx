import React from "react";
import {
  Bell,
  LogOut,
  UserCircle,
  Droplets
} from "lucide-react";

import "./Navbar.css";
export default function Navbar({ user, onLogout }) {
  return (
    <header className="navbar">
   <div className="navbar-brand">


<div className="navbar-brand-text">
  <h2 className="text-bolder">BloodLink</h2>

  <span className="nav-subtitle">
    Blood Management System
  </span>
</div>
</div>
      <div className="nav-actions">
        <button
          className="notification-btn"
          title="Notifications"
        >
          <Bell size={20} />

          <span className="notification-badge">
            3
          </span>
        </button>

        <div className="user-chip">

          <UserCircle
            size={28}
            className="user-icon"
          />

          <div className="user-info">

            <span className="user-name">
              {user?.name || "Administrator"}
            </span>

            <small className="user-role">
              {user?.role || "Admin"}
            </small>

          </div>

        </div>
        <button
          className="navbar-logout"
          onClick={onLogout}
        >
          <LogOut size={17} />
          <span>Logout</span>
        </button>

      </div>

    </header>
  );
}