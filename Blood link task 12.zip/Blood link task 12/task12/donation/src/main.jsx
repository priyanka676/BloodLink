import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const requests = [
  {
    id: "REQ-1042",
    blood: "O+",
    units: 2,
    hospital: "City Hospital",
    date: "24 Aug 2026",
    status: "Pending"
  },
  {
    id: "REQ-1011",
    blood: "O+",
    units: 1,
    hospital: "Civil Hospital",
    date: "18 Aug 2026",
    status: "Completed"
  },
  {
    id: "REQ-0987",
    blood: "AB+",
    units: 2,
    hospital: "City Hospital",
    date: "10 Aug 2026",
    status: "Approved"
  },
  {
    id: "REQ-0988",
    blood: "O",
    units: 3,
    hospital: "City Hospital",
    date: "26 Aug 2026",
    status: "Approved"
  },
  {
    id: "REQ-0989",
    blood: "AB+",
    units: 2,
    hospital: "City Hospital",
    date: "27 Aug 2026",
    status: "Approved"
  }
];

const menuItems = [
  { label: "Dashboard", icon: "▦", path: "/patient/dashboard" },
  { label: "Search Blood", icon: "⌕", path: "/patient/search-blood" },
  { label: "Request Blood", icon: "▱", path: "/patient/request-blood" },
  { label: "My Requests", icon: "▤", path: "/patient/my-requests" },
  { label: "Notifications", icon: "♧", path: "/patient/notifications" },
  { label: "Profile", icon: "♙", path: "/patient/profile" }
];

function App() {
  const [path, setPath] = useState(window.location.pathname || "/patient/my-requests");
  const [showNotifications, setShowNotifications] = useState(false);

  function navigate(newPath) {
    window.history.pushState({}, "", newPath);
    setPath(newPath);
  }

  React.useEffect(() => {
    const onPop = () => setPath(window.location.pathname);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  const current =
    menuItems.find((item) => item.path === path)?.label || "My Requests";

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-logo">
            <span>♨</span>
          </div>
          <div>
            <div className="brand-title">BloodLink</div>
            <div className="brand-subtitle">Patient Portal</div>
          </div>
        </div>

        <div className="section-title">MAIN MENU</div>

        <nav className="menu">
          {menuItems.map((item) => (
            <button
              key={item.path}
              className={`menu-item ${current === item.label ? "active" : ""}`}
              onClick={() => navigate(item.path)}
            >
              <span className="menu-icon">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="help-card">
          <div className="help-title">Need help?</div>
          <div className="help-text">
            Contact BloodLink support for assistance.
          </div>
          <button
            className="support-button"
            onClick={() => alert("BloodLink support: support@bloodlink.local")}
          >
            Contact Support
          </button>
        </div>
      </aside>

      <div className="page">
        <header className="header">
          <div className="header-brand">
            <div className="header-title">BloodLink</div>
            <div className="header-subtitle">Blood Management System</div>
          </div>

          <div className="header-right">
            <button
              className="notification-button"
              onClick={() => setShowNotifications((v) => !v)}
              aria-label="Notifications"
            >
              ♧
              <span className="notification-dot">3</span>
            </button>

            <div className="user-info">
              <div className="user-avatar">♙</div>
              <div>
                <div className="user-name">Rahul Patel</div>
                <div className="user-role">Patient</div>
              </div>
            </div>

            <button
              className="logout-button"
              onClick={() => alert("Logout clicked")}
            >
              <span>⇥</span> Logout
            </button>

            {showNotifications && (
              <div className="notification-panel">
                <strong>Notifications</strong>
                <p>Your blood request REQ-1042 is pending.</p>
                <p>REQ-0987 has been approved.</p>
              </div>
            )}
          </div>
        </header>

        <main className="content">
          <div className="heading">
            <div>
              <h1>Donation Requests</h1>
              <p>Track all your blood requests.</p>
            </div>
          </div>

          {path === "/patient/my-requests" || path === "/" ? (
            <RequestTable requests={requests} />
          ) : (
            <PlaceholderPage title={current} />
          )}
        </main>
      </div>
    </div>
  );
}

function RequestTable({ requests }) {
  return (
    <section className="card">
      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>REQUEST ID</th>
              <th>BLOOD TYPE</th>
              <th>UNITS</th>
              <th>HOSPITAL</th>
              <th>DATE</th>
              <th>STATUS</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((request) => (
              <tr key={request.id}>
                <td>{request.id}</td>
                <td>{request.blood}</td>
                <td>{request.units}</td>
                <td>{request.hospital}</td>
                <td>{request.date}</td>
                <td>
                  <span className={`status ${request.status.toLowerCase()}`}>
                    {request.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function PlaceholderPage({ title }) {
  return (
    <section className="placeholder card">
      <div className="placeholder-icon">♥</div>
      <h2>{title}</h2>
      <p>This patient portal section is ready for your content.</p>
    </section>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);