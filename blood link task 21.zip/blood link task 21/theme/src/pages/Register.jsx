import React, { useState } from "react";
import { AuthFooter } from "../components/Footer";
import { Droplets } from "lucide-react";
import { BLOOD_GROUPS, USERS_KEY, loadUsers } from "../constants";

export default function Register({ onRegistered, onBackToLogin }) {
  const [form, setForm] = useState({
    name: "", email: "", phone: "", age: "", city: "", blood: "", password: "",
  });
  const [errors, setErrors] = useState({});

  const set = (key, value) => {
    setForm(f => ({ ...f, [key]: value }));
    setErrors(e => ({ ...e, [key]: "" }));
  };

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Full name is required.";
    if (!/^\S+@\S+\.\S+$/.test(form.email)) e.email = "Enter a valid email.";
    if (!/^[+\d][\d\s-]{8,14}$/.test(form.phone.trim())) e.phone = "Enter a valid phone number.";
    const age = Number(form.age);
    if (!age || age < 18 || age > 65) e.age = "Age must be between 18 and 65.";
    if (!form.city.trim()) e.city = "City is required.";
    if (!form.blood) e.blood = "Please select your blood group.";
    if (form.password.length < 6) e.password = "Password must be at least 6 characters.";
    if (loadUsers().some(u => u.email.toLowerCase() === form.email.toLowerCase()))
      e.email = "This email is already registered.";
    return e;
  };

  const submit = ev => {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    const user = {
      name: form.name.trim(), email: form.email.trim(), phone: form.phone.trim(),
      age: Number(form.age), city: form.city.trim(), blood: form.blood, password: form.password,
    };
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify([...loadUsers(), user]));
    } catch { /* storage unavailable - continue without saving */ }
    onRegistered(user);
  };

  const field = (key, label, props = {}) => (
    <>
      <label>{label}</label>
      <input value={form[key]} onChange={e => set(key, e.target.value)} {...props} />
      {errors[key] && <span className="field-error">{errors[key]}</span>}
    </>
  );

  return <div className="login-page">
    <div className="login-card register-card">
      <div className="login-logo"><Droplets size={34} /></div>
      <h1>Create your account</h1><p>Join BloodLink and find or donate blood</p>
      <form onSubmit={submit} noValidate>
        {field("name", "Full Name", { placeholder: "Enter your full name" })}
        {field("email", "Email Address", { type: "email", placeholder: "you@example.com" })}
        {field("phone", "Phone Number", { placeholder: "+91 98765 43210" })}
        <div className="register-two">
          <div>{field("age", "Age", { type: "number", placeholder: "18 - 65" })}</div>
          <div>{field("city", "City", { placeholder: "e.g. Surat" })}</div>
        </div>

        <label>Blood Group</label>
        <div className="blood-chips" role="radiogroup" aria-label="Blood group">
          {BLOOD_GROUPS.map(bg => (
            <button
              type="button" key={bg} role="radio" aria-checked={form.blood === bg}
              className={form.blood === bg ? "chip active" : "chip"}
              onClick={() => set("blood", bg)}
            >{bg}</button>
          ))}
        </div>
        {errors.blood && <span className="field-error">{errors.blood}</span>}

        {field("password", "Password", { type: "password", placeholder: "At least 6 characters" })}
        <button className="primary full" style={{ marginTop: 14 }}>Register</button>
      </form>
      <div className="demo-note">
        Already have an account? <a href="#login" onClick={e => { e.preventDefault(); onBackToLogin(); }}>Sign in</a>
      </div>
    </div>
    <AuthFooter />
  </div>;
}
