import React from "react";
import { Link } from "react-router-dom";
import { Droplets, Phone, Mail, MapPin, Heart } from "lucide-react";

const links = {
  admin: [
    ["/admin", "Dashboard"], ["/admin/donors", "Donors"], ["/admin/inventory", "Inventory"],
    ["/admin/requests", "Requests"], ["/admin/reports", "Reports"],
  ],
  patient: [
    ["/patient", "Dashboard"], ["/patient/search-blood", "Search Blood"],
    ["/patient/request-blood", "Request Blood"], ["/patient/my-requests", "My Requests"],
    ["/patient/profile", "Profile"],
  ],
};

export default function Footer({ role }) {
  const year = new Date().getFullYear();
  const quick = links[role] || links.patient;

  return (
    <footer className="app-footer">
      <div className="footer-grid">
        <div className="footer-about">
          <div className="footer-brand">
            <span className="footer-logo"><Droplets size={20} /></span>
            <strong>BloodLink</strong>
          </div>
          <p>Connecting donors, patients and hospitals to make blood available when it matters most.</p>
        </div>

        <div>
          <h4>Quick Links</h4>
          <ul>
            {quick.map(([to, label]) => (
              <li key={to}><Link to={to}>{label}</Link></li>
            ))}
          </ul>
        </div>

        <div>
          <h4>Contact</h4>
          <ul className="footer-contact">
            <li><Phone size={14} /> <a href="tel:+911234567890">+91 12345 67890</a></li>
            <li><Mail size={14} /> <a href="mailto:support@bloodlink.com">support@bloodlink.com</a></li>
            <li><MapPin size={14} /> Gujarat, India</li>
          </ul>
        </div>

        <div className="footer-emergency">
          <h4>Emergency?</h4>
          <p>Need blood urgently? Call our 24/7 helpline.</p>
          <a className="footer-call" href="tel:+911234567890"><Phone size={15} /> Call Now</a>
        </div>
      </div>

      <div className="footer-bottom">
        <span>© {year} BloodLink. All rights reserved.</span>
        <span className="footer-made">Made with <Heart size={13} /> to save lives</span>
      </div>
    </footer>
  );
}

export function AuthFooter() {
  return (
    <footer className="auth-footer">
      <span>© {new Date().getFullYear()} BloodLink — Blood Management System</span>
      <span>
        <a href="mailto:support@bloodlink.com">support@bloodlink.com</a>
        {" · "}
        <a href="tel:+911234567890">+91 12345 67890</a>
      </span>
    </footer>
  );
}
