import React from "react";
import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Footer from "./Footer";

export default function Layout({ user, onLogout }) {
  return (
    <div className="app-shell">
      <Sidebar role={user.role} />
      <div className="main-area">
        <Navbar user={user} onLogout={onLogout} />
        <main className="content"><Outlet /></main>
        <Footer role={user.role} />
      </div>
    </div>
  );
}