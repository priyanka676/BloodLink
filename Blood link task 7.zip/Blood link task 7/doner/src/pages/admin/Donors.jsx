import React, { useMemo, useState } from "react";
import {
  LayoutDashboard, Users, HeartPulse, Droplets, ClipboardList, Hospital,
  BarChart3, Settings, Bell, UserCircle, LogOut, Plus, Search, Filter,
  MoreVertical, Edit, Trash2, Eye, X, ChevronLeft, ChevronRight
} from "lucide-react";
import "./Donor.css";

const initialDonors = [
  { id:"D-501", name:"Priyanka Rana", blood:"O+", age:26, city:"Ahmedabad", donations:12, status:"Available", phone:"9876543210", email:"priyanka@example.com" },
  { id:"D-502", name:"Devang Gohil", blood:"A+", age:29, city:"Surat", donations:8, status:"Available", phone:"9876501234", email:"devang@example.com" },
  { id:"D-503", name:"Jay Patel", blood:"B+", age:33, city:"Vadodara", donations:15, status:"Unavailable", phone:"9898989898", email:"jay@example.com" },
  { id:"D-504", name:"Nisha Rao", blood:"O-", age:27, city:"Ahmedabad", donations:5, status:"Available", phone:"9825012345", email:"nisha@example.com" },
  { id:"D-505", name:"Rahul Shah", blood:"AB+", age:31, city:"Rajkot", donations:10, status:"Available", phone:"9909012345", email:"rahul@example.com" },
  { id:"D-506", name:"Meera Patel", blood:"B-", age:25, city:"Surat", donations:6, status:"Unavailable", phone:"9812345678", email:"meera@example.com" }
];

const blank = { name:"", blood:"", age:"", city:"", phone:"", email:"", donations:0, status:"Available" };

function Donors(){
  const [donors,setDonors] = useState(() => {
    try { return JSON.parse(localStorage.getItem("bloodlink_donors")) || initialDonors; } catch { return initialDonors; }
  });
  const [search,setSearch] = useState("");
  const [bloodFilter,setBloodFilter] = useState("All");
  const [statusFilter,setStatusFilter] = useState("All");
  const [page,setPage] = useState(1);
  const [modal,setModal] = useState(null);
  const [form,setForm] = useState(blank);
  const [toast,setToast] = useState("");
  const perPage = 5;

  const save = next => { setDonors(next); localStorage.setItem("bloodlink_donors", JSON.stringify(next)); };
  const notify = msg => { setToast(msg); setTimeout(()=>setToast(""),2200); };

  const filtered = useMemo(() => donors.filter(d => {
    const q=search.trim().toLowerCase();
    const matches=!q || [d.id,d.name,d.blood,d.city,d.phone,d.email].some(v=>String(v).toLowerCase().includes(q));
    return matches && (bloodFilter==="All" || d.blood===bloodFilter) && (statusFilter==="All" || d.status===statusFilter);
  }),[donors,search,bloodFilter,statusFilter]);

  const pages=Math.max(1,Math.ceil(filtered.length/perPage));
  const current=Math.min(page,pages);
  const visible=filtered.slice((current-1)*perPage,current*perPage);
  const stats={total:donors.length,available:donors.filter(d=>d.status==="Available").length,donations:donors.reduce((a,d)=>a+Number(d.donations||0),0)};

  const openAdd=()=>{setForm(blank);setModal("add")};
  const openEdit=d=>{setForm({...d});setModal("edit")};
  const submit=e=>{
    e.preventDefault();
    if(!form.name || !form.blood || !form.age || !form.city || !form.phone || !form.email){notify("Please fill all fields.");return;}
    if(modal==="add"){
      const nextId=`D-${500+donors.length+1}`;
      save([{...form,id:nextId,age:Number(form.age),donations:Number(form.donations||0)},...donors]);
      notify("Donor added successfully.");
    }else{
      save(donors.map(d=>d.id===form.id?{...form,age:Number(form.age),donations:Number(form.donations||0)}:d));
      notify("Donor updated successfully.");
    }
    setModal(null);
  };
  const remove=id=>{if(confirm("Are you sure you want to delete this donor?")){save(donors.filter(d=>d.id!==id));notify("Donor deleted successfully.");}};
  const toggle=id=>{save(donors.map(d=>d.id===id?{...d,status:d.status==="Available"?"Unavailable":"Available"}:d));};
  const reset=()=>{if(confirm("Restore demo donor data?")){save(initialDonors);setPage(1);notify("Demo data restored.");}};

  return <div className="bloodlink-wrapper">
    <aside className="blood-sidebar">
      <div className="brand-area"><div className="brand-logo"><Droplets size={21}/></div><div className="brand-text"><h4>BloodLink</h4><span>Life Saving Network</span></div></div>
      <div className="menu-title">MAIN MENU</div>
      <ul className="sidebar-menu">
        <li><a href="#"><LayoutDashboard size={16}/><span>Dashboard</span></a></li>
        <li className="active"><a href="#donors"><Users size={16}/><span>Donors</span></a></li>
        <li><a href="#"><HeartPulse size={16}/><span>Blood Requests</span></a></li>
        <li><a href="#"><Hospital size={16}/><span>Hospitals</span></a></li>
        <li><a href="#"><BarChart3 size={16}/><span>Reports</span></a></li>
        <li><a href="#"><Settings size={16}/><span>Settings</span></a></li>
      </ul>
      <div className="help-box"><h6>Need help?</h6><p>Manage donors and blood requests from one place.</p><button>Contact Support</button></div>
    </aside>

    <main className="blood-main">
      <header className="top-header"><div className="header-title"><h5>Donor Management</h5><span>BloodLink / Donors</span></div><div className="header-right"><div className="notification"><Bell size={18}/><span>3</span></div><div className="admin-profile"><UserCircle size={28}/><div><strong>Admin</strong><small>Administrator</small></div></div><button className="logout-btn"><LogOut size={14}/> Logout</button></div></header>
      <section className="content-area" id="donors">
        <div className="page-heading"><div><h2>Donors</h2><p>View and manage registered blood donors.</p></div><div className="heading-actions"><button className="reset-btn" onClick={reset}>Reset Demo</button><button className="add-donor-btn" onClick={openAdd}><Plus size={17}/>Add Donor</button></div></div>
        <div className="donor-stats">
          <div className="stat-card"><div className="stat-icon red"><Users size={22}/></div><div><span>Total Donors</span><h3>{stats.total}</h3></div></div>
          <div className="stat-card"><div className="stat-icon green"><HeartPulse size={22}/></div><div><span>Available</span><h3>{stats.available}</h3></div></div>
          <div className="stat-card"><div className="stat-icon blue"><Droplets size={22}/></div><div><span>Total Donations</span><h3>{stats.donations.toLocaleString()}</h3></div></div>
          <div className="stat-card"><div className="stat-icon orange"><ClipboardList size={22}/></div><div><span>This Month</span><h3>{Math.min(stats.donations,42)}</h3></div></div>
        </div>
        <div className="donor-card">
          <div className="table-toolbar"><div className="search-box"><Search size={17}/><input placeholder="Search donor..." value={search} onChange={e=>{setSearch(e.target.value);setPage(1)}}/></div><div className="filters"><select value={bloodFilter} onChange={e=>{setBloodFilter(e.target.value);setPage(1)}}><option>All</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>AB+</option><option>AB-</option><option>O+</option><option>O-</option></select><select value={statusFilter} onChange={e=>{setStatusFilter(e.target.value);setPage(1)}}><option>All</option><option>Available</option><option>Unavailable</option></select><button className="filter-btn"><Filter size={16}/>Filter</button></div></div>
          <div className="table-responsive"><table className="donor-table"><thead><tr><th>ID</th><th>DONOR</th><th>BLOOD TYPE</th><th>AGE</th><th>CITY</th><th>DONATIONS</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody>{visible.map(d=><tr key={d.id}><td><span className="donor-id">{d.id}</span></td><td><div className="donor-name"><div className="donor-avatar">{d.name.charAt(0)}</div><div><strong>{d.name}</strong><small>Blood Donor</small></div></div></td><td><span className="blood-badge">{d.blood}</span></td><td>{d.age}</td><td>{d.city}</td><td><strong className="donation-count">{d.donations}</strong></td><td><button className={`status ${d.status.toLowerCase()}`} onClick={()=>toggle(d.id)}><span className="status-dot"></span>{d.status}</button></td><td><div className="action-buttons"><button title="View" onClick={()=>setModal(d)}><Eye size={15}/></button><button title="Edit" onClick={()=>openEdit(d)}><Edit size={15}/></button><button title="Delete" onClick={()=>remove(d.id)}><Trash2 size={15}/></button><button title="More"><MoreVertical size={15}/></button></div></td></tr>)}</tbody></table>{!visible.length&&<div className="no-data">No donors found.</div>}</div>
          <div className="table-footer"><span>Showing <strong>{filtered.length?((current-1)*perPage+1):0}</strong> to <strong>{Math.min(current*perPage,filtered.length)}</strong> of <strong>{filtered.length}</strong> donors</span><div className="pagination"><button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={current===1}><ChevronLeft size={14}/></button>{Array.from({length:pages},(_,i)=>i+1).slice(0,5).map(p=><button key={p} className={current===p?"current":""} onClick={()=>setPage(p)}>{p}</button>)}<button onClick={()=>setPage(p=>Math.min(pages,p+1))} disabled={current===pages}><ChevronRight size={14}/></button></div></div>
        </div>
      </section>
    </main>

    {(modal==="add"||modal==="edit")&&<div className="modal-overlay" onMouseDown={()=>setModal(null)}><form className="donor-modal" onSubmit={submit} onMouseDown={e=>e.stopPropagation()}><div className="modal-header"><div><h4>{modal==="add"?"Add New Donor":"Edit Donor"}</h4><p>{modal==="add"?"Register a new blood donor.":"Update donor information."}</p></div><button type="button" className="close-modal" onClick={()=>setModal(null)}><X size={16}/></button></div><div className="modal-body"><div className="form-grid">{[["Full Name","name","text","Enter donor name"],["Age","age","number","Enter age"],["City","city","text","Enter city"],["Phone Number","phone","tel","Enter phone number"],["Email","email","email","Enter email"]].map(([label,key,type,placeholder])=><div className="form-group" key={key}><label>{label}</label><input required type={type} placeholder={placeholder} value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})}/></div>)}<div className="form-group"><label>Blood Type</label><select required value={form.blood} onChange={e=>setForm({...form,blood:e.target.value})}><option value="">Select blood type</option>{["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(x=><option key={x}>{x}</option>)}</select></div><div className="form-group"><label>Previous Donations</label><input type="number" min="0" value={form.donations} onChange={e=>setForm({...form,donations:e.target.value})}/></div><div className="form-group"><label>Status</label><select value={form.status} onChange={e=>setForm({...form,status:e.target.value})}><option>Available</option><option>Unavailable</option></select></div></div></div><div className="modal-footer"><button type="button" className="cancel-btn" onClick={()=>setModal(null)}>Cancel</button><button className="save-btn" type="submit">{modal==="add"?<Plus size={16}/>:<Edit size={15}/>} {modal==="add"?"Add Donor":"Save Changes"}</button></div></form></div>}

    {modal && modal!=="add" && modal!=="edit" && <div className="modal-overlay" onMouseDown={()=>setModal(null)}><div className="donor-modal detail-modal" onMouseDown={e=>e.stopPropagation()}><div className="modal-header"><div><h4>Donor Details</h4><p>Complete donor information.</p></div><button className="close-modal" onClick={()=>setModal(null)}><X size={16}/></button></div><div className="detail-profile"><div className="detail-avatar">{modal.name.charAt(0)}</div><div><h3>{modal.name}</h3><span className={`status ${modal.status.toLowerCase()}`}><span className="status-dot"></span>{modal.status}</span></div></div><div className="detail-grid"><div><small>Donor ID</small><strong>{modal.id}</strong></div><div><small>Blood Type</small><strong>{modal.blood}</strong></div><div><small>Age</small><strong>{modal.age}</strong></div><div><small>City</small><strong>{modal.city}</strong></div><div><small>Phone</small><strong>{modal.phone}</strong></div><div><small>Email</small><strong>{modal.email}</strong></div><div><small>Donations</small><strong>{modal.donations}</strong></div></div><div className="modal-footer"><button className="cancel-btn" onClick={()=>setModal(null)}>Close</button><button className="save-btn" onClick={()=>openEdit(modal)}><Edit size={15}/> Edit Donor</button></div></div></div>}
    {toast&&<div className="toast">✓ {toast}</div>}
  </div>
}
export default Donors;
