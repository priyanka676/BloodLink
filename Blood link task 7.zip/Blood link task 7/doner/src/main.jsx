import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import Donors from "./pages/admin/Donors";
import "./pages/admin/Donor.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <Donors />
    </BrowserRouter>
  </React.StrictMode>
);
