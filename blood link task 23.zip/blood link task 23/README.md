# Blood Link

React + Vite project.

## Run
    npm install
    npm run dev

Open the URL shown (usually http://localhost:5173).

## Routes
- /              Home
- /login         Login (animated)
- /register      3-step Register form with CSS3 animated transitions
- /forgot-password   3-step password reset (email -> 6-digit code -> new password)
- /blog-detail   Blog details page

## Notes
- Register/Login submit handlers have TODO comments: connect your real API there.
- Your original admin/ and patient/ pages were not included (the .rar could not be extracted here).
  Copy them into src/pages/ and add routes in src/App.jsx.
