import { useState } from 'react'
import { Link } from 'react-router-dom'
import FormInput from '../components/FormInput.jsx'
import './Register.css'

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
const ROLES = [
  { value: 'donor', label: 'Donor' },
  { value: 'patient', label: 'Patient' },
]

const initial = {
  role: 'donor', fullName: '', email: '', phone: '', bloodGroup: '',
  city: '', password: '', confirmPassword: '',
}

function validateField(name, v, all) {
  switch (name) {
    case 'fullName':
      return v.trim().length < 3 ? 'Enter your full name (min 3 characters).' : ''
    case 'email':
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? '' : 'Enter a valid email address.'
    case 'phone':
      return /^[0-9]{10}$/.test(v) ? '' : 'Enter a 10-digit mobile number.'
    case 'bloodGroup':
      return v ? '' : 'Select your blood group.'
    case 'city':
      return v.trim() ? '' : 'Enter your city.'
    case 'password':
      return v.length >= 8 && /\d/.test(v) && /[A-Za-z]/.test(v)
        ? '' : 'Use at least 8 characters with letters and a number.'
    case 'confirmPassword':
      return v === all.password ? '' : 'Passwords do not match.'
    default:
      return ''
  }
}

export default function Register() {
  const [form, setForm] = useState(initial)
  const [errors, setErrors] = useState({})
  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    const next = { ...form, [name]: value }
    setForm(next)
    if (errors[name] !== undefined) {
      setErrors((p) => ({ ...p, [name]: validateField(name, value, next) }))
    }
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    setErrors((p) => ({ ...p, [name]: validateField(name, value, form) }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const all = {}
    Object.keys(initial).forEach((k) => {
      if (k !== 'role') all[k] = validateField(k, form[k], form)
    })
    setErrors(all)
    if (Object.values(all).some(Boolean)) return

    // TODO: replace with your API call, e.g. fetch('/api/register', {...})
    console.log('Registering:', form)
    setSubmitted(true)
  }

  // Props shared by every field, so each FormInput below stays one line.
  const bind = (name) => ({
    name, value: form[name], onChange: handleChange, onBlur: handleBlur, error: errors[name],
  })

  if (submitted) {
    return (
      <main className="reg-page">
        <div className="reg-card reg-success">
          <h1>You're registered, {form.fullName.split(' ')[0]}.</h1>
          <p>Your {form.role} account for blood group {form.bloodGroup} is ready.</p>
          <Link className="reg-btn" to="/login">Go to login</Link>
        </div>
      </main>
    )
  }

  return (
    <main className="reg-page">
      <form className="reg-card" onSubmit={handleSubmit} noValidate>
        <header className="reg-head">
          <h1>Create your Blood Link account</h1>
          <p>Donors and patients register here.</p>
        </header>

        <div className="reg-grid">
          <FormInput label="I am a" type="select" required options={ROLES}
            name="role" value={form.role} onChange={handleChange} />
          <FormInput label="Blood group" type="select" required options={BLOOD_GROUPS}
            placeholder="Choose group" {...bind('bloodGroup')} />

          <div className="reg-full">
            <FormInput label="Full name" required placeholder="e.g. Riya Patel"
              autoComplete="name" {...bind('fullName')} />
          </div>

          <FormInput label="Email" type="email" required placeholder="you@example.com"
            autoComplete="email" {...bind('email')} />
          <FormInput label="Mobile number" type="tel" required placeholder="10 digits"
            maxLength={10} inputMode="numeric" {...bind('phone')} />

          <div className="reg-full">
            <FormInput label="City" required placeholder="e.g. Surat" {...bind('city')} />
          </div>

          <FormInput label="Password" type="password" required autoComplete="new-password"
            hint="8+ characters, letters and a number." {...bind('password')} />
          <FormInput label="Confirm password" type="password" required
            autoComplete="new-password" {...bind('confirmPassword')} />
        </div>

        <button type="submit" className="reg-btn">Create account</button>
        <p className="reg-foot">
          Already registered? <Link to="/login">Log in</Link>
        </p>
      </form>
    </main>
  )
}
