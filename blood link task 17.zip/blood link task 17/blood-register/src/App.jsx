import { Routes, Route, Navigate, Link } from 'react-router-dom'
import Register from './pages/Register.jsx'

// Placeholder – replace with your existing Login page.
const Login = () => (
  <div style={{ padding: 40, fontFamily: 'sans-serif' }}>
    Login page placeholder. <Link to="/register">Create an account</Link>
  </div>
)

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/register" replace />} />
      <Route path="/register" element={<Register />} />
      <Route path="/login" element={<Login />} />
    </Routes>
  )
}
