import { useState } from 'react'
import './FormInput.css'

/**
 * Reusable form field.
 * Props:
 *  label, name, type ("text" | "email" | "password" | "tel" | "select" | "textarea" ...)
 *  value, onChange, onBlur, placeholder
 *  options   – for type="select": [{ value, label }] or ["A+", "B+"]
 *  error     – error message string (shows red state)
 *  hint      – helper text under the field
 *  required  – shows asterisk
 *  ...rest   – any other native attribute (maxLength, autoComplete, etc.)
 */
export default function FormInput({
  label,
  name,
  type = 'text',
  value,
  onChange,
  onBlur,
  placeholder,
  options = [],
  error,
  hint,
  required = false,
  ...rest
}) {
  const [show, setShow] = useState(false)
  const id = `field-${name}`
  const describedBy = error ? `${id}-error` : hint ? `${id}-hint` : undefined
  const common = {
    id,
    name,
    value,
    onChange,
    onBlur,
    placeholder,
    required,
    'aria-invalid': !!error,
    'aria-describedby': describedBy,
    className: `fi-control${error ? ' fi-control--error' : ''}`,
    ...rest,
  }

  let control
  if (type === 'select') {
    control = (
      <select {...common}>
        <option value="">{placeholder || 'Select…'}</option>
        {options.map((o) => {
          const opt = typeof o === 'string' ? { value: o, label: o } : o
          return (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          )
        })}
      </select>
    )
  } else if (type === 'textarea') {
    control = <textarea rows={3} {...common} />
  } else if (type === 'password') {
    // Password field with a show / hide toggle
    control = (
      <div className="fi-pw">
        <input type={show ? 'text' : 'password'} {...common}
          className={`${common.className} fi-pw-input`} />
        <button type="button" className="fi-pw-toggle"
          onClick={() => setShow((s) => !s)}
          aria-label={show ? 'Hide password' : 'Show password'}
          aria-pressed={show}>
          {show ? (
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
              <line x1="1" y1="1" x2="23" y2="23" />
            </svg>
          ) : (
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
          )}
        </button>
      </div>
    )
  } else {
    control = <input type={type} {...common} />
  }

  return (
    <div className="fi-field">
      <label htmlFor={id} className="fi-label">
        {label}
        {required && <span className="fi-req"> *</span>}
      </label>
      {control}
      {error ? (
        <p id={`${id}-error`} className="fi-error" role="alert">{error}</p>
      ) : hint ? (
        <p id={`${id}-hint`} className="fi-hint">{hint}</p>
      ) : null}
    </div>
  )
}
