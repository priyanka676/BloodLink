# Blood Link – Registration page

## Run standalone
    npm install
    npm run dev          # open http://localhost:5173

## Add to your existing Blood Link project
1. Copy `src/components/FormInput.jsx` + `FormInput.css` into `blood/src/components/`
2. Copy `src/pages/Register.jsx` + `Register.css` into `blood/src/pages/`
3. If you don't have react-router-dom: `npm i react-router-dom`
4. In your App.jsx add:
       import Register from './pages/Register.jsx'
       <Route path="/register" element={<Register />} />
5. Replace the `console.log` in Register.jsx `handleSubmit` with your API call.

## Using FormInput elsewhere
    <FormInput label="Email" name="email" type="email" value={v} onChange={fn} error={err} />
    <FormInput label="Group" name="bg" type="select" options={['A+','B+']} value={v} onChange={fn} />

Password fields (`type="password"`) automatically include a show/hide eye toggle.
