import React from "react";
export default function Donors() {
    const rows = [["D-501", "Harsh Vyas", "O+", "26", "Ahmedabad", "12", "Available"],
    ["D-502", "priya mishra", "A+", "29", "Surat", "8", "Available"],
    ["D-503", "Jay Patel", "B+", "33", "Vadodara", "15", "Unavailable"],
    ["D-504", "Nisha Rao", "O-", "27", "Ahmedabad", "5", "Available"]];
    return <Page title="Donors" desc="View and manage registered blood donors.">
        <Table rows={rows} heads={["ID", "Name", "Blood Type", "Age", "City", "Donations", "Status"]} />
    </Page>
}
function Page({ title, desc, children }) { return <><div className="page-head"><div><h1>{title}</h1><p>{desc}</p></div><button className="primary">+ Add Donor</button></div><section className="panel">{children}</section></> }
function Table({ rows, heads }) {
    return <table>
        <thead>
            <tr>
                {heads.map(h => <th key={h}>{h}</th>)}</tr>
        </thead>
        <tbody>
            {rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{j === r.length - 1
                ? <span className={`status ${String(c).toLowerCase()}`}>{c}</span> : c}</td>)}
            </tr>)}
        </tbody>
    </table>
}