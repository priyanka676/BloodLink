import React from "react";
import { Bell, LogOut, UserCircle } from "lucide-react";

export default function Navbar({ user, onLogout }) {
  return (
    <header className="navbar">
      <div>
        <h2>BloodLink</h2>
        <span className="nav-subtitle">Blood Management System</span>
      </div>
      <div className="nav-actions">
        <button className="icon-btn" title="Notifications"><Bell size={19}/><span className="badge">3</span></button>
        <div className="user-chip"><UserCircle size={28}/><span>{user.name}</span><small>{user.role}</small></div>
        <button className="logout-btn" onClick={onLogout}><LogOut size={17}/> Logout</button>
      </div>
    </header>
  );
}