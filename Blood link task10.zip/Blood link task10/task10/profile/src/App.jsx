import React, { useState } from "react";
import {
  Bell,
  ChevronDown,
  ClipboardList,
  Droplets,
  Grid2x2,
  LogOut,
  Menu,
  Search,
  User,
  X,
} from "lucide-react";
import "./Profile.css";
import { BrowserRouter, NavLink, Route, Routes, useNavigate } from "react-router-dom";

const defaultProfile = {
  fullName: "Rahul Patel",
  email: "rahul@example.com",
  phone: "+91 98765 43210",
  bloodType: "O+",
  address: "Ahmedabad, Gujarat",
};

function PatientLayout() {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem("bloodlink_profile");
    return saved ? JSON.parse(saved) : defaultProfile;
  });

  const [form, setForm] = useState(profile);
  const [message, setMessage] = useState("");

  const updateField = (e) => {
    const { name, value } = e.target;
    setForm((old) => ({ ...old, [name]: value }));
  };

  const handleUpdate = (e) => {
    e.preventDefault();
    localStorage.setItem("bloodlink_profile", JSON.stringify(form));
    setProfile(form);
    setMessage("Profile updated successfully.");
    setTimeout(() => setMessage(""), 3000);
  };

  const logout = () => {
    localStorage.removeItem("bloodlink_profile");
    navigate("/patient/profile");
  };

  const navItems = [
    { label: "Dashboard", icon: Grid2x2, path: "/patient/dashboard" },
    { label: "Search Blood", icon: Search, path: "/patient/search-blood" },
    { label: "Request Blood", icon: ClipboardList, path: "/patient/request-blood" },
    { label: "My Requests", icon: ClipboardList, path: "/patient/requests" },
    { label: "Notifications", icon: Bell, path: "/patient/notifications" },
    { label: "Profile", icon: User, path: "/patient/profile" },
  ];

  return (
    <div className="bloodlink-app">
      <aside className={`sidebar ${sidebarOpen ? "sidebar-open" : ""}`}>
        <div className="brand-area">
          <div className="brand-icon">
            <Droplets size={28} strokeWidth={2.3} />
          </div>
          <div>
            <div className="brand-name">BloodLink</div>
            <div className="brand-subtitle">Patient Portal</div>
          </div>
          <button
            className="mobile-close"
            onClick={() => setSidebarOpen(false)}
            aria-label="Close menu"
          >
            <X size={22} />
          </button>
        </div>

        <div className="menu-title">MAIN MENU</div>

        <nav className="sidebar-nav">
          {navItems.map(({ label, icon: Icon, path }) => (
            <NavLink
              key={label}
              to={path}
              className={({ isActive }) =>
                `sidebar-link ${isActive ? "active" : ""}`
              }
              onClick={() => setSidebarOpen(false)}
            >
              <Icon size={20} strokeWidth={1.8} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="support-box">
          <strong>Need help?</strong>
          <p>Contact BloodLink support for assistance.</p>
          <button onClick={() => alert("BloodLink support: support@bloodlink.com")}>
            Contact Support
          </button>
        </div>
      </aside>

      {sidebarOpen && (
        <div
          className="sidebar-overlay"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <main className="main-area">
        <header className="topbar">
          <button
            className="mobile-menu"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={25} />
          </button>

          <div className="topbar-brand">
            <div className="topbar-title">BloodLink</div>
            <div className="topbar-subtitle">Blood Management System</div>
          </div>

          <div className="topbar-right">
            <button className="icon-button notification-button" aria-label="Notifications">
              <Bell size={22} />
              <span className="notification-dot">3</span>
            </button>

            <div className="user-info">
              <div className="user-avatar">
                <User size={21} />
              </div>
              <div className="user-text">
                <strong>{profile.fullName}</strong>
                <span>Patient</span>
              </div>
              <ChevronDown size={16} className="user-chevron" />
            </div>

            <button className="logout-button" onClick={logout}>
              <LogOut size={17} />
              <span>Logout</span>
            </button>
          </div>
        </header>

        <section className="page-content">
          <Routes>
            <Route
              path="*"
              element={
                <ProfilePage
                  form={form}
                  updateField={updateField}
                  handleUpdate={handleUpdate}
                  message={message}
                />
              }
            />
          </Routes>
        </section>
      </main>
    </div>
  );
}

function ProfilePage({ form, updateField, handleUpdate, message }) {
  return (
    <div className="profile-page">
      <div className="page-heading">
        <h1>My Profile</h1>
        <p>Manage your personal information.</p>
      </div>

      {message && <div className="success-message">{message}</div>}

      <form className="profile-card" onSubmit={handleUpdate}>
        <div className="form-grid">
          <div className="field">
            <label htmlFor="fullName">Full Name</label>
            <input
              id="fullName"
              name="fullName"
              type="text"
              value={form.fullName}
              onChange={updateField}
              required
            />
          </div>

          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={form.email}
              onChange={updateField}
              required
            />
          </div>

          <div className="field">
            <label htmlFor="phone">Phone</label>
            <input
              id="phone"
              name="phone"
              type="tel"
              value={form.phone}
              onChange={updateField}
              required
            />
          </div>

          <div className="field">
            <label htmlFor="bloodType">Blood Type</label>
            <select
              id="bloodType"
              name="bloodType"
              value={form.bloodType}
              onChange={updateField}
              required
            >
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>

          <div className="field field-full">
            <label htmlFor="address">Address</label>
            <textarea
              id="address"
              name="address"
              value={form.address}
              onChange={updateField}
              rows="4"
              required
            />
          </div>
        </div>

        <button type="submit" className="update-button">
          Update Profile
        </button>
      </form>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <PatientLayout />
    </BrowserRouter>
  );
}