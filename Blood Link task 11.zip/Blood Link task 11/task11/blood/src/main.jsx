import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const initialInventory = [
  { type: "A+", available: 482, reserved: 44, level: "Good" },
  { type: "A-", available: 186, reserved: 21, level: "Low" },
  { type: "B+", available: 376, reserved: 31, level: "Good" },
  { type: "B-", available: 121, reserved: 14, level: "Low" },
  { type: "O+", available: 912, reserved: 75, level: "Excellent" },
  { type: "O-", available: 204, reserved: 26, level: "Low" },
  { type: "AB+", available: 348, reserved: 18, level: "Good" },
  { type: "AB-", available: 78, reserved: 11, level: "Critical" }
];

const menu = [
  ["▦", "Dashboard"],
  ["♙", "Patients"],
  ["♡", "Donors"],
  ["◉", "Blood Types"],
  ["▣", "Requests"],
  ["◇", "Inventory"],
  ["▥", "Hospitals"],
  ["▥", "Reports"],
  ["⚙", "Settings"]
];

function App() {
  const [inventory, setInventory] = useState(initialInventory);
  const [active, setActive] = useState("Inventory");
  const [showModal, setShowModal] = useState(false);
  const [selectedType, setSelectedType] = useState("A+");
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");

  const updateStock = (e) => {
    e.preventDefault();
    const units = Number(amount);
    if (!units || units < 1) {
      setMessage("Please enter a valid number of units.");
      return;
    }

    setInventory((rows) =>
      rows.map((row) =>
        row.type === selectedType
          ? { ...row, available: row.available + units }
          : row
      )
    );
    setMessage(`${units} units added to ${selectedType} stock.`);
    setAmount("");
    setTimeout(() => {
      setShowModal(false);
      setMessage("");
    }, 700);
  };

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">♨</div>
          <div>
            <div className="brand-name">BloodLink</div>
            <div className="brand-sub">Admin Portal</div>
          </div>
        </div>

        <div className="menu-title">MAIN MENU</div>
        <nav>
          {menu.map(([icon, label]) => (
            <button
              key={label}
              className={`menu-item ${active === label ? "active" : ""}`}
              onClick={() => setActive(label)}
            >
              <span className="menu-icon">{icon}</span>
              <span>{label}</span>
            </button>
          ))}
        </nav>

        <div className="help-box">
          <strong>Need help?</strong>
          <p>Contact BloodLink support for assistance.</p>
          <button>Contact Support</button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <h1>BloodLink</h1>
            <p>Blood Management System</p>
          </div>
          <div className="top-actions">
            <button className="notification" aria-label="Notifications">♧<span>3</span></button>
            <div className="admin">
              <div className="user-circle">♙</div>
              <div>
                <strong>Administrator</strong>
                <small>Admin</small>
              </div>
            </div>
            <button className="logout" onClick={() => alert("Logout clicked")}>⇥ &nbsp; Logout</button>
          </div>
        </header>

        <section className="content">
          <div className="page-heading">
            <div>
              <h2>Blood Stocks</h2>
              <p>Monitor available blood units and stock levels.</p>
            </div>
            <button className="stock-btn" onClick={() => setShowModal(true)}>+ Update Stock</button>
          </div>

          <div className="table-card">
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>BLOOD TYPE</th>
                    <th>AVAILABLE</th>
                    <th>RESERVED</th>
                    <th>TOTAL</th>
                    <th>STOCK LEVEL</th>
                  </tr>
                </thead>
                <tbody>
                  {inventory.map((row) => (
                    <tr key={row.type}>
                      <td>{row.type}</td>
                      <td>{row.available}</td>
                      <td>{row.reserved}</td>
                      <td>{row.available + row.reserved}</td>
                      <td>
                        <span className={`badge ${row.level.toLowerCase()}`}>
                          {row.level}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>

      {showModal && (
        <div className="modal-backdrop" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <h3>Update Blood Stock</h3>
              <button onClick={() => setShowModal(false)}>×</button>
            </div>
            <form onSubmit={updateStock}>
              <label>Blood Type</label>
              <select value={selectedType} onChange={(e) => setSelectedType(e.target.value)}>
                {inventory.map((r) => <option key={r.type}>{r.type}</option>)}
              </select>

              <label>Add Units</label>
              <input
                type="number"
                min="1"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter units"
              />

              {message && <div className="form-message">{message}</div>}

              <div className="modal-actions">
                <button type="button" className="cancel" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="stock-btn">Update Stock</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);