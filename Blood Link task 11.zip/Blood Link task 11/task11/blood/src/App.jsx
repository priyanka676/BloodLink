import { useState } from 'react'
import heroImg from './assets/hero.png'
import reactLogo from './assets/react.svg'
import viteLogo from './assets/vite.svg'
import './App.css'

function App() {
  const initialInventory = [
  { type: "A+", available: 482, reserved: 44, level: "Good" },
  { type: "A-", available: 186, reserved: 21, level: "Low" },
  { type: "B+", available: 376, reserved: 31, level: "Good" },
  { type: "B-", available: 121, reserved: 14, level: "Low" },
  { type: "O+", available: 912, reserved: 75, level: "Excellent" },
  { type: "O-", available: 204, reserved: 26, level: "Low" },
  { type: "AB+", available: 348, reserved: 18, level: "Good" },
  { type: "AB-", available: 78, reserved: 11, level: "Critical" }
];

const menu = [
  ["▦", "Dashboard"],
  ["♙", "Patients"],
  ["♡", "Donors"],
  ["◉", "Blood Types"],
  ["▣", "Requests"],
  ["◇", "Inventory"],
  ["▥", "Hospitals"],
  ["▥", "Reports"],
  ["⚙", "Settings"]
];


  return (
    <>
      
    </>
  )
}

export default App
