import { useState } from "react";

/* Shared donor data + helpers (stored in the browser's localStorage).
   Replace these with API calls when you connect a backend. */

export const STORAGE_KEY = "bloodlink_donor_profile";
export const APPT_KEY = "bloodlink_donor_appointment";

export const DEFAULT_PROFILE = {
  donorId: "D-501",
  fullName: "Priyanka Rana",
  email: "priyanka@example.com",
  phone: "+91 98765 11223",
  dob: "1999-06-18",
  gender: "Female",
  bloodType: "O+",
  weight: "58",
  hemoglobin: "13.2",
  city: "Ahmedabad",
  state: "Gujarat",
  pincode: "380015",
  address: "Satellite, Ahmedabad, Gujarat",
  lastDonation: "2026-05-10",
  totalDonations: 12,
  available: true,
  contactPref: "Phone",
  travelKm: "15",
  conditions: "",
  medications: "",
  emergencyName: "",
  emergencyPhone: "",
  avatar: ""
};

/* Past donations shown on the "My Donations" page (sample data) */
export const DONATION_HISTORY = [
  { ref: "DON-210510", date: "2026-05-10", hospital: "City Hospital", units: 1, status: "Completed" },
  { ref: "DON-210112", date: "2026-01-12", hospital: "Civil Hospital", units: 1, status: "Completed" },
  { ref: "DON-250920", date: "2025-09-20", hospital: "LifeCare Hospital", units: 1, status: "Completed" },
  { ref: "DON-250518", date: "2025-05-18", hospital: "City Hospital", units: 1, status: "Completed" },
  { ref: "DON-250124", date: "2025-01-24", hospital: "Civil Hospital", units: 1, status: "Completed" }
];

/* Open blood requests donors can respond to (sample data) */
export const BLOOD_REQUESTS = [
  { id: "REQ-1042", patient: "Priya Shah", blood: "O+", units: 2, hospital: "City Hospital", city: "Ahmedabad", urgency: "Critical", needBy: "2026-10-10" },
  { id: "REQ-1041", patient: "Amit Desai", blood: "B+", units: 1, hospital: "Civil Hospital", city: "Ahmedabad", urgency: "High", needBy: "2026-10-12" },
  { id: "REQ-1040", patient: "Neha Joshi", blood: "A-", units: 3, hospital: "LifeCare Hospital", city: "Surat", urgency: "Medium", needBy: "2026-10-15" },
  { id: "REQ-1039", patient: "Ravi Mehta", blood: "AB+", units: 2, hospital: "City Hospital", city: "Vadodara", urgency: "High", needBy: "2026-10-14" },
  { id: "REQ-1038", patient: "Meera Shah", blood: "O-", units: 1, hospital: "Civil Hospital", city: "Ahmedabad", urgency: "Critical", needBy: "2026-10-09" },
  { id: "REQ-1037", patient: "Karan Patel", blood: "A+", units: 2, hospital: "LifeCare Hospital", city: "Rajkot", urgency: "Medium", needBy: "2026-10-20" }
];

/* Which recipient blood types a donor can give to */
const CAN_GIVE_TO = {
  "O-": ["O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+"],
  "O+": ["O+", "A+", "B+", "AB+"],
  "A-": ["A-", "A+", "AB-", "AB+"],
  "A+": ["A+", "AB+"],
  "B-": ["B-", "B+", "AB-", "AB+"],
  "B+": ["B+", "AB+"],
  "AB-": ["AB-", "AB+"],
  "AB+": ["AB+"]
};
export const canDonateTo = (donorType, recipientType) => (CAN_GIVE_TO[donorType] || []).includes(recipientType);

export function loadProfile() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved ? { ...DEFAULT_PROFILE, ...saved } : DEFAULT_PROFILE;
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function loadAppointment() {
  try {
    const a = JSON.parse(localStorage.getItem(APPT_KEY));
    return a && new Date(a.date + "T23:59:59") >= new Date() ? a : null;
  } catch {
    return null;
  }
}

/* React hook: the donor's upcoming donation appointment (shared across pages) */
export function useAppointment() {
  const [appt, setAppt] = useState(loadAppointment);
  const book = (a) => {
    try { localStorage.setItem(APPT_KEY, JSON.stringify(a)); } catch { /* storage full */ }
    setAppt(a);
  };
  const cancel = () => {
    try { localStorage.removeItem(APPT_KEY); } catch { /* ignore */ }
    setAppt(null);
  };
  return { appt, book, cancel };
}

export function calcAge(dob) {
  if (!dob) return NaN;
  const d = new Date(dob);
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--;
  return age;
}

export function addDays(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d;
}

export const fmt = (d) => d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
export const fmtISO = (s) => fmt(new Date(s + "T00:00:00"));

/* Eligibility based on common donation guidelines (18-65 yrs, >= 45 kg, Hb >= 12.5 g/dL,
   gap of 3 months for men / 4 months for women between whole-blood donations). */
export function checkEligibility(p) {
  const issues = [];
  const age = calcAge(p.dob);
  if (!(age >= 18 && age <= 65)) issues.push("Donor age must be between 18 and 65 years.");
  if (!(Number(p.weight) >= 45)) issues.push("Weight must be at least 45 kg.");
  if (!(Number(p.hemoglobin) >= 12.5)) issues.push("Hemoglobin must be at least 12.5 g/dL.");

  let nextDate = null;
  if (p.lastDonation) {
    nextDate = addDays(p.lastDonation, p.gender === "Female" ? 120 : 90);
    if (nextDate > new Date()) issues.push(`Next donation allowed from ${fmt(nextDate)}.`);
  }
  return { eligible: issues.length === 0, issues, nextDate };
}
