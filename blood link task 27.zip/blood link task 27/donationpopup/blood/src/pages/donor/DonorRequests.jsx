import React, { useState } from "react";
import { HeartPulse, MapPin, CalendarDays, CheckCircle2 } from "lucide-react";
import ConfirmDonationModal from "../../components/ConfirmDonationModal";
import UpcomingDonationCard from "./UpcomingDonationCard";
import {
  loadProfile, useAppointment, checkEligibility, fmtISO, BLOOD_REQUESTS, canDonateTo
} from "./donorStore";
import "../patient/Profile.css";
import "./DonorProfile.css";
import "./DonorRequests.css";

export default function DonorRequests() {
  const [profile] = useState(loadProfile);
  const { appt, book, cancel } = useAppointment();
  const [onlyMatching, setOnlyMatching] = useState(true);
  const [selected, setSelected] = useState(null);
  const [done, setDone] = useState(false);

  const elig = checkEligibility(profile);
  const blockedReason = !profile.available ? "You are marked unavailable"
    : !elig.eligible ? "You are not eligible right now"
    : appt ? "You already have an upcoming donation" : "";

  const list = BLOOD_REQUESTS.filter((r) => !onlyMatching || canDonateTo(profile.bloodType, r.blood));

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Blood Requests</h1>
          <p>Patients who need blood. Accept a request to confirm your donation.</p>
        </div>
        <label className="dr-toggle">
          <input type="checkbox" checked={onlyMatching} onChange={(e) => setOnlyMatching(e.target.checked)} />
          Only requests I can donate to ({profile.bloodType})
        </label>
      </div>

      {done && <div className="pf-toast"><CheckCircle2 size={17} /> Donation confirmed. Thank you!</div>}

      <UpcomingDonationCard appt={appt} onCancel={cancel} />

      {list.length === 0 && <section className="panel dr-empty">No matching requests right now.</section>}

      <div className="dr-grid">
        {list.map((r) => {
          const accepted = appt?.requestId === r.id;
          return (
            <section className="panel dr-card" key={r.id}>
              <div className="dr-top">
                <div className="dr-blood">{r.blood}</div>
                <div>
                  <strong>{r.patient}</strong>
                  <small>{r.id} &middot; {r.units} unit(s)</small>
                </div>
                <span className={`status ${r.urgency === "Critical" ? "critical" : r.urgency === "High" ? "pending" : "processing"}`}>{r.urgency}</span>
              </div>
              <ul className="dr-meta">
                <li><MapPin size={14} /> {r.hospital}, {r.city}</li>
                <li><CalendarDays size={14} /> Needed by {fmtISO(r.needBy)}</li>
              </ul>
              {accepted
                ? <div className="dr-accepted"><CheckCircle2 size={16} /> You accepted this request</div>
                : <button className="primary dr-btn" disabled={!!blockedReason || !canDonateTo(profile.bloodType, r.blood)}
                    title={blockedReason || (!canDonateTo(profile.bloodType, r.blood) ? "Your blood type is not compatible" : "")}
                    onClick={() => setSelected(r)}>
                    <HeartPulse size={16} /> Accept &amp; Donate
                  </button>}
            </section>
          );
        })}
      </div>

      {selected && (
        <ConfirmDonationModal
          donor={profile}
          request={selected}
          defaultHospital={selected.hospital}
          onClose={() => setSelected(null)}
          onConfirm={(a) => { book(a); setDone(true); setTimeout(() => setDone(false), 3000); }}
        />
      )}
    </>
  );
}
