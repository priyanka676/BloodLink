import React, { useState } from "react";
import { Link } from "react-router-dom";
import { HeartPulse, CalendarClock, Droplets, Activity, CheckCircle2, AlertCircle } from "lucide-react";
import StatCard from "../../components/StatCard";
import ConfirmDonationModal from "../../components/ConfirmDonationModal";
import UpcomingDonationCard from "./UpcomingDonationCard";
import {
  loadProfile, useAppointment, checkEligibility, fmt, fmtISO, DONATION_HISTORY, BLOOD_REQUESTS, canDonateTo
} from "./donorStore";
import "../patient/Profile.css";
import "./DonorProfile.css";

export default function DonorDashboard() {
  const [profile] = useState(loadProfile);
  const { appt, book, cancel } = useAppointment();
  const [showDonate, setShowDonate] = useState(false);
  const [done, setDone] = useState(false);

  const elig = checkEligibility(profile);
  const matching = BLOOD_REQUESTS.filter((r) => canDonateTo(profile.bloodType, r.blood)).length;
  const canBook = elig.eligible && profile.available && !appt;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Donor Dashboard</h1>
          <p>Welcome back, {profile.fullName}. Thank you for saving lives.</p>
        </div>
        <button className="primary" disabled={!canBook} style={{ opacity: canBook ? 1 : .5, cursor: canBook ? "pointer" : "not-allowed" }}
          title={appt ? "You already have an upcoming donation" : !profile.available ? "Mark yourself available in your profile" : !elig.eligible ? "You are not eligible right now" : ""}
          onClick={() => setShowDonate(true)}>
          <HeartPulse size={16} /> Confirm Donation
        </button>
      </div>

      {done && <div className="pf-toast"><CheckCircle2 size={17} /> Donation confirmed. Thank you!</div>}

      <div className="stats-grid">
        <StatCard title="Total Donations" value={profile.totalDonations} note="Lives you can impact: 3 each" icon={HeartPulse} type="red" />
        <StatCard title="Blood Type" value={profile.bloodType} note={profile.available ? "Available to donate" : "Marked unavailable"} icon={Droplets} type="blue" />
        <StatCard title="Last Donation" value={profile.lastDonation ? fmtISO(profile.lastDonation) : "—"} note="Whole blood" icon={CalendarClock} type="orange" />
        <StatCard title="Matching Requests" value={matching} note="Compatible with your type" icon={Activity} type="green" />
      </div>

      <section className={`panel dp-elig ${elig.eligible ? "ok" : "no"}`} style={{ marginTop: 20 }}>
        {elig.eligible ? <CheckCircle2 size={22} /> : <AlertCircle size={22} />}
        <div className="dp-elig-text">
          <strong>{elig.eligible ? "You are eligible to donate blood" : "Currently not eligible to donate"}</strong>
          {elig.eligible
            ? <p>{elig.nextDate ? `Eligible since ${fmt(elig.nextDate)}.` : "No previous donation recorded."}</p>
            : <ul>{elig.issues.map((i) => <li key={i}>{i}</li>)}</ul>}
        </div>
        <Link to="/donor/requests" className="primary dp-donate-btn" style={{ textDecoration: "none" }}>View Requests</Link>
      </section>

      <UpcomingDonationCard appt={appt} onCancel={cancel} />

      <section className="panel">
        <div className="panel-head"><h3>Recent Donations</h3><Link to="/donor/donations">View all</Link></div>
        <table>
          <thead><tr><th>Reference</th><th>Date</th><th>Hospital</th><th>Units</th><th>Status</th></tr></thead>
          <tbody>
            {DONATION_HISTORY.slice(0, 3).map((d) => (
              <tr key={d.ref}>
                <td>{d.ref}</td><td>{fmtISO(d.date)}</td><td>{d.hospital}</td><td>{d.units}</td>
                <td><span className="status completed">{d.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      {showDonate && (
        <ConfirmDonationModal
          donor={profile}
          onClose={() => setShowDonate(false)}
          onConfirm={(a) => { book(a); setDone(true); setTimeout(() => setDone(false), 3000); }}
        />
      )}
    </>
  );
}
