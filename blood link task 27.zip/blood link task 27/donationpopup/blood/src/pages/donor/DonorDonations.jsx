import React, { useState } from "react";
import { Link } from "react-router-dom";
import UpcomingDonationCard from "./UpcomingDonationCard";
import { loadProfile, useAppointment, fmt, fmtISO, addDays, DONATION_HISTORY } from "./donorStore";
import "../patient/Profile.css";
import "./DonorProfile.css";

export default function DonorDonations() {
  const [profile] = useState(loadProfile);
  const { appt, cancel } = useAppointment();
  const next = profile.lastDonation ? addDays(profile.lastDonation, profile.gender === "Female" ? 120 : 90) : null;

  return (
    <>
      <div className="page-head">
        <div>
          <h1>My Donations</h1>
          <p>Your donation history and upcoming appointment.</p>
        </div>
        <Link to="/donor/requests" className="primary" style={{ textDecoration: "none" }}>Find Requests</Link>
      </div>

      <UpcomingDonationCard appt={appt} onCancel={cancel} />

      <section className="panel">
        <div className="panel-head">
          <h3>Donation History</h3>
          <span className="saved" style={{ color: "#7b8494" }}>
            {DONATION_HISTORY.length} donations{next ? ` · next eligible ${fmt(next)}` : ""}
          </span>
        </div>
        <table>
          <thead><tr><th>Reference</th><th>Date</th><th>Hospital</th><th>Units</th><th>Status</th></tr></thead>
          <tbody>
            {appt && (
              <tr>
                <td>{appt.ref}</td><td>{fmtISO(appt.date)}</td><td>{appt.hospital}</td><td>{appt.units}</td>
                <td><span className="status processing">Upcoming</span></td>
              </tr>
            )}
            {DONATION_HISTORY.map((d) => (
              <tr key={d.ref}>
                <td>{d.ref}</td><td>{fmtISO(d.date)}</td><td>{d.hospital}</td><td>{d.units}</td>
                <td><span className="status completed">{d.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </>
  );
}
