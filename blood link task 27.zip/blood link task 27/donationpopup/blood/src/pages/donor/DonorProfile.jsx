import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import {
  Camera, Pencil, Save, X, UserCircle, Droplets, Phone, Mail, MapPin,
  ShieldAlert, Lock, Trash2, CheckCircle2, HeartPulse, CalendarClock, AlertCircle, CalendarDays
} from "lucide-react";
import Modal from "../../components/Modal";
import ConfirmDonationModal from "../../components/ConfirmDonationModal";
import {
  STORAGE_KEY, APPT_KEY, loadProfile, loadAppointment, calcAge, fmt, checkEligibility
} from "./donorStore";
import "../patient/Profile.css";
import "./DonorProfile.css";

const BLOOD_TYPES = ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"];
const PHONE_RE = /^\+?[0-9\s-]{10,15}$/;

function validate(p) {
  const e = {};
  const today = new Date().toISOString().slice(0, 10);
  if (p.fullName.trim().length < 3) e.fullName = "Enter your full name (min 3 characters).";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.email.trim())) e.email = "Enter a valid email address.";
  if (!PHONE_RE.test(p.phone.trim())) e.phone = "Enter a valid phone number (10-15 digits).";
  if (!p.dob) e.dob = "Date of birth is required.";
  else if (p.dob > today || calcAge(p.dob) > 120) e.dob = "Enter a valid date of birth.";
  else if (calcAge(p.dob) < 18) e.dob = "Donors must be at least 18 years old.";
  if (!p.weight || Number(p.weight) < 30 || Number(p.weight) > 300) e.weight = "Enter a valid weight (30-300 kg).";
  if (p.hemoglobin && (Number(p.hemoglobin) < 5 || Number(p.hemoglobin) > 25)) e.hemoglobin = "Enter a valid hemoglobin value (5-25 g/dL).";
  if (!p.city.trim()) e.city = "City is required.";
  if (p.pincode && !/^[0-9]{6}$/.test(p.pincode)) e.pincode = "Pincode must be 6 digits.";
  if (p.lastDonation && p.lastDonation > today) e.lastDonation = "Last donation date cannot be in the future.";
  if (p.travelKm && (Number(p.travelKm) < 1 || Number(p.travelKm) > 500)) e.travelKm = "Enter a distance between 1 and 500 km.";
  if (p.emergencyPhone && !PHONE_RE.test(p.emergencyPhone.trim())) e.emergencyPhone = "Enter a valid emergency phone number.";
  return e;
}

/* Field lives outside the page component so inputs keep focus while typing */
const FormCtx = createContext(null);

function Field({ name, label, type = "text", full, children, ...rest }) {
  const { form, errors, editing, change } = useContext(FormCtx);
  return (
    <label className={`pf-field${full ? " full-field" : ""}${errors[name] ? " has-error" : ""}`}>
      {label}
      {children
        ? React.cloneElement(children, { name, value: form[name], onChange: change, disabled: !editing })
        : <input type={type} name={name} value={form[name]} onChange={change} disabled={!editing} {...rest} />}
      {errors[name] && <span className="pf-error">{errors[name]}</span>}
    </label>
  );
}

export default function DonorProfile({ onUpdateUser }) {
  const [saved, setSaved] = useState(loadProfile);
  const [form, setForm] = useState(saved);
  const [editing, setEditing] = useState(false);
  const [errors, setErrors] = useState({});
  const [toast, setToast] = useState("");
  const [showDonate, setShowDonate] = useState(false);
  const [showCancel, setShowCancel] = useState(false);
  const [appt, setAppt] = useState(loadAppointment);
  const fileRef = useRef(null);

  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [pwErrors, setPwErrors] = useState({});

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 3000);
    return () => clearTimeout(t);
  }, [toast]);

  const persist = (profile) => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(profile)); } catch { /* storage full */ }
  };

  const change = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => (er[name] ? { ...er, [name]: undefined } : er));
  };

  const startEdit = () => { setForm(saved); setErrors({}); setEditing(true); };
  const cancelEdit = () => { setForm(saved); setErrors({}); setEditing(false); };

  const save = (e) => {
    e.preventDefault();
    const errs = validate(form);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const clean = { ...form, fullName: form.fullName.trim(), email: form.email.trim(), phone: form.phone.trim(), city: form.city.trim() };
    persist(clean);
    setSaved(clean);
    setForm(clean);
    setEditing(false);
    if (onUpdateUser) onUpdateUser({ name: clean.fullName });
    setToast("Donor profile updated successfully.");
  };

  /* Availability can be switched any time, without entering edit mode */
  const toggleAvailability = () => {
    const next = { ...saved, available: !saved.available };
    persist(next);
    setSaved(next);
    setForm((f) => ({ ...f, available: next.available }));
    setToast(next.available ? "You are now visible as available." : "You are now marked unavailable.");
  };

  const pickAvatar = (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) return setToast("Please choose an image file.");
    if (file.size > 1024 * 1024) return setToast("Image must be smaller than 1 MB.");
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, avatar: reader.result }));
    reader.readAsDataURL(file);
  };

  const onDonationConfirmed = (appointment) => {
    try { localStorage.setItem(APPT_KEY, JSON.stringify(appointment)); } catch { /* storage full */ }
    setAppt(appointment);
  };

  const cancelAppointment = () => {
    try { localStorage.removeItem(APPT_KEY); } catch { /* ignore */ }
    setAppt(null);
    setShowCancel(false);
    setToast("Your donation appointment was cancelled.");
  };

  const changePassword = (e) => {
    e.preventDefault();
    const er = {};
    if (!pw.current) er.current = "Enter your current password.";
    if (pw.next.length < 8) er.next = "New password must be at least 8 characters.";
    else if (pw.next === pw.current) er.next = "New password must be different.";
    if (pw.confirm !== pw.next) er.confirm = "Passwords do not match.";
    setPwErrors(er);
    if (Object.keys(er).length) return;
    // TODO: call your backend API here to change the password.
    setPw({ current: "", next: "", confirm: "" });
    setToast("Password changed successfully.");
  };

  const view = editing ? form : saved;
  const initials = view.fullName.split(" ").filter(Boolean).map((w) => w[0]).slice(0, 2).join("").toUpperCase();
  const elig = checkEligibility(view);
  const savedElig = checkEligibility(saved);

  return (
    <>
      <div className="page-head">
        <div>
          <h1>Donor Profile</h1>
          <p>Keep your donor details up to date so patients can reach you.</p>
        </div>
        {!editing && (
          <button className="primary" onClick={startEdit}><Pencil size={16} /> Edit Profile</button>
        )}
      </div>

      {toast && <div className="pf-toast"><CheckCircle2 size={17} /> {toast}</div>}

      <section className="panel pf-summary">
        <div className="pf-avatar-wrap">
          {view.avatar
            ? <img src={view.avatar} alt="Profile" className="pf-avatar" />
            : <div className="pf-avatar pf-avatar-fallback">{initials || <UserCircle size={40} />}</div>}
          {editing && (
            <>
              <button type="button" className="pf-avatar-btn" title="Change photo" onClick={() => fileRef.current?.click()}>
                <Camera size={15} />
              </button>
              <input ref={fileRef} type="file" accept="image/*" hidden onChange={pickAvatar} />
            </>
          )}
        </div>

        <div className="pf-summary-info">
          <h2>{view.fullName} <small className="dp-id">{view.donorId}</small></h2>
          <div className="pf-meta">
            <span><Mail size={14} /> {view.email}</span>
            <span><Phone size={14} /> {view.phone}</span>
            <span><MapPin size={14} /> {view.city}{view.state ? `, ${view.state}` : ""}</span>
          </div>
          <div className="dp-avail">
            <span className={`status ${saved.available ? "available" : "unavailable"}`}>
              {saved.available ? "Available" : "Unavailable"}
            </span>
            <button type="button" className="pf-link-btn" onClick={toggleAvailability}>
              Mark as {saved.available ? "unavailable" : "available"}
            </button>
            {editing && view.avatar && (
              <button type="button" className="pf-link-btn" onClick={() => setForm((f) => ({ ...f, avatar: "" }))}>
                <Trash2 size={13} /> Remove photo
              </button>
            )}
          </div>
        </div>

        <div className="pf-badges">
          <div className="pf-badge-box red"><Droplets size={18} /><strong>{view.bloodType}</strong><small>Blood Type</small></div>
          <div className="pf-badge-box"><HeartPulse size={18} /><strong>{view.totalDonations}</strong><small>Donations</small></div>
          <div className="pf-badge-box"><strong>{view.hemoglobin || "-"}</strong><small>Hb (g/dL)</small></div>
        </div>
      </section>

      <section className={`panel dp-elig ${elig.eligible ? "ok" : "no"}`}>
        {elig.eligible ? <CheckCircle2 size={22} /> : <AlertCircle size={22} />}
        <div className="dp-elig-text">
          <strong>{elig.eligible ? "You are eligible to donate blood" : "Currently not eligible to donate"}</strong>
          {elig.eligible
            ? <p><CalendarClock size={13} /> {view.lastDonation ? `Last donated on ${fmt(new Date(view.lastDonation))}.` : "No previous donation recorded."}</p>
            : <ul>{elig.issues.map((i) => <li key={i}>{i}</li>)}</ul>}
        </div>
        <button
          type="button"
          className="primary dp-donate-btn"
          disabled={!savedElig.eligible || !saved.available || !!appt || editing}
          title={
            appt ? "You already have an upcoming donation"
              : editing ? "Save or cancel your profile changes first"
              : !saved.available ? "Mark yourself as available first"
              : !savedElig.eligible ? "You are not eligible right now" : "Confirm a donation"
          }
          onClick={() => setShowDonate(true)}
        >
          <HeartPulse size={16} /> Confirm Donation
        </button>
      </section>

      {appt && (
        <section className="panel dp-appt">
          <CalendarDays size={22} />
          <div className="dp-elig-text">
            <strong>Upcoming donation &middot; {appt.ref}</strong>
            <p>{appt.hospital} &middot; {fmt(new Date(appt.date + "T00:00:00"))} &middot; {appt.slot}</p>
          </div>
          <button type="button" className="pf-secondary" onClick={() => setShowCancel(true)}>Cancel appointment</button>
        </section>
      )}

      <FormCtx.Provider value={{ form, errors, editing, change }}>
        <form onSubmit={save} noValidate>
          <section className="panel form-panel pf-section">
            <div className="panel-head"><h3>Personal Information</h3></div>
            <div className="form-grid">
              <Field name="fullName" label="Full Name" />
              <Field name="email" label="Email" type="email" />
              <Field name="phone" label="Phone" />
              <Field name="dob" label="Date of Birth" type="date" max={new Date().toISOString().slice(0, 10)} />
              <Field name="gender" label="Gender">
                <select><option>Male</option><option>Female</option><option>Other</option></select>
              </Field>
              <Field name="bloodType" label="Blood Type">
                <select>{BLOOD_TYPES.map((b) => <option key={b}>{b}</option>)}</select>
              </Field>
            </div>
          </section>

          <section className="panel form-panel pf-section">
            <div className="panel-head"><h3><HeartPulse size={17} /> Donation Details</h3></div>
            <div className="form-grid">
              <Field name="weight" label="Weight (kg)" type="number" min="30" max="300" />
              <Field name="hemoglobin" label="Hemoglobin (g/dL)" type="number" step="0.1" min="5" max="25" />
              <Field name="lastDonation" label="Last Donation Date" type="date" max={new Date().toISOString().slice(0, 10)} />
              <Field name="travelKm" label="Willing to Travel (km)" type="number" min="1" max="500" />
              <Field name="contactPref" label="Preferred Contact Method">
                <select><option>Phone</option><option>Email</option><option>WhatsApp</option></select>
              </Field>
            </div>
          </section>

          <section className="panel form-panel pf-section">
            <div className="panel-head"><h3>Address</h3></div>
            <div className="form-grid">
              <Field name="city" label="City" />
              <Field name="state" label="State" />
              <Field name="pincode" label="Pincode" inputMode="numeric" maxLength={6} />
              <Field name="address" label="Address" full><textarea /></Field>
            </div>
          </section>

          <section className="panel form-panel pf-section">
            <div className="panel-head"><h3><ShieldAlert size={17} /> Medical &amp; Emergency</h3></div>
            <div className="form-grid">
              <Field name="conditions" label="Medical Conditions (if any)" full><textarea placeholder="e.g. Diabetes, Hypertension" /></Field>
              <Field name="medications" label="Current Medications (if any)" full><textarea placeholder="e.g. Iron supplements" /></Field>
              <Field name="emergencyName" label="Emergency Contact Name" />
              <Field name="emergencyPhone" label="Emergency Contact Phone" />
            </div>
            {editing && (
              <div className="pf-actions">
                <button type="submit" className="primary"><Save size={16} /> Save Changes</button>
                <button type="button" className="pf-secondary" onClick={cancelEdit}><X size={16} /> Cancel</button>
              </div>
            )}
          </section>
        </form>
      </FormCtx.Provider>

      <form onSubmit={changePassword} noValidate>
        <section className="panel form-panel pf-section">
          <div className="panel-head"><h3><Lock size={17} /> Change Password</h3></div>
          <div className="form-grid">
            <label className={`pf-field full-field${pwErrors.current ? " has-error" : ""}`}>
              Current Password
              <input type="password" value={pw.current} autoComplete="current-password"
                onChange={(e) => setPw({ ...pw, current: e.target.value })} />
              {pwErrors.current && <span className="pf-error">{pwErrors.current}</span>}
            </label>
            <label className={`pf-field${pwErrors.next ? " has-error" : ""}`}>
              New Password
              <input type="password" value={pw.next} autoComplete="new-password"
                onChange={(e) => setPw({ ...pw, next: e.target.value })} />
              {pwErrors.next && <span className="pf-error">{pwErrors.next}</span>}
            </label>
            <label className={`pf-field${pwErrors.confirm ? " has-error" : ""}`}>
              Confirm New Password
              <input type="password" value={pw.confirm} autoComplete="new-password"
                onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
              {pwErrors.confirm && <span className="pf-error">{pwErrors.confirm}</span>}
            </label>
          </div>
          <button type="submit" className="primary"><Lock size={16} /> Update Password</button>
        </section>
      </form>
    
      {showDonate && (
        <ConfirmDonationModal
          donor={saved}
          onClose={() => setShowDonate(false)}
          onConfirm={onDonationConfirmed}
        />
      )}

      {showCancel && (
        <Modal
          title="Cancel appointment?"
          size="sm"
          onClose={() => setShowCancel(false)}
          footer={<>
            <button className="bl-btn-secondary" onClick={() => setShowCancel(false)}>Keep it</button>
            <button className="bl-btn-danger" onClick={cancelAppointment}>Yes, cancel</button>
          </>}
        >
          <p style={{ margin: 0, fontSize: 14, color: "#4b5563" }}>
            Your donation at <strong>{appt?.hospital}</strong> on <strong>{appt && fmt(new Date(appt.date + "T00:00:00"))}</strong> will be cancelled.
          </p>
        </Modal>
      )}
    </>
  );
}
