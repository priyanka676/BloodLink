import React, { useState } from "react";
import { CalendarDays } from "lucide-react";
import Modal from "../../components/Modal";
import { fmtISO } from "./donorStore";
import "./DonorProfile.css";

/* Shows the donor's upcoming appointment with a cancel button (and cancel-confirmation popup) */
export default function UpcomingDonationCard({ appt, onCancel }) {
  const [showCancel, setShowCancel] = useState(false);
  if (!appt) return null;
  return (
    <>
      <section className="panel dp-appt">
        <CalendarDays size={22} />
        <div className="dp-elig-text">
          <strong>Upcoming donation &middot; {appt.ref}</strong>
          <p>{appt.hospital} &middot; {fmtISO(appt.date)} &middot; {appt.slot}{appt.requestId ? ` · for ${appt.requestId}` : ""}</p>
        </div>
        <button type="button" className="pf-secondary" onClick={() => setShowCancel(true)}>Cancel appointment</button>
      </section>

      {showCancel && (
        <Modal
          title="Cancel appointment?"
          size="sm"
          onClose={() => setShowCancel(false)}
          footer={<>
            <button className="bl-btn-secondary" onClick={() => setShowCancel(false)}>Keep it</button>
            <button className="bl-btn-danger" onClick={() => { setShowCancel(false); onCancel(); }}>Yes, cancel</button>
          </>}
        >
          <p style={{ margin: 0, fontSize: 14, color: "#4b5563" }}>
            Your donation at <strong>{appt.hospital}</strong> on <strong>{fmtISO(appt.date)}</strong> will be cancelled.
          </p>
        </Modal>
      )}
    </>
  );
}
