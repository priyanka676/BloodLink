import React, { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import "./Modal.css";

/* Reusable modal popup.
   Closes on Esc, on backdrop click and on the X button. Locks page scroll while open. */
export default function Modal({ open = true, onClose, title, icon: Icon, children, footer, size = "md" }) {
  const dialogRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose?.(); };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialogRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return createPortal(
    <div className="bl-modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose?.(); }}>
      <div
        className={`bl-modal bl-modal-${size}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        ref={dialogRef}
      >
        <header className="bl-modal-head">
          <h3>{Icon && <span className="bl-modal-icon"><Icon size={18} /></span>}{title}</h3>
          <button type="button" className="bl-modal-x" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </header>
        <div className="bl-modal-body">{children}</div>
        {footer && <footer className="bl-modal-foot">{footer}</footer>}
      </div>
    </div>,
    document.body
  );
}
