import React, { useState } from "react";
import { HeartPulse, CheckCircle2, Droplets, CalendarDays, Clock, Hospital as HospitalIcon } from "lucide-react";
import Modal from "./Modal";
import "./ConfirmDonationModal.css";

export const HOSPITALS = ["City Hospital", "Civil Hospital", "LifeCare Hospital"];
export const SLOTS = ["09:00 AM - 11:00 AM", "11:00 AM - 01:00 PM", "02:00 PM - 04:00 PM", "04:00 PM - 06:00 PM"];

const toISO = (d) => d.toISOString().slice(0, 10);
const prettyDate = (s) =>
  new Date(s + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "2-digit", month: "short", year: "numeric" });

/* Render this only while it should be visible: {open && <ConfirmDonationModal ... />}
   so its internal state is fresh every time it opens. */
export default function ConfirmDonationModal({ donor, onClose, onConfirm, defaultHospital, request }) {
  const today = new Date();
  const maxDate = new Date(); maxDate.setDate(maxDate.getDate() + 30);

  const hospitals = defaultHospital && !HOSPITALS.includes(defaultHospital) ? [defaultHospital, ...HOSPITALS] : HOSPITALS;
  const [step, setStep] = useState("form"); // form -> review -> success
  const [data, setData] = useState({ hospital: defaultHospital || HOSPITALS[0], date: toISO(today), slot: SLOTS[0], consent: false });
  const [errors, setErrors] = useState({});
  const [result, setResult] = useState(null);

  const set = (name, value) => {
    setData((d) => ({ ...d, [name]: value }));
    setErrors((e) => ({ ...e, [name]: undefined }));
  };

  const goReview = () => {
    const e = {};
    if (!data.date) e.date = "Select a donation date.";
    else if (data.date < toISO(today) || data.date > toISO(maxDate)) e.date = "Choose a date within the next 30 days.";
    if (!data.consent) e.consent = "Please confirm the declaration to continue.";
    setErrors(e);
    if (Object.keys(e).length === 0) setStep("review");
  };

  const confirm = () => {
    const appointment = {
      ref: "DON-" + String(Date.now()).slice(-6),
      hospital: data.hospital,
      date: data.date,
      slot: data.slot,
      units: 1,
      requestId: request?.id || null,
      createdAt: new Date().toISOString()
    };
    setResult(appointment);
    setStep("success");
    onConfirm?.(appointment);
  };

  /* ---------- success ---------- */
  if (step === "success") {
    return (
      <Modal title="Donation Confirmed" icon={CheckCircle2} onClose={onClose} size="sm"
        footer={<button className="primary" onClick={onClose}>Done</button>}>
        <div className="cdm-success">
          <div className="cdm-check"><CheckCircle2 size={44} /></div>
          <h4>Thank you, {donor.fullName.split(" ")[0]}!</h4>
          <p>Your donation has been confirmed. Please carry a valid photo ID.</p>
          <dl className="cdm-summary">
            <div><dt>Reference ID</dt><dd>{result.ref}</dd></div>
            <div><dt>Hospital</dt><dd>{result.hospital}</dd></div>
            <div><dt>Date</dt><dd>{prettyDate(result.date)}</dd></div>
            <div><dt>Time slot</dt><dd>{result.slot}</dd></div>
          </dl>
        </div>
      </Modal>
    );
  }

  /* ---------- review ---------- */
  if (step === "review") {
    return (
      <Modal title="Review & Confirm" icon={HeartPulse} onClose={onClose}
        footer={<>
          <button className="bl-btn-secondary" onClick={() => setStep("form")}>Back</button>
          <button className="primary" onClick={confirm}><CheckCircle2 size={16} /> Confirm Donation</button>
        </>}>
        <p className="cdm-lead">Please review your donation details before confirming.</p>
        <dl className="cdm-summary">
          <div><dt><Droplets size={14} /> Donor</dt><dd>{donor.fullName} ({donor.donorId})</dd></div>
          <div><dt><Droplets size={14} /> Blood type</dt><dd>{donor.bloodType}</dd></div>
          <div><dt><HospitalIcon size={14} /> Hospital</dt><dd>{data.hospital}</dd></div>
          <div><dt><CalendarDays size={14} /> Date</dt><dd>{prettyDate(data.date)}</dd></div>
          <div><dt><Clock size={14} /> Time slot</dt><dd>{data.slot}</dd></div>
          {request && <div><dt><HeartPulse size={14} /> For request</dt><dd>{request.id} ({request.patient})</dd></div>}
          <div><dt><HeartPulse size={14} /> Quantity</dt><dd>1 unit (approx. 350 ml)</dd></div>
        </dl>
      </Modal>
    );
  }

  /* ---------- form ---------- */
  return (
    <Modal title="Confirm Blood Donation" icon={HeartPulse} onClose={onClose}
      footer={<>
        <button className="bl-btn-secondary" onClick={onClose}>Cancel</button>
        <button className="primary" onClick={goReview}>Continue</button>
      </>}>
      <div className="cdm-donor">
        <div className="cdm-blood">{donor.bloodType}</div>
        <div>
          <strong>{donor.fullName}</strong>
          <small>{donor.donorId} &middot; {donor.city}</small>
        </div>
      </div>

      {request && (
        <div className="cdm-request">
          Responding to <strong>{request.id}</strong> &middot; {request.patient} needs {request.units} unit(s) of {request.blood}
        </div>
      )}

      <div className="cdm-form">
        <label>Hospital / Donation Center
          <select value={data.hospital} onChange={(e) => set("hospital", e.target.value)}>
            {hospitals.map((h) => <option key={h}>{h}</option>)}
          </select>
        </label>

        <div className="cdm-row">
          <label className={errors.date ? "has-error" : ""}>Donation Date
            <input type="date" value={data.date} min={toISO(today)} max={toISO(maxDate)}
              onChange={(e) => set("date", e.target.value)} />
            {errors.date && <span className="cdm-error">{errors.date}</span>}
          </label>
          <label>Time Slot
            <select value={data.slot} onChange={(e) => set("slot", e.target.value)}>
              {SLOTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>
        </div>

        <label className={`cdm-consent${errors.consent ? " has-error" : ""}`}>
          <input type="checkbox" checked={data.consent} onChange={(e) => set("consent", e.target.checked)} />
          <span>I confirm that I am in good health, have not consumed alcohol in the last 24 hours, and
            voluntarily agree to donate blood.</span>
        </label>
        {errors.consent && <span className="cdm-error">{errors.consent}</span>}
      </div>
    </Modal>
  );
}
