BloodLink - Donor Portal
========================

Run:
  cd blood
  npm install        (skip if node_modules is already included)
  npm run dev

Login: choose the "Donor" tab, enter any email + password.

Donor pages
  /donor            Dashboard  (stats, eligibility, upcoming donation, recent donations)
  /donor/requests   Blood Requests (accept a request -> donation confirmation popup)
  /donor/donations  My Donations (history + upcoming appointment)
  /donor/profile    Donor Profile (edit profile, photo, availability, password form)

Data is stored in the browser (localStorage). Replace the functions in
blood/src/pages/donor/donorStore.js and the save handlers in DonorProfile.jsx
with API calls when you have a backend.
