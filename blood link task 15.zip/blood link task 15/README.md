# Blood Link – Notifications (react-toastify)

## Run
```
npm install
npm run dev
```
Open http://localhost:5173

## Included
- Toast pop-ups (`react-toastify`)
- Bell icon with unread badge + dropdown (`components/NotificationBell.jsx`)
- `/notifications` page: filters, mark read, delete, clear all, test buttons
- `context/NotificationContext.jsx` – `notify(type, title, message)` (bell + toast), `toastOnly(type, text)`

## Use anywhere
```jsx
const { notify } = useNotifications()
notify('success', 'Saved', 'Donor added successfully.')
```
Types: success | error | warning | info

## Add to your existing project
1. `npm i react-toastify`
2. Copy `src/context`, `src/components/NotificationBell.jsx`, `src/components/Notifications.css`, `src/pages/Notifications.jsx`
3. Wrap app in `<NotificationProvider>` (inside BrowserRouter), render `<ToastContainer />` once,
   add route `/notifications`, put `<NotificationBell />` in your Navbar.

Stored in localStorage (`bloodlink_notifications`).
