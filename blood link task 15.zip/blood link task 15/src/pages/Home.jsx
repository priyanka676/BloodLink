import { useNotifications } from '../context/NotificationContext.jsx'

export default function Home() {
  const { notify, toastOnly } = useNotifications()
  return (
    <div className="np">
      <h1>Blood Link – Notifications Demo</h1>
      <p>Click a button: the toast pops up and the bell in the navbar gets a new unread notification.</p>
      <div className="np-actions">
        <button onClick={() => notify('success', 'Request approved', 'Your blood request #12 was approved.')}>Success</button>
        <button onClick={() => notify('warning', 'Low stock', 'O- units are running low.')}>Warning</button>
        <button onClick={() => notify('error', 'Request rejected', 'Please contact the hospital.')}>Error</button>
        <button onClick={() => notify('info', 'New donor', 'A matching donor is nearby.')}>Info</button>
        <button onClick={() => toastOnly('info', 'Toast only (not saved to bell)')}>Toast only</button>
      </div>
    </div>
  )
}
