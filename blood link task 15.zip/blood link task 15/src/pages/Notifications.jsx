import { useState } from 'react'
import { Trash2, CheckCheck } from 'lucide-react'
import { useNotifications } from '../context/NotificationContext.jsx'
import { ICONS, ago } from '../components/NotificationBell.jsx'
import { Info } from 'lucide-react'
import '../components/Notifications.css'

export default function Notifications() {
  const { items, unread, markRead, markAllRead, remove, clearAll, notify } = useNotifications()
  const [filter, setFilter] = useState('all')
  const shown = items.filter((n) => filter === 'all' || (filter === 'unread' ? !n.read : n.type === filter))

  return (
    <div className="np">
      <div className="np-head">
        <h1>Notifications {unread > 0 && <span className="nb-badge static">{unread}</span>}</h1>
        <div className="np-actions">
          <button onClick={markAllRead}><CheckCheck size={16} /> Mark all read</button>
          <button onClick={() => window.confirm('Delete all notifications?') && clearAll()}><Trash2 size={16} /> Clear all</button>
          <button onClick={() => notify('success', 'Request approved', 'Your blood request was approved.')}>Test success</button>
          <button onClick={() => notify('warning', 'Low stock', 'O- blood units are running low.')}>Test warning</button>
          <button onClick={() => notify('error', 'Request rejected', 'Please contact the hospital.')}>Test error</button>
          <button onClick={() => notify('info', 'New donor', 'A matching donor is available nearby.')}>Test info</button>
        </div>
      </div>
      <div className="np-tabs">
        {['all', 'unread', 'success', 'warning', 'error', 'info'].map((f) => (
          <button key={f} className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>{f}</button>
        ))}
      </div>
      <div className="np-card">
        {shown.length === 0 && <p className="nb-empty">Nothing to show.</p>}
        {shown.map((n) => {
          const Icon = ICONS[n.type] || Info
          return (
            <div key={n.id} className={`nb-item ${n.read ? '' : 'unread'}`} onClick={() => markRead(n.id)}>
              <Icon size={20} className={`t-${n.type}`} />
              <div style={{ flex: 1 }}><strong>{n.title}</strong><span>{n.message}</span><small>{ago(n.time)}</small></div>
              <button className="np-del" onClick={(e) => { e.stopPropagation(); remove(n.id) }} title="Delete"><Trash2 size={16} /></button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
