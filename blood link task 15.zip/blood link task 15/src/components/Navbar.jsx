import { NavLink } from 'react-router-dom'
import { Droplet } from 'lucide-react'
import NotificationBell from './NotificationBell.jsx'
import './Notifications.css'

export default function Navbar() {
  return (
    <nav className="nav">
      <div className="nav-brand"><Droplet size={22} /> Blood Link</div>
      <div className="nav-links">
        <NavLink to="/">Home</NavLink>
        <NavLink to="/notifications">Notifications</NavLink>
      </div>
      <NotificationBell />
    </nav>
  )
}
