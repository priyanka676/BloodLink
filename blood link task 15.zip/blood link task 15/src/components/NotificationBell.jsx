import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Bell, CheckCircle2, AlertCircle, Info, AlertTriangle } from 'lucide-react'
import { useNotifications } from '../context/NotificationContext.jsx'
import './Notifications.css'

export const ICONS = { success: CheckCircle2, error: AlertCircle, info: Info, warning: AlertTriangle }
export const ago = (iso) => {
  const s = Math.floor((Date.now() - new Date(iso)) / 1000)
  if (s < 60) return 'just now'
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  return `${Math.floor(s / 86400)}d ago`
}

export default function NotificationBell() {
  const { items, unread, markRead, markAllRead } = useNotifications()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const close = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [])

  return (
    <div className="nb" ref={ref}>
      <button className="nb-btn" onClick={() => setOpen((o) => !o)} aria-label="Notifications">
        <Bell size={22} />
        {unread > 0 && <span className="nb-badge">{unread > 9 ? '9+' : unread}</span>}
      </button>
      {open && (
        <div className="nb-menu">
          <div className="nb-head">
            <b>Notifications</b>
            {unread > 0 && <button onClick={markAllRead}>Mark all read</button>}
          </div>
          <div className="nb-list">
            {items.length === 0 && <p className="nb-empty">You're all caught up.</p>}
            {items.slice(0, 6).map((n) => {
              const Icon = ICONS[n.type] || Info
              return (
                <div key={n.id} className={`nb-item ${n.read ? '' : 'unread'}`} onClick={() => markRead(n.id)}>
                  <Icon size={18} className={`t-${n.type}`} />
                  <div><strong>{n.title}</strong><span>{n.message}</span><small>{ago(n.time)}</small></div>
                </div>
              )
            })}
          </div>
          <Link to="/notifications" className="nb-foot" onClick={() => setOpen(false)}>View all</Link>
        </div>
      )}
    </div>
  )
}
