import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { toast } from 'react-toastify'

const KEY = 'bloodlink_notifications'
const Ctx = createContext(null)
export const useNotifications = () => useContext(Ctx)

const read = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }

export function NotificationProvider({ children }) {
  const [items, setItems] = useState(() => read(KEY, []))

  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(items)) }, [items])

  // type: success | error | info | warning. Saves to the notification center AND shows a toast.
  const notify = useCallback((type, title, message = '', { silent = false } = {}) => {
    setItems((p) => [{ id: Date.now() + Math.random().toString(36).slice(2, 6), type, title, message, read: false, time: new Date().toISOString() }, ...p].slice(0, 100))
    if (!silent) (toast[type] || toast)(message ? `${title} – ${message}` : title)
  }, [])

  // Toast only (not stored), e.g. form validation errors
  const toastOnly = useCallback((type, text) => (toast[type] || toast)(text), [])

  const markRead = (id) => setItems((p) => p.map((n) => (n.id === id ? { ...n, read: true } : n)))
  const markAllRead = () => setItems((p) => p.map((n) => ({ ...n, read: true })))
  const remove = (id) => setItems((p) => p.filter((n) => n.id !== id))
  const clearAll = () => setItems([])

  const unread = items.filter((n) => !n.read).length
  return <Ctx.Provider value={{ items, unread, notify, toastOnly, markRead, markAllRead, remove, clearAll }}>{children}</Ctx.Provider>
}
