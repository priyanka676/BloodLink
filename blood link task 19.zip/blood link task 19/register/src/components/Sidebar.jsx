import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard, Users, HeartPulse, Droplets, ClipboardList, Package,
  Hospital, BarChart3, Settings, Search, FileHeart, Bell, User
} from "lucide-react";

const adminItems = [
  ["/admin","Dashboard",LayoutDashboard], ["/admin/patients","Patients",Users],
  ["/admin/donors","Donors",HeartPulse], ["/admin/blood-types","Blood Types",Droplets],
  ["/admin/requests","Requests",ClipboardList], ["/admin/inventory","Inventory",Package],
  ["/admin/hospitals","Hospitals",Hospital], ["/admin/reports","Reports",BarChart3],
  ["/admin/settings","Settings",Settings]
];
const patientItems = [
  ["/patient","Dashboard",LayoutDashboard], ["/patient/search-blood","Search Blood",Search],
  ["/patient/request-blood","Request Blood",FileHeart], ["/patient/my-requests","My Requests",ClipboardList],
  ["/patient/notifications","Notifications",Bell], ["/patient/profile","Profile",User]
];

export default function Sidebar({ role }) {
  const items = role === "admin" ? adminItems : patientItems;
  return (
    <aside className="sidebar">
      <div className="brand"><div className="brand-icon"><Droplets size={25}/></div><div><strong>BloodLink</strong><small>{role === "admin" ? "Admin Portal" : "Patient Portal"}</small></div></div>
      <div className="menu-title">MAIN MENU</div>
      <nav>{items.map(([path,label,Icon]) => (
        <NavLink key={path} to={path} end={path === `/${role}`}>
          <Icon size={19}/><span>{label}</span>
        </NavLink>
      ))}</nav>
      <div className="sidebar-footer"><div className="help-box"><strong>Need help?</strong><p>Contact BloodLink support for assistance.</p><button>Contact Support</button></div></div>
    </aside>
  );
}
