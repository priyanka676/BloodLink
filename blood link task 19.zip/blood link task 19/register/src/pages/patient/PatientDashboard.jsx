import React from "react";
import { Search, FileHeart, ClipboardList, Bell } from "lucide-react";
import StatCard from "../../components/StatCard";
export default function PatientDashboard() {
    return <>
        <div className="page-head">
            <div>
                <h1>Patient Dashboard</h1>
                <p>Welcome back, Priyanka Rana. Manage your blood requests here.</p>
            </div>
            <button className="primary">Request Blood</button>
        </div>
        <div className="stats-grid">
            <StatCard title="My Requests" value="5" note="2 pending" icon={ClipboardList} type="blue" />
            <StatCard title="Approved" value="2" note="Ready for collection" icon={FileHeart} type="green" /><StatCard title="Notifications" value="3" note="Unread messages" icon={Bell} type="orange" />
            <StatCard title="Blood Type" value="O+" note="Your registered group" icon={Search} type="red" /></div><div className="quick-grid"><a href="/patient/search-blood" className="quick"><Search /><h3>Search Blood</h3>
                <p>Find available blood near you.</p></a>
            <a href="/patient/request-blood" className="quick"><FileHeart />
                <h3>Request Blood</h3><p>Create a new blood request.</p></a>
            <a href="/patient/my-requests" className="quick">
                <ClipboardList /><h3>My Requests</h3>
                <p>Track your request status.</p></a>
        </div>
        <section className="panel">
            <div className="panel-head">
                <h3>Recent Requests</h3></div>
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Blood Type</th>
                        <th>Units</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>REQ-1042</td>
                        <td>O+</td>
                        <td>2</td>
                        <td>24 Aug 2026</td>
                        <td><span className="status pending">Pending</span></td></tr><tr><td>REQ-1011</td><td>O+</td><td>1</td><td>18 Aug 2026</td><td><span className="status completed">Completed</span></td>
                    </tr>
                </tbody>
            </table>
        </section>
    </>
}