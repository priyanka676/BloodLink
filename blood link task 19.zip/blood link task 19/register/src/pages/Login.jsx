import React, { useState } from "react";
import { Droplets, ShieldCheck, UserRound } from "lucide-react";
import { loadUsers } from "../constants";

export default function Login({ onLogin, onShowRegister }) {
  const [role, setRole] = useState("admin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submit = e => {
    e.preventDefault();
    if (!email || !password) return alert("Please enter email and password.");
    if (role === "admin") return onLogin("admin", "Administrator");
    const found = loadUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
    if (found && found.password !== password) return alert("Incorrect password.");
    onLogin("patient", found ? found.name : "Rahul Patel", found ? found.blood : "O+");
  };

  return <div className="login-page">
    <div className="login-card">
      <div className="login-logo"><Droplets size={34} /></div>
      <h1>Welcome to BloodLink</h1><p>Blood Management System</p>
      <div className="role-tabs">
        <button type="button" className={role === "admin" ? "active" : ""} onClick={() => setRole("admin")}><ShieldCheck size={17} /> Admin</button>
        <button type="button" className={role === "patient" ? "active" : ""} onClick={() => setRole("patient")}><UserRound size={17} /> Patient</button>
      </div>
      <form onSubmit={submit}>
        <label>Email Address</label><input type="email" placeholder="admin@bloodlink.com" value={email} onChange={e => setEmail(e.target.value)} />
        <label>Password</label><input type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
        <div className="form-row"><label className="check"><input type="checkbox" /> Remember me</label><a href="#forgot">Forgot password?</a></div>
        <button className="primary full">{role === "admin" ? "Sign in as Admin" : "Sign in as Patient"}</button>
      </form>
      <div className="demo-note">Demo: enter any valid email and password.</div>
      {role === "patient" && <div className="demo-note">New here? <a href="#register" onClick={e => { e.preventDefault(); onShowRegister(); }}>Create an account</a></div>}
    </div>
  </div>;
}