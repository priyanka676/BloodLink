import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Register.css";

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [shaking, setShaking] = useState(false);

  const set = (k) => (e) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    if (errors[k]) setErrors((x) => ({ ...x, [k]: undefined }));
  };

  const submit = (e) => {
    e.preventDefault();
    const err = {};
    if (!/^\S+@\S+\.\S+$/.test(form.email)) err.email = "Enter a valid email address.";
    if (!form.password) err.password = "Enter your password.";
    setErrors(err);
    if (Object.keys(err).length) {
      setShaking(true);
      return;
    }
    // TODO: replace with your real login API call
    navigate("/");
  };

  return (
    <div className="reg">
      <aside className="reg-side" aria-hidden="true">
        <svg className="reg-drop" viewBox="0 0 120 160">
          <path d="M60 6C60 6 14 62 14 100a46 46 0 0 0 92 0C106 62 60 6 60 6Z" fill="#fff" />
        </svg>
        <h2>Blood Link</h2>
        <p>Welcome back. Log in to find donors or respond to requests.</p>
      </aside>
      <main className="reg-main">
        <form
          className="reg-card"
          data-shake={shaking}
          onSubmit={submit}
          noValidate
          onAnimationEnd={(e) => {
            if (e.target === e.currentTarget && e.animationName === "reg-shake") setShaking(false);
          }}
        >
          <h1>Log in</h1>
          <label className={`reg-field ${errors.email ? "has-error" : ""}`}>
            <span>Email</span>
            <input type="email" value={form.email} onChange={set("email")} autoComplete="email" />
            {errors.email && <small className="reg-error">{errors.email}</small>}
          </label>
          <label className={`reg-field ${errors.password ? "has-error" : ""}`}>
            <span>Password</span>
            <input type="password" value={form.password} onChange={set("password")} autoComplete="current-password" />
            {errors.password && <small className="reg-error">{errors.password}</small>}
          </label>
          <div className="reg-actions">
            <span />
            <button type="submit" className="reg-btn reg-btn-primary">Log in</button>
          </div>
          <p className="reg-login">
            New here? <Link to="/register">Create an account</Link>
          </p>
        </form>
      </main>
    </div>
  );
}
