import { useState } from "react";
import { Link } from "react-router-dom";
import { Check, Eye, EyeOff } from "lucide-react";
import "./Register.css";

const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const STEPS = ["Account", "Blood details", "Confirm"];

const initial = {
  name: "",
  email: "",
  password: "",
  role: "donor",
  bloodGroup: "",
  dob: "",
  phone: "",
  city: "",
  terms: false,
};

function passwordScore(pw) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s; // 0..4
}

function validate(step, f) {
  const e = {};
  if (step === 0) {
    if (f.name.trim().length < 2) e.name = "Enter your full name.";
    if (!/^\S+@\S+\.\S+$/.test(f.email)) e.email = "Enter a valid email address.";
    if (f.password.length < 8) e.password = "Use at least 8 characters.";
  }
  if (step === 1) {
    if (!f.bloodGroup) e.bloodGroup = "Choose your blood group.";
    if (!f.dob) e.dob = "Enter your date of birth.";
    if (!/^\+?[\d\s-]{10,15}$/.test(f.phone)) e.phone = "Enter a valid phone number.";
    if (f.city.trim().length < 2) e.city = "Enter your city.";
  }
  if (step === 2) {
    if (!f.terms) e.terms = "Accept the terms to create your account.";
  }
  return e;
}

export default function Register() {
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState("forward");
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState({});
  const [shaking, setShaking] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const set = (k) => (e) => {
    const v = e.target.type === "checkbox" ? e.target.checked : e.target.value;
    setForm((f) => ({ ...f, [k]: v }));
    if (errors[k]) setErrors((x) => ({ ...x, [k]: undefined }));
  };

  const next = async () => {
    const e = validate(step, form);
    setErrors(e);
    if (Object.keys(e).length) {
      setShaking(true); // cleared in onAnimationEnd so it can fire again
      return;
    }
    if (step < STEPS.length - 1) {
      setDir("forward");
      setStep(step + 1);
      return;
    }
    setLoading(true);
    try {
      // TODO: replace with your real API call, e.g.
      // await fetch("/api/register", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(form) });
      await new Promise((r) => setTimeout(r, 1200));
      setDone(true);
    } finally {
      setLoading(false);
    }
  };

  const back = () => {
    setErrors({});
    setDir("back");
    setStep(step - 1);
  };

  const score = passwordScore(form.password);
  const fill = done ? 100 : ((step + 1) / STEPS.length) * 100;

  return (
    <div className="reg">
      <aside className="reg-side" aria-hidden="true">
        <svg className="reg-drop" viewBox="0 0 120 160">
          <defs>
            <clipPath id="dropClip">
              <path d="M60 6C60 6 14 62 14 100a46 46 0 0 0 92 0C106 62 60 6 60 6Z" />
            </clipPath>
          </defs>
          <path
            d="M60 6C60 6 14 62 14 100a46 46 0 0 0 92 0C106 62 60 6 60 6Z"
            fill="rgba(255,255,255,.12)"
            stroke="rgba(255,255,255,.7)"
            strokeWidth="2"
          />
          <g clipPath="url(#dropClip)">
            <rect
              className="reg-drop-fill"
              x="0"
              y="0"
              width="120"
              height="160"
              style={{ transform: `translateY(${160 - (fill / 100) * 140}px)` }}
            />
          </g>
        </svg>
        <h2>Blood Link</h2>
        <p>One account connects donors, patients and hospitals when every minute counts.</p>
      </aside>

      <main className="reg-main">
        {done ? (
          <div className="reg-success">
            <svg viewBox="0 0 52 52" className="reg-check">
              <circle cx="26" cy="26" r="24" />
              <path d="M14 27l8 8 16-17" />
            </svg>
            <h1>You're registered, {form.name.split(" ")[0]}.</h1>
            <p>
              Your {form.role === "donor" ? "donor" : "patient"} account for blood group{" "}
              <strong>{form.bloodGroup}</strong> is ready.
            </p>
            <Link className="reg-btn reg-btn-primary" to="/login">
              Go to login
            </Link>
          </div>
        ) : (
          <div
            className="reg-card"
            data-shake={shaking}
            onAnimationEnd={(e) => {
              if (e.target === e.currentTarget && e.animationName === "reg-shake") setShaking(false);
            }}
          >
            <h1>Create your account</h1>

            <ol className="reg-steps" aria-label="Progress">
              {STEPS.map((s, i) => (
                <li key={s} className={i < step ? "is-done" : i === step ? "is-current" : ""}>
                  <span className="reg-dot">{i < step ? <Check size={14} /> : i + 1}</span>
                  <span className="reg-step-label">{s}</span>
                </li>
              ))}
              <span className="reg-track">
                <span style={{ width: `${(step / (STEPS.length - 1)) * 100}%` }} />
              </span>
            </ol>

            <div className="reg-viewport">
              <div className={`reg-panel ${dir}`} key={step}>
                {step === 0 && (
                  <>
                    <Field label="Full name" error={errors.name}>
                      <input value={form.name} onChange={set("name")} autoComplete="name" />
                    </Field>
                    <Field label="Email" error={errors.email}>
                      <input type="email" value={form.email} onChange={set("email")} autoComplete="email" />
                    </Field>
                    <Field label="Password" error={errors.password}>
                      <div className="reg-pw">
                        <input
                          type={showPw ? "text" : "password"}
                          value={form.password}
                          onChange={set("password")}
                          autoComplete="new-password"
                        />
                        <button
                          type="button"
                          className="reg-eye"
                          onClick={() => setShowPw((s) => !s)}
                          aria-label={showPw ? "Hide password" : "Show password"}
                        >
                          {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                        </button>
                      </div>
                      <div className={`reg-meter s${score}`}>
                        <span />
                      </div>
                    </Field>
                  </>
                )}

                {step === 1 && (
                  <>
                    <div className="reg-roles" role="radiogroup" aria-label="I am a">
                      {["donor", "patient"].map((r) => (
                        <label key={r} className={form.role === r ? "on" : ""}>
                          <input type="radio" name="role" checked={form.role === r} onChange={() => setForm((f) => ({ ...f, role: r }))} />
                          {r === "donor" ? "I want to donate" : "I need blood"}
                        </label>
                      ))}
                    </div>

                    <Field group label="Blood group" error={errors.bloodGroup}>
                      <div className="reg-groups">
                        {BLOOD_GROUPS.map((g, i) => (
                          <label key={g} className={form.bloodGroup === g ? "on" : ""} style={{ "--i": i }}>
                            <input
                              type="radio"
                              name="bg"
                              checked={form.bloodGroup === g}
                              onChange={() => {
                                setForm((f) => ({ ...f, bloodGroup: g }));
                                setErrors((x) => ({ ...x, bloodGroup: undefined }));
                              }}
                            />
                            {g}
                          </label>
                        ))}
                      </div>
                    </Field>

                    <div className="reg-row">
                      <Field label="Date of birth" error={errors.dob}>
                        <input type="date" value={form.dob} onChange={set("dob")} />
                      </Field>
                      <Field label="Phone" error={errors.phone}>
                        <input type="tel" value={form.phone} onChange={set("phone")} autoComplete="tel" />
                      </Field>
                    </div>
                    <Field label="City" error={errors.city}>
                      <input value={form.city} onChange={set("city")} autoComplete="address-level2" />
                    </Field>
                  </>
                )}

                {step === 2 && (
                  <>
                    <dl className="reg-review">
                      <div><dt>Name</dt><dd>{form.name}</dd></div>
                      <div><dt>Email</dt><dd>{form.email}</dd></div>
                      <div><dt>Role</dt><dd>{form.role === "donor" ? "Donor" : "Patient"}</dd></div>
                      <div><dt>Blood group</dt><dd>{form.bloodGroup}</dd></div>
                      <div><dt>Phone</dt><dd>{form.phone}</dd></div>
                      <div><dt>City</dt><dd>{form.city}</dd></div>
                    </dl>
                    <label className="reg-terms">
                      <input type="checkbox" checked={form.terms} onChange={set("terms")} />
                      I agree to share my blood group and city with verified hospitals and patients.
                    </label>
                    {errors.terms && <p className="reg-error">{errors.terms}</p>}
                  </>
                )}
              </div>
            </div>

            <div className="reg-actions">
              {step > 0 ? (
                <button type="button" className="reg-btn reg-btn-ghost" onClick={back}>
                  Back
                </button>
              ) : (
                <span />
              )}
              <button type="button" className="reg-btn reg-btn-primary" onClick={next} disabled={loading}>
                {loading ? <span className="reg-spin" /> : step === STEPS.length - 1 ? "Create account" : "Continue"}
              </button>
            </div>

            <p className="reg-login">
              Already registered? <Link to="/login">Log in</Link>
            </p>
          </div>
        )}
      </main>
    </div>
  );
}

// `group` renders a div instead of a label, for fields that contain their own labels (e.g. radio chips)
function Field({ label, error, group, children }) {
  const Tag = group ? "div" : "label";
  return (
    <Tag
      className={`reg-field ${error ? "has-error" : ""}`}
      role={group ? "group" : undefined}
      aria-label={group ? label : undefined}
    >
      <span>{label}</span>
      {children}
      {error && <small className="reg-error">{error}</small>}
    </Tag>
  );
}
