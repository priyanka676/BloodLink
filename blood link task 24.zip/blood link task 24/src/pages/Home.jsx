import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="home">
      <div>
        <svg width="64" viewBox="0 0 120 160" aria-hidden="true">
          <path d="M60 6C60 6 14 62 14 100a46 46 0 0 0 92 0C106 62 60 6 60 6Z" fill="#a4122b" />
        </svg>
        <h1>Blood Link</h1>
        <p>Connecting donors, patients and hospitals when every minute counts.</p>
        <nav>
          <Link className="primary" to="/register">Register</Link>
          <Link to="/login">Log in</Link>
          <Link to="/blog-detail">Blog</Link>
          <Link to="/admin">Admin</Link>
        </nav>
      </div>
    </div>
  );
}
