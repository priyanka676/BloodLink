export default function AdminPage({ title, group }) {
  return (
    <>
      <div className="adm-head">
        <h1>{title}</h1>
        {group && <p>{group}</p>}
      </div>
      <div className="adm-card adm-empty">
        <p>
           <code>Welcome to Admin Dashboard.</code> 
         
        </p>
      </div>
    </>
  );
}
