import { Users, Droplets, ClipboardList, Building2 } from "lucide-react";

const STATS = [
  { label: "Registered donors", value: "1,248", icon: Users },
  { label: "Units in stock", value: "436", icon: Droplets },
  { label: "Open requests", value: "18", icon: ClipboardList },
  { label: "Partner hospitals", value: "32", icon: Building2 },
];

const STOCK = [
  ["A+", 78], ["A-", 24], ["B+", 66], ["B-", 18],
  ["AB+", 40], ["AB-", 12], ["O+", 92], ["O-", 30],
];

const REQUESTS = [
  { id: "#1042", patient: "R. Mehta", group: "O-", units: 2, status: "Urgent" },
  { id: "#1041", patient: "S. Patel", group: "B+", units: 1, status: "Pending" },
  { id: "#1040", patient: "A. Shah", group: "A+", units: 3, status: "Fulfilled" },
  { id: "#1039", patient: "K. Desai", group: "AB-", units: 1, status: "Pending" },
];

const badge = { Urgent: "text-bg-danger", Pending: "text-bg-warning", Fulfilled: "text-bg-success" };

export default function AdminDashboard() {
  return (
    <>
      <div className="adm-head">
        <h1>Dashboard</h1>
        <p>Overview of donors, stock and requests.</p>
      </div>

      <div className="row g-3 mb-4">
        {STATS.map(({ label, value, icon: Icon }) => (
          <div className="col-6 col-xl-3" key={label}>
            <div className="adm-card adm-stat">
              <span className="adm-stat-icon"><Icon size={20} /></span>
              <div>
                <div className="adm-stat-value">{value}</div>
                <div className="adm-stat-label">{label}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="row g-3">
        <div className="col-lg-5">
          <div className="adm-card">
            <h2 className="adm-card-title">Stock by blood group</h2>
            {STOCK.map(([g, v]) => (
              <div className="adm-bar" key={g}>
                <span>{g}</span>
                <div className="progress" role="progressbar" aria-label={`${g} stock`} aria-valuenow={v} aria-valuemin="0" aria-valuemax="100">
                  <div className={`progress-bar ${v < 25 ? "bg-danger" : ""}`} style={{ width: `${v}%` }} />
                </div>
                <small>{v}%</small>
              </div>
            ))}
          </div>
        </div>

        <div className="col-lg-7">
          <div className="adm-card">
            <h2 className="adm-card-title">Recent requests</h2>
            <div className="table-responsive">
              <table className="table align-middle mb-0">
                <thead>
                  <tr><th>ID</th><th>Patient</th><th>Group</th><th>Units</th><th>Status</th></tr>
                </thead>
                <tbody>
                  {REQUESTS.map((r) => (
                    <tr key={r.id}>
                      <td>{r.id}</td>
                      <td>{r.patient}</td>
                      <td>{r.group}</td>
                      <td>{r.units}</td>
                      <td><span className={`badge ${badge[r.status]}`}>{r.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
