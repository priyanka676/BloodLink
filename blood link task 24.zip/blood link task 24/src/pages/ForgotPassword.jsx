import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Check, Eye, EyeOff } from "lucide-react";
import "./Register.css";
import "./ForgotPassword.css";

const STEPS = ["Email", "Verify", "New password"];
const CODE_LENGTH = 6;
const RESEND_SECONDS = 30;

function passwordScore(pw) {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return s;
}

export default function ForgotPassword() {
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState("forward");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState(Array(CODE_LENGTH).fill(""));
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [errors, setErrors] = useState({});
  const [shaking, setShaking] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const boxes = useRef([]);

  // Resend countdown
  useEffect(() => {
    if (seconds <= 0) return;
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [seconds]);

  // Focus first code box when the verify step opens
  useEffect(() => {
    if (step === 1) boxes.current[0]?.focus();
  }, [step]);

  const fail = (e) => {
    setErrors(e);
    setShaking(true);
  };

  const next = async () => {
    const e = {};
    if (step === 0) {
      if (!/^\S+@\S+\.\S+$/.test(email)) e.email = "Enter the email you registered with.";
    } else if (step === 1) {
      if (code.join("").length < CODE_LENGTH) e.code = `Enter the ${CODE_LENGTH}-digit code.`;
    } else {
      if (password.length < 8) e.password = "Use at least 8 characters.";
      if (confirm !== password) e.confirm = "Passwords do not match.";
    }
    if (Object.keys(e).length) return fail(e);
    setErrors({});

    setLoading(true);
    try {
      // TODO: call your API here
      //  step 0 -> POST /api/forgot-password { email }            (send the code)
      //  step 1 -> POST /api/verify-code { email, code }          (check the code)
      //  step 2 -> POST /api/reset-password { email, code, password }
      await new Promise((r) => setTimeout(r, 900));
      if (step < STEPS.length - 1) {
        setDir("forward");
        setStep(step + 1);
        if (step === 0) setSeconds(RESEND_SECONDS);
      } else {
        setDone(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const back = () => {
    setErrors({});
    setDir("back");
    setStep(step - 1);
  };

  const resend = () => {
    if (seconds > 0) return;
    // TODO: call your "resend code" API here
    setCode(Array(CODE_LENGTH).fill(""));
    setSeconds(RESEND_SECONDS);
    boxes.current[0]?.focus();
  };

  // ----- code box handlers -----
  const setDigit = (i, value) => {
    const digit = value.replace(/\D/g, "").slice(-1);
    setCode((c) => c.map((d, idx) => (idx === i ? digit : d)));
    if (errors.code) setErrors((x) => ({ ...x, code: undefined }));
    if (digit && i < CODE_LENGTH - 1) boxes.current[i + 1]?.focus();
  };
  const onKeyDown = (i, e) => {
    if (e.key === "Backspace" && !code[i] && i > 0) boxes.current[i - 1]?.focus();
    if (e.key === "ArrowLeft" && i > 0) boxes.current[i - 1]?.focus();
    if (e.key === "ArrowRight" && i < CODE_LENGTH - 1) boxes.current[i + 1]?.focus();
  };
  const onPaste = (e) => {
    const digits = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, CODE_LENGTH);
    if (!digits) return;
    e.preventDefault();
    setCode(Array.from({ length: CODE_LENGTH }, (_, i) => digits[i] || ""));
    boxes.current[Math.min(digits.length, CODE_LENGTH - 1)]?.focus();
  };

  const score = passwordScore(password);
  const fill = done ? 100 : ((step + 1) / STEPS.length) * 100;

  return (
    <div className="reg">
      <aside className="reg-side" aria-hidden="true">
        <svg className="reg-drop" viewBox="0 0 120 160">
          <defs>
            <clipPath id="fpClip">
              <path d="M60 6C60 6 14 62 14 100a46 46 0 0 0 92 0C106 62 60 6 60 6Z" />
            </clipPath>
          </defs>
          <path
            d="M60 6C60 6 14 62 14 100a46 46 0 0 0 92 0C106 62 60 6 60 6Z"
            fill="rgba(255,255,255,.12)"
            stroke="rgba(255,255,255,.7)"
            strokeWidth="2"
          />
          <g clipPath="url(#fpClip)">
            <rect
              className="reg-drop-fill"
              x="0"
              y="0"
              width="120"
              height="160"
              style={{ transform: `translateY(${160 - (fill / 100) * 140}px)` }}
            />
          </g>
        </svg>
        <h2>Blood Link</h2>
        <p>Locked out? We'll get you back into your account in three quick steps.</p>
      </aside>

      <main className="reg-main">
        {done ? (
          <div className="reg-success">
            <svg viewBox="0 0 52 52" className="reg-check">
              <circle cx="26" cy="26" r="24" />
              <path d="M14 27l8 8 16-17" />
            </svg>
            <h1>Password updated</h1>
            <p>You can now log in to {email} with your new password.</p>
            <Link className="reg-btn reg-btn-primary" to="/login">
              Go to login
            </Link>
          </div>
        ) : (
          <div
            className="reg-card"
            data-shake={shaking}
            onAnimationEnd={(e) => {
              if (e.target === e.currentTarget && e.animationName === "reg-shake") setShaking(false);
            }}
          >
            <h1>Reset your password</h1>

            <ol className="reg-steps" aria-label="Progress">
              {STEPS.map((s, i) => (
                <li key={s} className={i < step ? "is-done" : i === step ? "is-current" : ""}>
                  <span className="reg-dot">{i < step ? <Check size={14} /> : i + 1}</span>
                  <span className="reg-step-label">{s}</span>
                </li>
              ))}
              <span className="reg-track">
                <span style={{ width: `${(step / (STEPS.length - 1)) * 100}%` }} />
              </span>
            </ol>

            <div className="reg-viewport">
              <div className={`reg-panel ${dir}`} key={step}>
                {step === 0 && (
                  <>
                    <p className="fp-lead">Enter the email linked to your account and we'll send you a 6-digit code.</p>
                    <label className={`reg-field ${errors.email ? "has-error" : ""}`}>
                      <span>Email</span>
                      <input
                        type="email"
                        value={email}
                        autoComplete="email"
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (errors.email) setErrors({});
                        }}
                        onKeyDown={(e) => e.key === "Enter" && next()}
                      />
                      {errors.email && <small className="reg-error">{errors.email}</small>}
                    </label>
                  </>
                )}

                {step === 1 && (
                  <>
                    <p className="fp-lead">
                      We sent a code to <strong>{email}</strong>. Enter it below.
                    </p>
                    <div className={`reg-field ${errors.code ? "has-error" : ""}`} role="group" aria-label="Verification code">
                      <div className="fp-otp" onPaste={onPaste}>
                        {code.map((d, i) => (
                          <input
                            key={i}
                            ref={(el) => (boxes.current[i] = el)}
                            className={d ? "filled" : ""}
                            inputMode="numeric"
                            autoComplete={i === 0 ? "one-time-code" : "off"}
                            maxLength={1}
                            value={d}
                            aria-label={`Digit ${i + 1}`}
                            onChange={(e) => setDigit(i, e.target.value)}
                            onKeyDown={(e) => onKeyDown(i, e)}
                            onFocus={(e) => e.target.select()}
                          />
                        ))}
                      </div>
                      {errors.code && <small className="reg-error">{errors.code}</small>}
                    </div>
                    <p className="fp-resend">
                      {seconds > 0 ? (
                        <>Resend code in {seconds}s</>
                      ) : (
                        <>
                          Didn't get it?{" "}
                          <button type="button" onClick={resend}>
                            Resend code
                          </button>
                        </>
                      )}
                    </p>
                  </>
                )}

                {step === 2 && (
                  <>
                    <label className={`reg-field ${errors.password ? "has-error" : ""}`}>
                      <span>New password</span>
                      <div className="reg-pw">
                        <input
                          type={showPw ? "text" : "password"}
                          value={password}
                          autoComplete="new-password"
                          onChange={(e) => {
                            setPassword(e.target.value);
                            if (errors.password) setErrors((x) => ({ ...x, password: undefined }));
                          }}
                        />
                        <button
                          type="button"
                          className="reg-eye"
                          onClick={() => setShowPw((s) => !s)}
                          aria-label={showPw ? "Hide password" : "Show password"}
                        >
                          {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
                        </button>
                      </div>
                      <div className={`reg-meter s${score}`}>
                        <span />
                      </div>
                      {errors.password && <small className="reg-error">{errors.password}</small>}
                    </label>
                    <label className={`reg-field ${errors.confirm ? "has-error" : ""}`}>
                      <span>Confirm new password</span>
                      <input
                        type={showPw ? "text" : "password"}
                        value={confirm}
                        autoComplete="new-password"
                        onChange={(e) => {
                          setConfirm(e.target.value);
                          if (errors.confirm) setErrors((x) => ({ ...x, confirm: undefined }));
                        }}
                        onKeyDown={(e) => e.key === "Enter" && next()}
                      />
                      {errors.confirm && <small className="reg-error">{errors.confirm}</small>}
                    </label>
                  </>
                )}
              </div>
            </div>

            <div className="reg-actions">
              {step > 0 ? (
                <button type="button" className="reg-btn reg-btn-ghost" onClick={back} disabled={loading}>
                  Back
                </button>
              ) : (
                <span />
              )}
              <button type="button" className="reg-btn reg-btn-primary" onClick={next} disabled={loading}>
                {loading ? (
                  <span className="reg-spin" />
                ) : step === 0 ? (
                  "Send code"
                ) : step === 1 ? (
                  "Verify code"
                ) : (
                  "Update password"
                )}
              </button>
            </div>

            <p className="reg-login">
              Remembered it? <Link to="/login">Back to login</Link>
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
