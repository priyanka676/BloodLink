import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { Menu, Bell } from "lucide-react";
import AdminSidebar from "./AdminSidebar.jsx";
import "./admin.css";

export default function AdminLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { pathname } = useLocation();

  // Close the mobile drawer after navigating
  useEffect(() => setMobileOpen(false), [pathname]);

  // Close with Escape
  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (e) => e.key === "Escape" && setMobileOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mobileOpen]);

  return (
    <div className="adm">
      <AdminSidebar open={mobileOpen} onClose={() => setMobileOpen(false)} />
      <div className={`adm-overlay ${mobileOpen ? "show" : ""}`} onClick={() => setMobileOpen(false)} />

      <div className="adm-main">
        <header className="adm-top">
          <button
            type="button"
            className="adm-burger"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={22} />
          </button>
          <div className="adm-top-right">
            <button type="button" className="adm-icon-btn" aria-label="Notifications">
              <Bell size={20} />
              <span className="adm-dot" />
            </button>
          </div>
        </header>
        <main className="adm-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
