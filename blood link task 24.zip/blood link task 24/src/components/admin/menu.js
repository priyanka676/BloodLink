import {
  LayoutDashboard,
  Users,
  Droplets,
  Building2,
  BarChart3,
  Settings,
} from "lucide-react";

/**
 * Edit this file to change the admin side menu.
 *  - type "link":  a single item        { label, to, icon }
 *  - type "group": an accordion section { id, label, icon, children: [{ label, to }] }
 * Routes for every `to` are generated automatically in App.jsx.
 */
export const MENU = [
  { type: "link", label: "Dashboard", to: "/admin", icon: LayoutDashboard },
  {
    type: "group",
    id: "donors",
    label: "Donors",
    icon: Users,
    children: [
      { label: "All donors", to: "/admin/donors" },
      { label: "Add donor", to: "/admin/donors/new" },
      { label: "Donation history", to: "/admin/donors/history" },
    ],
  },
  {
    type: "group",
    id: "blood",
    label: "Blood bank",
    icon: Droplets,
    children: [
      { label: "Blood types", to: "/admin/blood-types" },
      { label: "Inventory", to: "/admin/inventory" },
      { label: "Requests", to: "/admin/requests" },
    ],
  },
  {
    type: "group",
    id: "network",
    label: "Hospitals & patients",
    icon: Building2,
    children: [
      { label: "Hospitals", to: "/admin/hospitals" },
      { label: "Patients", to: "/admin/patients" },
    ],
  },
  { type: "link", label: "Reports", to: "/admin/reports", icon: BarChart3 },
  {
    type: "group",
    id: "settings",
    label: "Settings",
    icon: Settings,
    children: [
      { label: "General", to: "/admin/settings" },
      { label: "Notifications", to: "/admin/settings/notifications" },
      { label: "Admin users", to: "/admin/settings/users" },
    ],
  },
];

/** Flat list of every page (except the dashboard) so App.jsx can build routes. */
export function getAdminRoutes() {
  const out = [];
  for (const item of MENU) {
    if (item.type === "link" && item.to !== "/admin") out.push({ to: item.to, label: item.label });
    if (item.type === "group") item.children.forEach((c) => out.push({ to: c.to, label: c.label, group: item.label }));
  }
  return out;
}
