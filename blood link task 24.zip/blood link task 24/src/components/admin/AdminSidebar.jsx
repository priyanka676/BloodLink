import { useEffect, useState } from "react";
import { NavLink, Link, useLocation } from "react-router-dom";
import { LogOut } from "lucide-react";
import { MENU } from "./menu.js";

const isInside = (pathname, to) => pathname === to || pathname.startsWith(to + "/");

export default function AdminSidebar({ open, onClose }) {
  const { pathname } = useLocation();

  // The group that contains the current page
  const activeGroup =
    MENU.find((m) => m.type === "group" && m.children.some((c) => isInside(pathname, c.to)))?.id ?? null;

  // Only one section open at a time (like a Bootstrap accordion)
  const [openId, setOpenId] = useState(activeGroup);

  // Keep the section of the current page open when navigating
  useEffect(() => {
    if (activeGroup) setOpenId(activeGroup);
  }, [activeGroup]);

  const toggle = (id) => setOpenId((cur) => (cur === id ? null : id));

  return (
    <aside className={`adm-sidebar ${open ? "is-open" : ""}`} aria-label="Admin menu">
      <Link to="/admin" className="adm-brand">
        <svg width="26" viewBox="0 0 120 160" aria-hidden="true">
          <path d="M60 6C60 6 14 62 14 100a46 46 0 0 0 92 0C106 62 60 6 60 6Z" fill="#fff" />
        </svg>
        <span>Blood Link</span>
      </Link>

      <nav className="adm-nav">
        <div className="accordion accordion-flush adm-accordion" id="adminMenu">
          {MENU.map((item) => {
            const Icon = item.icon;

            if (item.type === "link") {
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end
                  onClick={onClose}
                  className={({ isActive }) => `adm-single ${isActive ? "active" : ""}`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </NavLink>
              );
            }

            const isOpen = openId === item.id;
            const hasActive = item.children.some((c) => isInside(pathname, c.to));
            const panelId = `adm-panel-${item.id}`;

            return (
              <div className="accordion-item" key={item.id}>
                <h2 className="accordion-header">
                  <button
                    type="button"
                    className={`accordion-button ${isOpen ? "" : "collapsed"} ${hasActive ? "has-active" : ""}`}
                    aria-expanded={isOpen}
                    aria-controls={panelId}
                    onClick={() => toggle(item.id)}
                  >
                    <Icon size={18} />
                    <span>{item.label}</span>
                  </button>
                </h2>
                <div id={panelId} className="adm-panel" data-open={isOpen} role="region">
                  <div className="adm-panel-inner">
                    <ul className="accordion-body">
                      {item.children.map((c) => (
                        <li key={c.to}>
                          <NavLink
                            to={c.to}
                            end
                            onClick={onClose}
                            className={({ isActive }) => `adm-sub ${isActive ? "active" : ""}`}
                          >
                            {c.label}
                          </NavLink>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </nav>

      <div className="adm-user">
        <div className="adm-avatar">AD</div>
        <div className="adm-user-text">
          <strong>Admin</strong>
          <small>admin@bloodlink.org</small>
        </div>
        <Link to="/login" className="adm-logout" aria-label="Log out" title="Log out">
          <LogOut size={18} />
        </Link>
      </div>
    </aside>
  );
}
