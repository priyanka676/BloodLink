import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import ForgotPassword from "./pages/ForgotPassword.jsx";
import Blogdetails from "./pages/Blogdetails.jsx";
import AdminLayout from "./components/admin/AdminLayout.jsx";
import AdminDashboard from "./pages/admin/AdminDashboard.jsx";
import AdminPage from "./pages/admin/AdminPage.jsx";
import { getAdminRoutes } from "./components/admin/menu.js";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/blog-detail" element={<Blogdetails />} />

      {/* Admin area: every page in src/components/admin/menu.js gets a route automatically */}
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
        {getAdminRoutes().map((r) => (
          <Route
            key={r.to}
            path={r.to.replace("/admin/", "")}
            element={<AdminPage title={r.label} group={r.group} />}
          />
        ))}
        <Route path="*" element={<Navigate to="/admin" replace />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
