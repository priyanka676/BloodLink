@echo off
echo Installing packages (first run only)...
call npm install
call npm run dev
