import './FormInput.css'

/**
 * Reusable form field.
 * Props:
 *  label, name, type ("text" | "email" | "password" | "tel" | "select" | "textarea" ...)
 *  value, onChange, onBlur, placeholder
 *  options   – for type="select": [{ value, label }] or ["A+", "B+"]
 *  error     – error message string (shows red state)
 *  hint      – helper text under the field
 *  required  – shows asterisk
 *  ...rest   – any other native attribute (maxLength, autoComplete, etc.)
 */
export default function FormInput({
  label,
  name,
  type = 'text',
  value,
  onChange,
  onBlur,
  placeholder,
  options = [],
  error,
  hint,
  required = false,
  ...rest
}) {
  const id = `field-${name}`
  const describedBy = error ? `${id}-error` : hint ? `${id}-hint` : undefined
  const common = {
    id,
    name,
    value,
    onChange,
    onBlur,
    placeholder,
    required,
    'aria-invalid': !!error,
    'aria-describedby': describedBy,
    className: `fi-control${error ? ' fi-control--error' : ''}`,
    ...rest,
  }

  let control
  if (type === 'select') {
    control = (
      <select {...common}>
        <option value="">{placeholder || 'Select…'}</option>
        {options.map((o) => {
          const opt = typeof o === 'string' ? { value: o, label: o } : o
          return (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          )
        })}
      </select>
    )
  } else if (type === 'textarea') {
    control = <textarea rows={3} {...common} />
  } else {
    control = <input type={type} {...common} />
  }

  return (
    <div className="fi-field">
      <label htmlFor={id} className="fi-label">
        {label}
        {required && <span className="fi-req"> *</span>}
      </label>
      {control}
      {error ? (
        <p id={`${id}-error`} className="fi-error" role="alert">{error}</p>
      ) : hint ? (
        <p id={`${id}-hint`} className="fi-hint">{hint}</p>
      ) : null}
    </div>
  )
}
