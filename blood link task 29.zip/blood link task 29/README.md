# Blood Link Skeleton Loader UI

Run:
npm install
npm run dev

Open http://localhost:5173/

The page simulates an API request for 1.8 seconds and displays animated skeleton cards and table rows during loading. Replace the setTimeout in src/App.jsx with your fetch() or Axios API request when connecting your backend.