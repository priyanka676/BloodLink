import React,{useEffect,useState}from"react";

const donorData=[
{id:"D-501",name:"Priyanka Rana",blood:"O+",city:"Ahmedabad",units:3,status:"Available"},
{id:"D-502",name:"Devang Gohil",blood:"A+",city:"Surat",units:2,status:"Available"},
{id:"D-503",name:"Riya Shah",blood:"B+",city:"Vadodara",units:4,status:"Available"},
{id:"D-504",name:"Aarav Patel",blood:"AB+",city:"Rajkot",units:1,status:"Available"},
{id:"D-505",name:"Neha Joshi",blood:"O-",city:"Surat",units:2,status:"Available"},
{id:"D-506",name:"Karan Mehta",blood:"A-",city:"Ahmedabad",units:1,status:"Available"}];

function SkeletonRow(){return <tr>{[1,2,3,4,5,6].map(i=><td key={i}><span className={"skeleton "+(i===2?"skeleton-name":"")}/></td>)}</tr>}
function SkeletonCards(){return <div className="row g-4">{[1,2,3].map(i=><div className="col-md-4" key={i}><div className="donor-card"><div className="d-flex align-items-center gap-3"><span className="skeleton skeleton-avatar"/><div className="flex-grow-1"><span className="skeleton skeleton-line"/><span className="skeleton skeleton-line short"/></div></div><span className="skeleton skeleton-block mt-4"/><span className="skeleton skeleton-block small"/></div></div>)}</div>}

export default function App(){
const[loading,setLoading]=useState(true),[error,setError]=useState(false),[donors,setDonors]=useState([]),[bloodGroup,setBloodGroup]=useState("All"),[city,setCity]=useState("All");
const loadDonors=()=>{setLoading(true);setError(false);setDonors([]);setTimeout(()=>{setDonors(donorData);setLoading(false)},1800)};
useEffect(()=>{loadDonors()},[]);
const filtered=donors.filter(d=>(bloodGroup==="All"||d.blood===bloodGroup)&&(city==="All"||d.city===city));
return <div className="app">
<nav className="navbar navbar-dark"><div className="container"><span className="navbar-brand fw-bold">♥ Blood Link</span><span className="navbar-text text-white-50">Skeleton Loader Demo</span></div></nav>
<main className="container py-5">
<div className="hero mb-4"><div><span className="eyebrow">BLOOD AVAILABILITY</span><h1>Find Available Blood</h1><p>Skeleton loaders display while donor data is being fetched from an API.</p></div><button className="btn btn-light" onClick={loadDonors}>↻ Refresh API</button></div>
<div className="filter-box mb-4"><div className="row g-3 align-items-end">
<div className="col-md-5"><label className="form-label">Blood Group</label><select className="form-select" value={bloodGroup} onChange={e=>setBloodGroup(e.target.value)} disabled={loading}>{["All","A+","A-","B+","B-","AB+","AB-","O+","O-"].map(x=><option key={x}>{x}</option>)}</select></div>
<div className="col-md-5"><label className="form-label">City</label><select className="form-select" value={city} onChange={e=>setCity(e.target.value)} disabled={loading}>{["All","Ahmedabad","Surat","Vadodara","Rajkot"].map(x=><option key={x}>{x}</option>)}</select></div>
<div className="col-md-2"><button className="btn btn-danger w-100" onClick={loadDonors} disabled={loading}>{loading?"Loading...":"Search"}</button></div>
</div></div>
{loading&&<><div className="loading-message mb-3"><span className="spinner-border spinner-border-sm me-2"/>Loading donor data...</div><SkeletonCards/><div className="table-box mt-4"><div className="table-responsive"><table className="table align-middle mb-0"><thead><tr><th>ID</th><th>Donor</th><th>Blood</th><th>City</th><th>Units</th><th>Status</th></tr></thead><tbody>{[1,2,3,4].map(i=><SkeletonRow key={i}/>)}</tbody></table></div></div></>}
{!loading&&!error&&<><div className="result-count mb-3"><strong>{filtered.length}</strong> available donor records</div><div className="table-box"><div className="table-responsive"><table className="table align-middle mb-0"><thead><tr><th>Donor ID</th><th>Donor Name</th><th>Blood Group</th><th>City</th><th>Units</th><th>Status</th></tr></thead><tbody>{filtered.length?filtered.map(d=><tr key={d.id}><td className="fw-semibold">{d.id}</td><td>{d.name}</td><td><span className="blood-badge">{d.blood}</span></td><td>{d.city}</td><td>{d.units}</td><td><span className="status-badge">● {d.status}</span></td></tr>):<tr><td colSpan="6" className="text-center py-5 text-muted">No matching blood records found.</td></tr>}</tbody></table></div></div></>}
{!loading&&error&&<div className="error-box text-center"><h4>Unable to load blood availability</h4><p className="text-muted">Something went wrong while calling the API.</p><button className="btn btn-danger" onClick={loadDonors}>Try Again</button></div>}
<div className="api-note mt-4"><strong>Skeleton logic:</strong> <code>loading=true</code> shows animated placeholders; after the API response, the skeleton disappears and real donor data is rendered.</div>
</main></div>}