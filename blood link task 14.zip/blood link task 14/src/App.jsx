import { Routes, Route, Navigate } from 'react-router-dom'
import DonorSchedule from './pages/donor/DonorSchedule.jsx'

export default function App() {
  return (
    <Routes>
      <Route path="/donor/schedule" element={<DonorSchedule />} />
      <Route path="*" element={<Navigate to="/donor/schedule" replace />} />
    </Routes>
  )
}
