import { useEffect, useMemo, useState } from 'react'
import { Droplet, CalendarDays, Clock, MapPin, CheckCircle2, Trash2, AlertCircle } from 'lucide-react'
import './DonorSchedule.css'

const STORAGE_KEY = 'bloodlink_appointments'
const CAPACITY = 3 // donors per slot
const GAP_DAYS = 90 // minimum days between donations
const BLOOD_TYPES = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
const CENTERS = [
  'Blood Link Central Bank',
  'City Hospital Donation Camp',
  'Red Cross Community Center',
  'University Health Center',
]
const SLOTS = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00']
const CHECKS = [
  'I am between 18 and 65 years old',
  'I weigh at least 50 kg',
  'I feel healthy today (no fever, cold or infection)',
  'I have not had a tattoo, surgery or new medication in the last 6 months',
]

const iso = (d) => {
  const x = new Date(d.getTime() - d.getTimezoneOffset() * 60000)
  return x.toISOString().slice(0, 10)
}
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }
const load = () => { try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [] } catch { return [] } }
const fmtDate = (s) => new Date(s + 'T00:00').toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' })

const empty = { name: '', phone: '', email: '', bloodType: '', lastDonation: '', center: CENTERS[0], date: '', slot: '' }

export default function DonorSchedule() {
  const [appts, setAppts] = useState(load)
  const [form, setForm] = useState(empty)
  const [checks, setChecks] = useState(CHECKS.map(() => false))
  const [errors, setErrors] = useState({})
  const [done, setDone] = useState(null)

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(appts)) }, [appts])

  const today = new Date()
  const minDate = iso(today)
  const maxDate = iso(addDays(today, 60))
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v, ...(k === 'center' || k === 'date' ? { slot: '' } : {}) }))

  const booked = useMemo(() => {
    const m = {}
    appts.forEach((a) => { const k = `${a.center}|${a.date}|${a.slot}`; m[k] = (m[k] || 0) + 1 })
    return m
  }, [appts])

  const slotState = (slot) => {
    const left = CAPACITY - (booked[`${form.center}|${form.date}|${slot}`] || 0)
    const past = form.date === minDate && new Date(`${form.date}T${slot}`) <= new Date()
    return { left, disabled: left <= 0 || past }
  }

  const validate = () => {
    const e = {}
    if (form.name.trim().length < 2) e.name = 'Enter your full name'
    if (!/^[0-9+\-\s]{10,15}$/.test(form.phone.trim())) e.phone = 'Enter a valid phone number'
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) e.email = 'Enter a valid email'
    if (!form.bloodType) e.bloodType = 'Select your blood type'
    if (form.lastDonation) {
      const next = addDays(new Date(form.lastDonation + 'T00:00'), GAP_DAYS)
      if (form.date && new Date(form.date + 'T00:00') < next)
        e.lastDonation = `You can donate again from ${fmtDate(iso(next))}`
    }
    if (!form.date) e.date = 'Pick a date'
    if (!form.slot) e.slot = 'Pick a time slot'
    if (checks.some((c) => !c)) e.checks = 'Please confirm all eligibility statements'
    if (form.date && form.slot && appts.some((a) => a.date === form.date && a.slot === form.slot && a.phone === form.phone.trim()))
      e.slot = 'You already have an appointment at this time'
    return e
  }

  const submit = (ev) => {
    ev.preventDefault()
    const e = validate()
    setErrors(e)
    if (Object.keys(e).length) return
    const appt = { id: 'BL' + Date.now().toString(36).toUpperCase(), ...form, name: form.name.trim(), phone: form.phone.trim(), createdAt: new Date().toISOString() }
    setAppts((a) => [...a, appt])
    setDone(appt)
    setForm(empty)
    setChecks(CHECKS.map(() => false))
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const cancel = (id) => {
    if (window.confirm('Cancel this appointment?')) setAppts((a) => a.filter((x) => x.id !== id))
  }

  const sorted = [...appts].sort((a, b) => `${a.date}${a.slot}`.localeCompare(`${b.date}${b.slot}`))
  const isPast = (a) => new Date(`${a.date}T${a.slot}`) < new Date()

  return (
    <div className="ds-page">
      <header className="ds-hero">
        <Droplet size={36} />
        <div>
          <h1>Schedule a Blood Donation</h1>
          <p>One donation can save up to three lives. Choose a center, date and time that suits you.</p>
        </div>
      </header>

      {done && (
        <div className="ds-success">
          <CheckCircle2 size={22} />
          <div>
            <strong>Appointment confirmed!</strong> Ref <b>{done.id}</b> – {fmtDate(done.date)} at {done.slot}, {done.center}.
            Please eat well and drink water before you come.
          </div>
          <button onClick={() => setDone(null)} aria-label="Dismiss">×</button>
        </div>
      )}

      <div className="ds-grid">
        <form className="ds-card" onSubmit={submit} noValidate>
          <h2>Donor details</h2>
          <div className="ds-row">
            <Field label="Full name" error={errors.name}>
              <input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Your name" />
            </Field>
            <Field label="Phone" error={errors.phone}>
              <input value={form.phone} onChange={(e) => set('phone', e.target.value)} placeholder="9876543210" inputMode="tel" />
            </Field>
          </div>
          <div className="ds-row">
            <Field label="Email (optional)" error={errors.email}>
              <input type="email" value={form.email} onChange={(e) => set('email', e.target.value)} placeholder="you@example.com" />
            </Field>
            <Field label="Blood type" error={errors.bloodType}>
              <select value={form.bloodType} onChange={(e) => set('bloodType', e.target.value)}>
                <option value="">Select…</option>
                {BLOOD_TYPES.map((b) => <option key={b}>{b}</option>)}
              </select>
            </Field>
          </div>
          <Field label="Last donation date (optional)" error={errors.lastDonation}>
            <input type="date" max={minDate} value={form.lastDonation} onChange={(e) => set('lastDonation', e.target.value)} />
          </Field>

          <h2><MapPin size={18} /> Center &amp; date</h2>
          <div className="ds-row">
            <Field label="Donation center">
              <select value={form.center} onChange={(e) => set('center', e.target.value)}>
                {CENTERS.map((c) => <option key={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Date" error={errors.date}>
              <input type="date" min={minDate} max={maxDate} value={form.date} onChange={(e) => set('date', e.target.value)} />
            </Field>
          </div>

          <h2><Clock size={18} /> Time slot</h2>
          {!form.date ? (
            <p className="ds-muted">Select a date to see available slots.</p>
          ) : (
            <div className="ds-slots">
              {SLOTS.map((s) => {
                const { left, disabled } = slotState(s)
                return (
                  <button type="button" key={s} disabled={disabled}
                    className={`ds-slot ${form.slot === s ? 'active' : ''}`} onClick={() => set('slot', s)}>
                    {s}<small>{left <= 0 ? 'Full' : `${left} left`}</small>
                  </button>
                )
              })}
            </div>
          )}
          {errors.slot && <p className="ds-error">{errors.slot}</p>}

          <h2>Eligibility</h2>
          <div className="ds-checks">
            {CHECKS.map((c, i) => (
              <label key={c}>
                <input type="checkbox" checked={checks[i]} onChange={() => setChecks((p) => p.map((v, j) => (j === i ? !v : v)))} />
                {c}
              </label>
            ))}
          </div>
          {errors.checks && <p className="ds-error">{errors.checks}</p>}

          <button className="ds-submit" type="submit"><CalendarDays size={18} /> Book appointment</button>
        </form>

        <aside className="ds-card">
          <h2>My appointments</h2>
          {sorted.length === 0 && <p className="ds-muted">No appointments yet.</p>}
          {sorted.map((a) => (
            <div key={a.id} className={`ds-appt ${isPast(a) ? 'past' : ''}`}>
              <div className="ds-badge">{a.bloodType}</div>
              <div className="ds-appt-info">
                <b>{a.name}</b>
                <span>{fmtDate(a.date)} · {a.slot}</span>
                <span>{a.center}</span>
                <small>Ref {a.id} · {isPast(a) ? 'Completed / past' : 'Upcoming'}</small>
              </div>
              {!isPast(a) && (
                <button className="ds-icon" onClick={() => cancel(a.id)} title="Cancel"><Trash2 size={18} /></button>
              )}
            </div>
          ))}
          <div className="ds-note"><AlertCircle size={16} /> Appointments are saved in this browser. Connect an API to share them with the admin dashboard.</div>
        </aside>
      </div>
    </div>
  )
}

function Field({ label, error, children }) {
  return (
    <label className="ds-field">
      <span>{label}</span>
      {children}
      {error && <em className="ds-error">{error}</em>}
    </label>
  )
}
