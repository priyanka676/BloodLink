# Blood Link – Donor Scheduling

## Run
```
npm install
npm run dev
```
Open http://localhost:5173/donor/schedule

## Add to your existing Blood Link project
1. Copy `src/pages/donor/` (DonorSchedule.jsx + DonorSchedule.css) into your project's `src/pages/`.
2. `npm i lucide-react react-router-dom` (already in your project).
3. In `App.jsx` add:
   `import DonorSchedule from './pages/donor/DonorSchedule.jsx'`
   `<Route path="/donor/schedule" element={<DonorSchedule />} />`
4. Add a link in your Sidebar/Navbar pointing to `/donor/schedule`.

Appointments are stored in localStorage (`bloodlink_appointments`). To use a backend, replace the
`setAppts` / `localStorage` calls with API requests.
