const form = document.getElementById("registerForm");
const email = document.getElementById("email");
const password = document.getElementById("password");
const confirmPassword = document.getElementById("confirmPassword");
const emailError = document.getElementById("emailError");
const passwordError = document.getElementById("passwordError");
const confirmPasswordError = document.getElementById("confirmPasswordError");

form.addEventListener("submit", function (event) {
    event.preventDefault();
    emailError.textContent = "";
    passwordError.textContent = "";
    confirmPasswordError.textContent = "";

    email.classList.remove("is-invalid", "is-valid");
    password.classList.remove("is-invalid", "is-valid");
    confirmPassword.classList.remove("is-invalid", "is-valid");

    let isValid = true;
    const emailValue = email.value.trim();
    const passwordValue = password.value;
    const confirmPasswordValue = confirmPassword.value;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (emailValue === "") {
        emailError.textContent = "Email is required.";
        email.classList.add("is-invalid");
        isValid = false;
    } 
    else if (!emailPattern.test(emailValue)) {
        emailError.textContent = "Please enter a valid email address.";
        email.classList.add("is-invalid");
        isValid = false;
    } 
    else {
        email.classList.add("is-valid");
    }
    if (passwordValue === "") {
        passwordError.textContent = "Password is required.";
        password.classList.add("is-invalid");
        isValid = false;
    } 
    else if (passwordValue.length < 8) {
        passwordError.textContent =
            "Password must be at least 8 characters.";
        password.classList.add("is-invalid");
        isValid = false;
    } 
    else if (!/[A-Z]/.test(passwordValue)) {
        passwordError.textContent =
            "Password must contain at least one uppercase letter.";
        password.classList.add("is-invalid");
        isValid = false;
    } 
    else if (!/[a-z]/.test(passwordValue)) {
        passwordError.textContent =
            "Password must contain at least one lowercase letter.";
        password.classList.add("is-invalid");
        isValid = false;
    } 
    else if (!/[0-9]/.test(passwordValue)) {
        passwordError.textContent =
            "Password must contain at least one number.";
        password.classList.add("is-invalid");
        isValid = false;
    } 
    else if (!/[!@#$%^&*]/.test(passwordValue)) {
        passwordError.textContent =
            "Password must contain at least one special character.";
        password.classList.add("is-invalid");
        isValid = false;
    } 
    else {
        password.classList.add("is-valid");
    }
    if (confirmPasswordValue === "") {
        confirmPasswordError.textContent =
            "Please confirm your password.";
        confirmPassword.classList.add("is-invalid");
        isValid = false;
    } 
    else if (passwordValue !== confirmPasswordValue) {
        confirmPasswordError.textContent =
            "Passwords do not match.";
        confirmPassword.classList.add("is-invalid");
        isValid = false;
    } 
    else {
        confirmPassword.classList.add("is-valid");
    }
    if (isValid) {
        alert("Registration successful!");
        console.log("Email:", emailValue);
        console.log("Password:", passwordValue);
        form.reset();
        email.classList.remove("is-valid");
        password.classList.remove("is-valid");
        confirmPassword.classList.remove("is-valid");
    }
});