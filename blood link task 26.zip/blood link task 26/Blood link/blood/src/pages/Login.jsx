import React, { useState } from "react";
import { Droplets, ShieldCheck, UserRound, HeartPulse } from "lucide-react";

export default function Login({ onLogin }) {
  const [role, setRole] = useState("admin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submit = e => {
    e.preventDefault();
    if (!email || !password) return alert("Please enter email and password.");
    onLogin(role, role === "admin" ? "Administrator" : role === "donor" ? "Priyanka Rana" : "Rahul Patel");
  };

  return <div className="login-page">
    <div className="login-card">
      <div className="login-logo"><Droplets size={34} /></div>
      <h1>Welcome to BloodLink</h1><p>Blood Management System</p>
      <div className="role-tabs">
        <button className={role === "admin" ? "active" : ""} onClick={() => setRole("admin")}><ShieldCheck size={17} /> Admin</button>
        <button className={role === "patient" ? "active" : ""} onClick={() => setRole("patient")}><UserRound size={17} /> Patient</button>
        <button type="button" className={role === "donor" ? "active" : ""} onClick={() => setRole("donor")}><HeartPulse size={17} /> Donor</button>
      </div>
      <form onSubmit={submit}>
        <label>Email Address</label><input type="email" placeholder="admin@bloodlink.com" value={email} onChange={e => setEmail(e.target.value)} />
        <label>Password</label><input type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
        <div className="form-row"><label className="check"><input type="checkbox" /> Remember me</label><a href="#forgot">Forgot password?</a></div>
        <button className="primary full">{role === "admin" ? "Sign in as Admin" : role === "donor" ? "Sign in as Donor" : "Sign in as Patient"}</button>
      </form>
      <div className="demo-note">Demo: enter any valid email and password.</div>
    </div>
  </div>;
}