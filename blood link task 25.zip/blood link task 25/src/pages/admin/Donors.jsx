import React, { useState } from "react";

import {
  LayoutDashboard,
  Users,
  HeartPulse,
  Droplets,
  ClipboardList,
  Package,
  Hospital,
  BarChart3,
  Settings,
  Bell,
  UserCircle,
  LogOut,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Eye,
} from "lucide-react";

import "./Donor.css";

const donorsData = [
  {
    id: "D-501",
    name: "Priyanka Rana",
    blood: "O+",
    age: 26,
    city: "Ahmedabad",
    donations: 12,
    status: "Available",
  },
  {
    id: "D-502",
    name: "Devang Gohil",
    blood: "A+",
    age: 29,
    city: "Surat",
    donations: 8,
    status: "Available",
  },
  {
    id: "D-503",
    name: "Jay Patel",
    blood: "B+",
    age: 33,
    city: "Vadodara",
    donations: 15,
    status: "Unavailable",
  },
  {
    id: "D-504",
    name: "Nisha Rao",
    blood: "O-",
    age: 27,
    city: "Ahmedabad",
    donations: 5,
    status: "Available",
  },
  {
    id: "D-505",
    name: "Rahul Shah",
    blood: "AB+",
    age: 31,
    city: "Rajkot",
    donations: 10,
    status: "Available",
  },
  {
    id: "D-506",
    name: "Meera Patel",
    blood: "B-",
    age: 25,
    city: "Surat",
    donations: 6,
    status: "Unavailable",
  },
];

function Donors() {
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const filteredDonors = donorsData.filter((donor) => {
    const searchText = search.toLowerCase();

    return (
      donor.name.toLowerCase().includes(searchText) ||
      donor.id.toLowerCase().includes(searchText) ||
      donor.blood.toLowerCase().includes(searchText) ||
      donor.city.toLowerCase().includes(searchText)
    );
  });

  return (
    <div className="bloodlink-wrapper">
      <main className="blood-main container-fluid">
        <section className="content-area">
          <div className="page-heading">
            <div>
              <h2>
                Donors
              </h2>
              <p>
                View and manage registered blood donors.
              </p>

            </div>
            <button
              className="add-donor-btn"
              onClick={() => setShowModal(true)}
            >

              <Plus size={17} />

              Add Donor

            </button>

          </div>

          <div className="donor-stats">
            <div className="stat-card">

              <div className="stat-icon red">

                <Users size={22} />

              </div>

              <div>

                <span>
                  Total Donors
                </span>

                <h3>
                  156
                </h3>

              </div>

            </div>

            <div className="stat-card">

              <div className="stat-icon green">

                <HeartPulse size={22} />

              </div>

              <div>

                <span>
                  Available
                </span>

                <h3>
                  128
                </h3>

              </div>

            </div>


            <div className="stat-card">

              <div className="stat-icon blue">

                <Droplets size={22} />

              </div>

              <div>

                <span>
                  Total Donations
                </span>

                <h3>
                  1,245
                </h3>

              </div>

            </div>

            <div className="stat-card">

              <div className="stat-icon orange">

                <ClipboardList size={22} />

              </div>

              <div>

                <span>
                  This Month
                </span>

                <h3>
                  42
                </h3>

              </div>

            </div>

          </div>



          <div className="donor-card">
            <div className="table-toolbar">
              <div className="search-box">

                <Search size={17} />

                <input
                  type="text"
                  placeholder="Search donor..."
                  value={search}
                  onChange={(e) =>
                    setSearch(e.target.value)
                  }
                />

              </div>
              <button className="filter-btn">

                <Filter size={16} />

                Filter

              </button>

            </div>


            <div className="table-responsive">

              <table className="donor-table">

                <thead>

                  <tr>

                    <th>ID</th>

                    <th>DONOR</th>

                    <th>BLOOD TYPE</th>

                    <th>AGE</th>

                    <th>CITY</th>

                    <th>DONATIONS</th>

                    <th>STATUS</th>

                    <th>ACTION</th>

                  </tr>

                </thead>


                <tbody>

                  {filteredDonors.map((donor) => (
                    <tr key={donor.id}>
                      <td>

                        <span className="donor-id">
                          {donor.id}
                        </span>

                      </td>

                      <td>

                        <div className="donor-name">

                          <div className="donor-avatar">

                            {donor.name.charAt(0)}

                          </div>

                          <div>

                            <strong>
                              {donor.name}
                            </strong>

                            <small>
                              Blood Donor
                            </small>

                          </div>

                        </div>

                      </td>

                      <td>

                        <span className="blood-badge">

                          {donor.blood}

                        </span>

                      </td>


                      <td>
                        {donor.age}
                      </td>


                      <td>
                        {donor.city}
                      </td>

                      <td>

                        <strong className="donation-count">

                          {donor.donations}

                        </strong>

                      </td>

                      <td>

                        <span
                          className={
                            donor.status === "Available"
                              ? "status available"
                              : "status unavailable"
                          }
                        >

                          <span className="status-dot"></span>

                          {donor.status}

                        </span>

                      </td>

                      <td>

                        <div className="action-buttons">

                          <button title="View">

                            <Eye size={15} />

                          </button>

                          <button title="Edit">

                            <Edit size={15} />

                          </button>

                          <button title="Delete">

                            <Trash2 size={15} />

                          </button>

                          <button title="More">

                            <MoreVertical size={15} />

                          </button>

                        </div>

                      </td>

                    </tr>

                  ))}

                </tbody>

              </table>

              {filteredDonors.length === 0 && (

                <div className="no-data">

                  No donors found.

                </div>

              )}

            </div>

            <div className="table-footer">

              <span>

                Showing <strong>1</strong> to{" "}

                <strong>
                  {filteredDonors.length}
                </strong>{" "}

                of <strong>156</strong> donors

              </span>


              <div className="pagination">

                <button>
                  ‹
                </button>

                <button className="current">
                  1
                </button>

                <button>
                  2
                </button>

                <button>
                  3
                </button>

                <button>
                  4
                </button>

                <button>
                  5
                </button>

                <button>
                  ›
                </button>

              </div>

            </div>

          </div>

        </section>

      </main>

      {showModal && (

        <div className="modal-overlay">

          <div className="donor-modal">

            <div className="modal-header">

              <div>

                <h4>
                  Add New Donor
                </h4>

                <p>
                  Register a new blood donor.
                </p>

              </div>


              <button
                className="close-modal"
                onClick={() => setShowModal(false)}
              >
                ×
              </button>

            </div>

            <div className="modal-body">

              <div className="form-grid">
                <div className="form-group">

                  <label>
                    Full Name
                  </label>

                  <input
                    type="text"
                    placeholder="Enter donor name"
                  />

                </div>


                {/* BLOOD TYPE */}

                <div className="form-group">

                  <label>
                    Blood Type
                  </label>

                  <select>

                    <option>
                      Select blood type
                    </option>

                    <option>A+</option>
                    <option>A-</option>
                    <option>B+</option>
                    <option>B-</option>
                    <option>AB+</option>
                    <option>AB-</option>
                    <option>O+</option>
                    <option>O-</option>

                  </select>

                </div>

                <div className="form-group">

                  <label>
                    Age
                  </label>

                  <input
                    type="number"
                    placeholder="Enter age"
                  />

                </div>

                <div className="form-group">

                  <label>
                    City
                  </label>

                  <input
                    type="text"
                    placeholder="Enter city"
                  />

                </div>


                <div className="form-group">

                  <label>
                    Phone Number
                  </label>

                  <input
                    type="text"
                    placeholder="Enter phone number"
                  />

                </div>

                <div className="form-group">

                  <label>
                    Email
                  </label>

                  <input
                    type="email"
                    placeholder="Enter email"
                  />

                </div>

              </div>

            </div>

            <div className="modal-footer">

              <button
                className="cancel-btn"
                onClick={() => setShowModal(false)}
              >

                Cancel

              </button>


              <button className="save-btn">

                <Plus size={16} />

                Add Donor

              </button>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}

export default Donors;