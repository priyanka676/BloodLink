import React, { createContext, useContext, useEffect, useRef, useState } from "react";
import {
  Camera, Pencil, Save, X, UserCircle, Droplets, Phone, Mail,
  MapPin, ShieldAlert, Lock, Trash2, CheckCircle2
} from "lucide-react";
import "./Profile.css";

const STORAGE_KEY = "bloodlink_patient_profile";
const BLOOD_TYPES = ["O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"];

const DEFAULT_PROFILE = {
  fullName: "Rahul Patel",
  email: "rahul@example.com",
  phone: "+91 98765 43210",
  dob: "1995-04-12",
  gender: "Male",
  bloodType: "O+",
  weight: "68",
  city: "Ahmedabad",
  state: "Gujarat",
  pincode: "380001",
  address: "Ahmedabad, Gujarat",
  allergies: "",
  conditions: "",
  emergencyName: "",
  emergencyPhone: "",
  avatar: ""
};

const PHONE_RE = /^\+?[0-9\s-]{10,15}$/;

function loadProfile() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved ? { ...DEFAULT_PROFILE, ...saved } : DEFAULT_PROFILE;
  } catch {
    return DEFAULT_PROFILE;
  }
}

function validate(p) {
  const e = {};
  if (p.fullName.trim().length < 3) e.fullName = "Enter your full name (min 3 characters).";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.email.trim())) e.email = "Enter a valid email address.";
  if (!PHONE_RE.test(p.phone.trim())) e.phone = "Enter a valid phone number (10-15 digits).";
  if (!p.dob) e.dob = "Date of birth is required.";
  else if (new Date(p.dob) > new Date() || calcAge(p.dob) > 120) e.dob = "Enter a valid date of birth.";
  if (p.weight && (Number(p.weight) < 1 || Number(p.weight) > 300)) e.weight = "Weight must be between 1 and 300 kg.";
  if (p.pincode && !/^[0-9]{6}$/.test(p.pincode)) e.pincode = "Pincode must be 6 digits.";
  if (p.emergencyPhone && !PHONE_RE.test(p.emergencyPhone.trim()))
    e.emergencyPhone = "Enter a valid emergency phone number.";
  return e;
}

function calcAge(dob) {
  if (!dob) return "-";
  const d = new Date(dob);
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age--;
  return age >= 0 ? age : "-";
}

/* Field lives outside Profile so inputs don't remount (and lose focus) on every keystroke */
const FormCtx = createContext(null);

function Field({ name, label, type = "text", full, children, ...rest }) {
  const { form, errors, editing, change } = useContext(FormCtx);
  const kind = children ? null : type === "textarea" ? "textarea" : "input";
  return (
    <label className={`pf-field${full ? " full-field" : ""}${errors[name] ? " has-error" : ""}`}>
      {label}
      {children
        ? React.cloneElement(children, { name, value: form[name], onChange: change, disabled: !editing })
        : kind && <input type={type} name={name} value={form[name]} onChange={change} disabled={!editing} {...rest} />}
      {errors[name] && <span className="pf-error">{errors[name]}</span>}
    </label>
  );
}

export default function Profile({ onUpdateUser }) {
  const [saved, setSaved] = useState(loadProfile);
  const [form, setForm] = useState(saved);
  const [editing, setEditing] = useState(false);
  const [errors, setErrors] = useState({});
  const [toast, setToast] = useState("");
  const fileRef = useRef(null);

  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [pwErrors, setPwErrors] = useState({});

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 3000);
    return () => clearTimeout(t);
  }, [toast]);

  const change = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => (er[name] ? { ...er, [name]: undefined } : er));
  };

  const startEdit = () => { setForm(saved); setErrors({}); setEditing(true); };
  const cancelEdit = () => { setForm(saved); setErrors({}); setEditing(false); };

  const save = (e) => {
    e.preventDefault();
    const errs = validate(form);
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const clean = {
      ...form,
      fullName: form.fullName.trim(),
      email: form.email.trim(),
      phone: form.phone.trim()
    };
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(clean)); } catch { /* storage full */ }
    setSaved(clean);
    setForm(clean);
    setEditing(false);
    if (onUpdateUser) onUpdateUser({ name: clean.fullName });
    setToast("Profile updated successfully.");
  };

  const pickAvatar = (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) return setToast("Please choose an image file.");
    if (file.size > 1024 * 1024) return setToast("Image must be smaller than 1 MB.");
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, avatar: reader.result }));
    reader.readAsDataURL(file);
  };

  const changePassword = (e) => {
    e.preventDefault();
    const er = {};
    if (!pw.current) er.current = "Enter your current password.";
    if (pw.next.length < 8) er.next = "New password must be at least 8 characters.";
    else if (pw.next === pw.current) er.next = "New password must be different.";
    if (pw.confirm !== pw.next) er.confirm = "Passwords do not match.";
    setPwErrors(er);
    if (Object.keys(er).length) return;
    // TODO: call your backend API here to change the password.
    setPw({ current: "", next: "", confirm: "" });
    setToast("Password changed successfully.");
  };

  const view = editing ? form : saved;
  const initials = view.fullName.split(" ").filter(Boolean).map((w) => w[0]).slice(0, 2).join("").toUpperCase();

  return (
    <>
      <div className="page-head">
        <div>
          <h1>My Profile</h1>
          <p>View and edit your personal and medical information.</p>
        </div>
        {!editing && (
          <button className="primary" onClick={startEdit}>
            <Pencil size={16} /> Edit Profile
          </button>
        )}
      </div>

      {toast && <div className="pf-toast"><CheckCircle2 size={17} /> {toast}</div>}

      <section className="panel pf-summary">
        <div className="pf-avatar-wrap">
          {view.avatar
            ? <img src={view.avatar} alt="Profile" className="pf-avatar" />
            : <div className="pf-avatar pf-avatar-fallback">{initials || <UserCircle size={40} />}</div>}
          {editing && (
            <>
              <button type="button" className="pf-avatar-btn" title="Change photo" onClick={() => fileRef.current?.click()}>
                <Camera size={15} />
              </button>
              <input ref={fileRef} type="file" accept="image/*" hidden onChange={pickAvatar} />
            </>
          )}
        </div>

        <div className="pf-summary-info">
          <h2>{view.fullName}</h2>
          <div className="pf-meta">
            <span><Mail size={14} /> {view.email}</span>
            <span><Phone size={14} /> {view.phone}</span>
            <span><MapPin size={14} /> {view.city}{view.state ? `, ${view.state}` : ""}</span>
          </div>
          {editing && view.avatar && (
            <button type="button" className="pf-link-btn" onClick={() => setForm((f) => ({ ...f, avatar: "" }))}>
              <Trash2 size={13} /> Remove photo
            </button>
          )}
        </div>

        <div className="pf-badges">
          <div className="pf-badge-box red"><Droplets size={18} /><strong>{view.bloodType}</strong><small>Blood Type</small></div>
          <div className="pf-badge-box"><strong>{calcAge(view.dob)}</strong><small>Age</small></div>
          <div className="pf-badge-box"><strong>{view.weight || "-"}</strong><small>Weight (kg)</small></div>
        </div>
      </section>

      <FormCtx.Provider value={{ form, errors, editing, change }}>
        <form onSubmit={save} noValidate>
          <section className="panel form-panel pf-section">
            <div className="panel-head"><h3>Personal Information</h3></div>
            <div className="form-grid">
              <Field name="fullName" label="Full Name" />
              <Field name="email" label="Email" type="email" />
              <Field name="phone" label="Phone" />
              <Field name="dob" label="Date of Birth" type="date" max={new Date().toISOString().slice(0, 10)} />
              <Field name="gender" label="Gender">
                <select><option>Male</option><option>Female</option><option>Other</option></select>
              </Field>
              <Field name="bloodType" label="Blood Type">
                <select>{BLOOD_TYPES.map((b) => <option key={b}>{b}</option>)}</select>
              </Field>
              <Field name="weight" label="Weight (kg)" type="number" min="1" max="300" />
            </div>
          </section>

          <section className="panel form-panel pf-section">
            <div className="panel-head"><h3>Address</h3></div>
            <div className="form-grid">
              <Field name="city" label="City" />
              <Field name="state" label="State" />
              <Field name="pincode" label="Pincode" inputMode="numeric" maxLength={6} />
              <Field name="address" label="Address" full><textarea /></Field>
            </div>
          </section>

          <section className="panel form-panel pf-section">
            <div className="panel-head"><h3><ShieldAlert size={17} /> Medical &amp; Emergency</h3></div>
            <div className="form-grid">
              <Field name="allergies" label="Allergies (if any)" full><textarea placeholder="e.g. Penicillin" /></Field>
              <Field name="conditions" label="Medical Conditions (if any)" full><textarea placeholder="e.g. Thalassemia, Anemia" /></Field>
              <Field name="emergencyName" label="Emergency Contact Name" />
              <Field name="emergencyPhone" label="Emergency Contact Phone" />
            </div>

            {editing && (
              <div className="pf-actions">
                <button type="submit" className="primary"><Save size={16} /> Save Changes</button>
                <button type="button" className="pf-secondary" onClick={cancelEdit}><X size={16} /> Cancel</button>
              </div>
            )}
          </section>
        </form>
      </FormCtx.Provider>

      <form onSubmit={changePassword} noValidate>
        <section className="panel form-panel pf-section">
          <div className="panel-head"><h3><Lock size={17} /> Change Password</h3></div>
          <div className="form-grid">
            <label className={`pf-field full-field${pwErrors.current ? " has-error" : ""}`}>
              Current Password
              <input type="password" value={pw.current} autoComplete="current-password"
                onChange={(e) => setPw({ ...pw, current: e.target.value })} />
              {pwErrors.current && <span className="pf-error">{pwErrors.current}</span>}
            </label>
            <label className={`pf-field${pwErrors.next ? " has-error" : ""}`}>
              New Password
              <input type="password" value={pw.next} autoComplete="new-password"
                onChange={(e) => setPw({ ...pw, next: e.target.value })} />
              {pwErrors.next && <span className="pf-error">{pwErrors.next}</span>}
            </label>
            <label className={`pf-field${pwErrors.confirm ? " has-error" : ""}`}>
              Confirm New Password
              <input type="password" value={pw.confirm} autoComplete="new-password"
                onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
              {pwErrors.confirm && <span className="pf-error">{pwErrors.confirm}</span>}
            </label>
          </div>
          <button type="submit" className="primary"><Lock size={16} /> Update Password</button>
        </section>
      </form>
    </>
  );
}
